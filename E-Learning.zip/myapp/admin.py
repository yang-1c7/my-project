from django.contrib import admin
from django.db import models
from .models import Topic, Course, Student, Order


# Register your models here.

def new_hours(modeladmin, request, queryset):
    for course in queryset:
        course.hours = course.hours + 10
        course.save()
    new_hours.short_description = 'Applied 10 hours more'


def upper_case(modeladmin, request, queryset):
    for student in queryset:
        student.last_name.upper()
        student.first_name.upper()
        student.save()
    upper_case.short_description = 'Student Full Name'


class CourseAdmin(admin.ModelAdmin):
    list_display = ('name', 'topic', 'price', 'hours', 'for_everyone')
    add_50_to_hours = [new_hours, ]


class StudentAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'city')
    upper_case_name = [upper_case, ]

admin.site.register(Topic)
admin.site.register(Course)
admin.site.register(Student)
admin.site.register(Order)
