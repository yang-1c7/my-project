# Import necessary classes
import pytz
from django.contrib.sites.shortcuts import get_current_site
from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import render_to_string
from django.urls import reverse
from .models import Topic, Course, Student, Order, User
from django.shortcuts import render, get_object_or_404, redirect
from myapp.forms import OrderForm, InterestForm, RegisterForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from datetime import datetime
from django.utils.encoding import force_text, force_bytes
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from .tokens import account_activation_token
from django.views import View
from django.views.generic import DetailView, ListView
# Create your views here.


class IndexView(View):
    def get(self, request):
        if 'last_login' in request.session:
            last_login = request.session['last_login']
        else:
            last_login = "Your last login was more than one hour ago!!"
        # top_list = Topic.objects.all().order_by('id')[:10]
        # request.session.set_test_cookie()
        return render(request, 'myapp/index.html', {'ash': self.get_queryset(), 'last_login': last_login})

    def get_queryset(self):
        return Topic.objects.all().order_by('id')[:10]

def about(request):
    #    response = HttpResponse()
    #    heading1 = '<p>' + ' This is an E-learning Website! Search our Topics to find all available Courses. ' + '</p>'
    #    response.write(heading1)

    # if request.session.test_cookie_worked():
    #  request.session.delete_test_cookie()
    #    cookienum += 2
    #  print("The test cookie worked!!!")
    #  return render(request, 'myapp/about.html')

    """
    about_visits = request.session.get('about_visits', 0)
    if request.COOKIES.get('about_visits'):
        about_visits = request.COOKIES.get('about_visits')
    else:
        request.session['about_visits'] = about_visits + 1
    response = render(request, 'myapp/about.html', {'about_visits': about_visits})
    response.set_cookie('about_visits', about_visits, max_age=5)
    response.delete_cookie('about_visits', about_visits)
    """
    about_visits = request.session.get('about_visits', 0)
    request.session['about_visits'] = about_visits + 1
    request.session.set_expiry(300)

    return render(request, 'myapp/about.html', {'about_visits': about_visits})


class DetailView(View):

    def get(self, request, top_no):
        topic = Topic.objects.get(id=top_no)
        name = str(topic.name)
        category = str(topic.category)
        courses = list(topic.courses.values_list('name'))

        my_context = {
            "topic_name": name,
            "topic_category": category,
            "topic_course": courses
        }
        return render(request, 'myapp/detail.html', my_context)

@login_required(login_url="user_login")
def detail(request, top_no):
    topic = Topic.objects.get(id=top_no)
    response = HttpResponse()

    heading1 = '<p>' + 'This is the detail page: ' + '<p>'
    response.write(heading1)
    name = str(topic.name)
    category = str(topic.category)
    courses = list(topic.courses.values_list('name'))

    response.write(name)
    response.write(category)
    response.write(courses)

    my_context = {
        "topic_name": name,
        "topic_category": category,
        "topic_course": courses
    }
    return render(request, 'myapp/detail.html', {'topic': topic})


def courses(request):
    courlist = Course.objects.all().order_by('id')
    return render(request, 'myapp/courses.html', {'courlist': courlist})


def place_order(request):
    msg = ''
    courlist = Course.objects.all()
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            if order.levels <= order.course.stages:
                if order.course.price > 150:
                    order.course.price -= order.course.discount()
                order.save()
                msg = 'Your course has been ordered successfully.'

            else:
                msg = 'You exceeded the number of levels for this course.'
            return render(request, 'myapp/order_response.html', {'msg': msg})
    else:
        form = OrderForm()
    return render(request, 'myapp/placeorder.html', {'form': form, 'msg': msg, 'courlist': courlist})


def coursedetail(request, cour_id):
    courdetail = Course.objects.get(id=cour_id)
    name = str(courdetail.name)
    price = str(courdetail.price)
    interested = str(courdetail.interested)
    my_context = {
        "course_name": name,
        "course_price": price,
        "course_interest": interested
    }

    if request.method == 'POST':
        form = InterestForm(request.POST)
        if form.is_valid():
            interested = form.cleaned_data['interested']
            if interested == 1:
                return render(request, 'myapp/index.html', )
        else:
            return HttpResponse('Invalid data')
    else:
        form = InterestForm()
        return render(request, 'myapp/coursedetail.html', {'form': form})


def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        current_login_time = datetime.now(pytz.timezone('America/Toronto'))
        timestamp = current_login_time.strftime("%d-%b-%Y (%H:%M:%S)")
        request.session['last_login'] = 'Last Login: ' + timestamp
        request.session.set_expiry(60)
        if user:
            login(request, user)
            if 'next' in request.POST:
                return redirect(request.POST.get('next'))
            else:
                return HttpResponseRedirect(reverse('myapp:index'))
        else:
            return HttpResponse('Invalid login details.')
    else:
        return render(request, 'myapp/login.html')

@login_required
def user_logout(request):
    request.session.flush()
    return HttpResponseRedirect(reverse('myapp:index'))



@login_required(login_url='myapp:user_login')
def myaccount(request):
    try:
        if Student.objects.get(id=request.user.id):
            if Order.objects.filter(student__id=request.user.id):
                orders = Order.objects.filter(student__id=request.user.id)
                for order in orders:
                    first_name = str(order.student.first_name)
                    last_name = str(order.student.last_name)
                    value1 = list(order.student.order_set.values_list('course__name'))
                    order_course = ", ".join(map(str, value1))
                    value2 = list(order.student.interested_in.all())
                    interested_in = ", ".join(map(str, value2))
                    my_context = {
                    "first_name": first_name,
                    "last_name": last_name,
                    "order_course":order_course,
                    "interested_in": interested_in

                    }
                return render(request, 'myapp/myaccount.html', my_context)
            else:
                return HttpResponseRedirect(reverse('myapp:myaccount1'))

    except Student.DoesNotExist:
        return HttpResponse("You are not a registered Client")


def activate(request, uidb64, token):
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        # user.profile.email_confirmed = True
        user.save()
        login(request, user)
        return redirect('myapp:index')
    else:
        return render(request, 'myapp/account_activation_invalid.html')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.save()
            current_site = get_current_site(request)
            subject = 'Activate Your MySite Account'
            message = render_to_string('myapp/account_activation_email.html', {
                'user': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            user.email_user(subject, message)
            return redirect('myapp:account_activation_sent')
    else:
        form = RegisterForm()
    return render(request, 'myapp/register.html', {'form': form})

def account_activation_sent(request):
    return render(request, 'myapp/account_activation_sent.html')

def myaccount1(request):
    return render(request, 'myapp/myaccount1.html')