from django.contrib import admin
from django.urls import path
from django.urls import include
from django.conf.urls import *
from django.contrib.auth import views as auth_views
from myapp import views


app_name = 'myapp'

urlpatterns = [
    path(r'', views.IndexView.as_view(), name='index'),
    path('admin/', admin.site.urls),
    path(r'about', views.about, name='about'),
    path(r'<int:top_no>/', views.DetailView.as_view(), name='detail'),
    path(r'courses', views.courses, name='courses'),
    path(r'place_order', views.place_order, name='place_order'),
    path(r'order_response', views.place_order, name='order_response'),
    path(r'courses/<int:cour_id>/', views.coursedetail, name='coursedetail'),
    path(r'login', views.user_login, name='user_login'),
    path(r'logout', views.user_logout, name='user_logout'),
    path(r'register', views.register, name='register'),
    path(r'myaccount', views.myaccount, name='myaccount'),


    path(r'accounts/', include('django.contrib.auth.urls')),


    path(r'password_change/done/',
         auth_views.PasswordChangeDoneView.as_view(template_name='registration/password_change_done.html'),
         name='password_change_done'),

    path(r'password_change/', auth_views.PasswordChangeView.as_view(template_name='registration/password_change.html'),
         name='password_change'),

    path(r'password_reset/done/',
         auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_done.html'),
         name='password_reset_done'),

    path(r'reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path(r'password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),

    path(r'reset/done/',
         auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_complete.html'),
         name='password_reset_complete'),

    url(r'account_activation_sent/$', views.account_activation_sent, name='account_activation_sent'),
    url(r'myaccount1/$', views.myaccount1, name='myaccount1'),

    url(r'activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        views.activate, name='activate'),
    
]
