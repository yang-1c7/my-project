package com.yjq.musiclz.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Extras;
import com.yjq.musiclz.constants.RequestCode;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.utils.FileUtils;
import com.yjq.musiclz.utils.ImageUtils;
import com.yjq.musiclz.utils.SystemUtils;

import java.io.File;
import java.util.Locale;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class MusicDetailsActivity extends BaseActivity implements View.OnClickListener {

    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;
    @BindView(R.id.iv_music_info_cover)
    ImageView ivMusicInfoCover;
    @BindView(R.id.et_music_info_title)
    EditText etMusicInfoTitle;
    @BindView(R.id.et_music_info_artist)
    EditText etMusicInfoArtist;
    @BindView(R.id.et_music_info_album)
    EditText etMusicInfoAlbum;
    @BindView(R.id.tv_music_info_duration)
    EditText tvMusicInfoDuration;
    @BindView(R.id.tv_music_info_file_name)
    EditText tvMusicInfoFileName;
    @BindView(R.id.tv_music_info_file_size)
    EditText tvMusicInfoFileSize;
    @BindView(R.id.tv_music_info_file_path)
    EditText tvMusicInfoFilePath;

    private Music mMusic;
    private File mMusicFile;
    private Bitmap mCoverBitmap;

    @Override
    protected void initData() {

    }

    @Override
    protected void initView() {
        super.initView();
        setTlTitle(idTlMain, idTvTlTitle, "歌曲信息");
    }

    @Override
    protected void onServiceBound() {
        super.onServiceBound();
        mMusic = (Music) getIntent().getSerializableExtra(Extras.MUSIC_DETAILS);
        if (mMusic == null || mMusic.getType() != Music.Type.LOCAL) {
            finish();
        }
        mMusicFile = new File(mMusic.getPath());
        Bitmap cover = BitmapFactory.decodeFile(mMusic.getCoverPath());
        if (cover != null) {
            ivMusicInfoCover.setImageBitmap(cover);
        }
        ivMusicInfoCover.setOnClickListener(this);

        etMusicInfoTitle.setText(mMusic.getTitle());
        etMusicInfoTitle.setSelection(etMusicInfoTitle.length());

        etMusicInfoArtist.setText(mMusic.getArtist());
        etMusicInfoArtist.setSelection(etMusicInfoArtist.length());

        etMusicInfoAlbum.setText(mMusic.getAlbum());
        etMusicInfoAlbum.setSelection(etMusicInfoAlbum.length());

        tvMusicInfoDuration.setText(SystemUtils.formatTime("mm:ss", mMusic.getDuration()));

        tvMusicInfoFileName.setText(mMusic.getFileName());

        tvMusicInfoFileSize.setText(String.format(Locale.getDefault(), "%.2fMB", FileUtils.b2mb((int) mMusic.getFileSize())));

        tvMusicInfoFilePath.setText(mMusicFile.getParent());
    }

    @Override
    protected void initListener() {
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());
        //toolbar的菜单操作
        idTlMain.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.action_save:
                    if (!mMusicFile.exists()) {
                        RxToast.normal("歌曲文件不存在");
                        return true;
                    }

                    String title = etMusicInfoTitle.getText().toString().trim();
                    String artist = etMusicInfoArtist.getText().toString().trim();
                    String album = etMusicInfoAlbum.getText().toString().trim();
                    if (isEtEmpty(title, "音乐标题不能为空...", etMusicInfoTitle)) return true;
                    if (isEtEmpty(artist, "音乐艺术家不能为空...", etMusicInfoArtist)) return true;
                    if (isEtEmpty(album, "音乐专辑不能为空...", etMusicInfoAlbum)) return true;

                    mMusic.setTitle(title);
                    mMusic.setArtist(artist);
                    mMusic.setAlbum(album);

                    Observable.just(GreenDaoHelper.getInstance().updateMusic(mMusic))
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(integer -> {
                                if (integer == 1){
                                    RxToast.normal("保存成功");
                                    mActivity.setResult(RESULT_OK);
                                    mActivity.finish();
                                }
                            })

                    ;
                    return true;
            }
            return false;
        });
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_music_details;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_music_details_save, menu);
        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_music_info_cover:
                ImageUtils.startAlbum(mActivity);
                break;
        }
    }

    private String cropFilePath;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK) {
            return;
        }
        if (requestCode == RequestCode.REQUEST_ALBUM && data != null) {
            cropFilePath = ImageUtils.startCorp(this, data.getData()).getPath();
        } else if (requestCode == RequestCode.REQUEST_CORP) {
            File corpFile = new File(cropFilePath);
            if (!corpFile.exists()) {
                RxToast.normal("图片保存失败");
                return;
            }
            mMusic.setCoverPath(cropFilePath);
            mCoverBitmap = BitmapFactory.decodeFile(cropFilePath);
            ivMusicInfoCover.setImageBitmap(mCoverBitmap);
        }
    }
}
