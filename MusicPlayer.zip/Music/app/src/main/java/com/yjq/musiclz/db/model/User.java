package com.yjq.musiclz.db.model;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 */
@Entity(nameInDb = "tb_user")
public class User {

    @Id(autoincrement = true)
    @Property(nameInDb = "id")
    private Long id;

    @NotNull
    @Property(nameInDb = "user_name")
    private String userName; //昵称

    @NotNull
    @Property(nameInDb = "user_pwd")
    private String userPwd; //密码

    @NotNull
    @Property(nameInDb = "user_pwd_help")
    private String userPwdHelp; //密保

    @NotNull
    @Property(nameInDb = "user_email")
    private String userEmail; //邮箱

    @Property(nameInDb = "user_img_path")
    private String userImgPath; // 头像路径  备用

    @Property(nameInDb = "user_type")
    private int userType; // 用户类型  1  管理员  0 普通用户


    @Generated(hash = 534628454)
    public User(Long id, @NotNull String userName, @NotNull String userPwd,
            @NotNull String userPwdHelp, @NotNull String userEmail,
            String userImgPath, int userType) {
        this.id = id;
        this.userName = userName;
        this.userPwd = userPwd;
        this.userPwdHelp = userPwdHelp;
        this.userEmail = userEmail;
        this.userImgPath = userImgPath;
        this.userType = userType;
    }

    @Generated(hash = 586692638)
    public User() {
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    public String getUserPwdHelp() {
        return userPwdHelp;
    }

    public void setUserPwdHelp(String userPwdHelp) {
        this.userPwdHelp = userPwdHelp;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserImgPath() {
        return userImgPath;
    }

    public void setUserImgPath(String userImgPath) {
        this.userImgPath = userImgPath;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", userPwd='" + userPwd + '\'' +
                ", userPwdHelp='" + userPwdHelp + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", userImgPath='" + userImgPath + '\'' +
                ", userType=" + userType +
                '}';
    }
}
