package com.yjq.musiclz.fragment;

import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ListView;
import android.widget.TextView;

import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.RxTimeTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.MyApp;
import com.yjq.musiclz.R;
import com.yjq.musiclz.activity.LoginActivity;
import com.yjq.musiclz.activity.VideoDetailActivity;
import com.yjq.musiclz.adapter.VideoAdapter;
import com.yjq.musiclz.base.BaseFragment;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.CommentDetailBean;
import com.yjq.musiclz.db.model.ReplyDetailBean;
import com.yjq.musiclz.db.model.VideoBean;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayer;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayerStandard;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * 我的  fragment
 */

public class FindMusicFragment extends BaseFragment {

    @BindView(R.id.id_lv_online_music)
    ListView idLvOnlineMusic;
    @BindView(R.id.id_tv_searching)
    TextView idTvSearching;

    private int firstVisible = 0, visibleCount = 0, totalCount = 0;

    private VideoAdapter mVideoAdapter;

    private GreenDaoHelper mGreenDaoHelper;

    @Override
    protected void initView() {
        super.initView();
        idTvSearching.setVisibility(View.GONE);
        idLvOnlineMusic.setVisibility(View.VISIBLE);
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshVideoList();
        mVideoAdapter.refreshUser();
    }

    @Override
    protected void initData() {
        super.initData();
        mGreenDaoHelper = GreenDaoHelper.getInstance();
        mVideoAdapter = new VideoAdapter(new ArrayList<>(), mContext);
        mVideoAdapter.setOnViewClickListener((view, o, position) -> {
            if (o == null) {
                RxToast.normal("请先登录之后再操作！！");
                RxActivityTool.skipActivity(mContext, LoginActivity.class);
                return;
            }
            VideoBean videoBean = (VideoBean) o;
            switch (view.getId()){
                case R.id.id_iv_video_comment:
                    Log.i(TAG, "initData: 评论点击");
                    addComment(position, videoBean);
                    break;
                case R.id.id_rsb_video_loves:
                    Log.i(TAG, "initData: 点赞点击");
                    videoBean.update();
                    Log.i(TAG, "initData: mgr===" + mGreenDaoHelper.queryVideoById(videoBean.getId()).toString());
                    break;
                case R.id.id_tv_video_desc:
                    addComment(position, videoBean);
                    break;
                case R.id.id_iv_video_share:
                    //分享
                    shareVideo(videoBean);
                    break;
            }
        });

        idLvOnlineMusic.setAdapter(mVideoAdapter);
        idLvOnlineMusic.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                switch (scrollState) {
                    case AbsListView.OnScrollListener.SCROLL_STATE_FLING:
                        Log.e("videoTest", "SCROLL_STATE_FLING");
                        break;
                    case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:
                        Log.e("videoTest", "SCROLL_STATE_IDLE");
                        autoPlayVideo(view);
                        break;
                    case AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                        Log.e("videoTest", "SCROLL_STATE_TOUCH_SCROLL");

                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem,
                                 int visibleItemCount, int totalItemCount) {
                // firstVisibleItem   当前第一个可见的item
                // visibleItemCount   当前可见的item个数
                if (firstVisible == firstVisibleItem) {
                    return;
                }
                firstVisible = firstVisibleItem;
                visibleCount = visibleItemCount;
                totalCount = totalItemCount;
            }
        });

    }

    private void refreshVideoList() {
        Observable.just(0)
                .map(integer -> {
                    List<VideoBean> videoBeanList = mGreenDaoHelper.queryVideoList();
                    videoBeanList = videoBeanList == null ? new ArrayList<>() : videoBeanList;
                    if (videoBeanList.size()==0) {
                        Resources res = mContext.getResources();
                        TypedArray a = res.obtainTypedArray(R.array.int_video_head);

                        String[] videoPublishNameArr = res.getStringArray(R.array.text_video_publish_name);
                        String[] videoDescArr = res.getStringArray(R.array.text_video_desc);
                        String[] videoCoverUrlArr = new String[]{
                                "http://android-imgs.25pp.com/fs08/2017/04/11/1/cee48982ad11e3d333bfa6efaf72f12c.jpg",
                                "http://android-imgs.25pp.com/fs08/2017/04/11/5/6d10e5650766c2260e5263d83b1aa2b0.jpg",
                                "http://android-imgs.25pp.com/fs08/2017/04/11/8/54bdc1f5156cfc63005fd0fecd533897.jpg"
                        };
                        String[] videoUrlArr = new String[]{
                                "http://video.pp.cn/fs08/2017/04/11/7/200_b81b52e4df88bb878248623045d47cca.mp4",
                                "http://video.pp.cn/fs08/2017/04/11/11/90751092-3f1d-403d-81c0-9cb8f512c9c1.mp4",
                                "http://video.pp.cn/fs08/2017/04/11/6/200_0c869e0dd681b98e459fad414a528005.mp4"
                        };
                        for (int i = 0; i < a.length(); i++) {
                            VideoBean videoBean = new VideoBean();
                            videoBean.setVideoCoverUrl(videoCoverUrlArr[2 - i % 2]);
                            videoBean.setVideoUrl(videoUrlArr[2 - i % 2]);
                            videoBean.setPublishHead(a.getResourceId(i, 0));
                            videoBean.setPublishName(videoPublishNameArr[i]);
                            videoBean.setVideoDesc(videoDescArr[i]);
                            videoBeanList.add(videoBean);
                        }
                        mGreenDaoHelper.insertVideoList(videoBeanList);
                    }
                    return mGreenDaoHelper.queryVideoList();
                }).observeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(videoBeanList -> mVideoAdapter.refreshVideoList(videoBeanList));
    }

    private void addComment(int position, VideoBean videoBean) {
        List<CommentDetailBean> commentDetailBeanList = videoBean.getCommentDetailBeanList();
        commentDetailBeanList = commentDetailBeanList == null ? new ArrayList<>() : commentDetailBeanList;
        if (commentDetailBeanList.size()==0){
            if (position/3==0){
                CommentDetailBean commentDetailBean = new CommentDetailBean();
                commentDetailBean.setContent("时间是一切财富中最宝贵的财富。");
                commentDetailBean.setCreateDate(RxTimeTool.string2Timestamp("yyyy-MM-dd HH:mm", "2019-02-25 00:00"));
                commentDetailBean.setVideoId(videoBean.getId());
                commentDetailBean.setUserId(1L);

                CommentDetailBean commentDetailBean01 = new CommentDetailBean();
                commentDetailBean01.setContent("这世界要是没有爱情，它在我们心中还会有什么意义！这就如一盏没有亮光的走马灯。。");
                commentDetailBean01.setCreateDate(RxTimeTool.string2Timestamp("yyyy-MM-dd HH:mm", "2019-02-26 00:00"));
                commentDetailBean01.setVideoId(videoBean.getId());
                commentDetailBean01.setUserId(2L);

                commentDetailBeanList.add(commentDetailBean);
                commentDetailBeanList.add(commentDetailBean01);
                mGreenDaoHelper.insertCommentDetailList(commentDetailBeanList);

                commentDetailBean.getUser();
                commentDetailBean01.getUser();


                List<ReplyDetailBean> replyDetailBeanList = commentDetailBean.getReplyList();
                replyDetailBeanList = replyDetailBeanList == null ? new ArrayList<>() : replyDetailBeanList;
                if (replyDetailBeanList.size()==0){
                    ReplyDetailBean replyDetailBean = new ReplyDetailBean();
                    replyDetailBean.setCreateDate(RxTimeTool.string2Timestamp("yyyy-MM-dd HH:mm", "2019-02-25 02:00"));
                    replyDetailBean.setUserId(2L);
                    replyDetailBean.setCommentId(1L);
                    replyDetailBean.setContent("时间总是在不经意中擦肩而过,不留一点痕迹.");
                    replyDetailBeanList.add(replyDetailBean);
                }
                mGreenDaoHelper.insertReplyDetailList(replyDetailBeanList);
                replyDetailBeanList.get(0).getUser();
                commentDetailBeanList.get(0).getReplyList();
            }
        }
        videoBean.getCommentDetailBeanList();
        Log.i(TAG, "addComment: videoBean.getCommentDetailBeanList()==" + videoBean.getCommentDetailBeanList().toString());
        Log.i(TAG, "initData: videoBean==" + videoBean.toString());
        Bundle parmas = new Bundle();
        parmas.putLong(Keys.VIDEO_ID, videoBean.getId());
        RxActivityTool.skipActivity(mContext, VideoDetailActivity.class, parmas);

    }

    private void autoPlayVideo(AbsListView view) {
        Log.e("videoTest", "firstVisiblePos  =  " + firstVisible + "visibleItemCount =  " + visibleCount);
        for (int i = 0; i < visibleCount; i++) {
            if (view != null && view.getChildAt(i) != null && view.getChildAt(i).findViewById(R.id.id_jcvps_video) != null) {
                JCVideoPlayerStandard videoPlayerStandard1 = view.getChildAt(i).findViewById(R.id.id_jcvps_video);
                Rect rect = new Rect();
                videoPlayerStandard1.getLocalVisibleRect(rect);
                int videoheight3 = videoPlayerStandard1.getHeight();
                Log.e("videoTest", "i=" + i + "===" + "videoheight3:" + videoheight3 + "===" + "rect.top:" + rect.top + "===" + "rect.bottom:" + rect.bottom);
                if (rect.top == 0 && rect.bottom == videoheight3) {
                    if (videoPlayerStandard1.currentState == JCVideoPlayer.CURRENT_STATE_NORMAL || videoPlayerStandard1.currentState == JCVideoPlayer.CURRENT_STATE_ERROR) {
                        Log.e("videoTest", videoPlayerStandard1.currentState + "======================performClick======================");
                        videoPlayerStandard1.startButton.performClick();
                        MyApp.getInstance().setVideoPlaying(videoPlayerStandard1);
                    }
                    return;
                }

            }
        }
        Log.e("videoTest", "======================releaseAllVideos=====================");
        JCVideoPlayer.releaseAllVideos();
        MyApp.getInstance().setVideoPlaying(null);
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.fragment_online_music_list;
    }


    /**
     * 分享视频
     */
    private void shareVideo(VideoBean videoBean) {
        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_SUBJECT, "分享视频链接");
        intent.putExtra(Intent.EXTRA_TEXT, videoBean.getVideoUrl());
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(Intent.createChooser(intent, "分享"));
    }

}
