package com.yjq.musiclz.utils;

import android.content.Context;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteConstraintException;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.enums.PlayModeEnum;
import com.yjq.musiclz.listener.OnPlayerEventListener;
import com.yjq.musiclz.receiver.NoisyAudioStreamReceiver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


/**
 */
public class AudioPlayer {

    private static final String TAG = "AudioPlayer";
    private static final int STATE_IDLE = 0;
    private static final int STATE_PREPARING = 1;
    private static final int STATE_PLAYING = 2;
    private static final int STATE_PAUSE = 3;

    private static final long TIME_UPDATE = 300L;

    private Context context;
    private AudioFocusManager audioFocusManager;
    private MediaPlayer mediaPlayer;
    private Handler handler;
    private NoisyAudioStreamReceiver noisyReceiver;
    private IntentFilter noisyFilter;
    private List<Music> musicList;
    private final List<OnPlayerEventListener> listeners = new ArrayList<>();
    private int state = STATE_IDLE;

    private GreenDaoHelper mGreenDaoHelper;

    private long userId = Keys.DEF_TOURIST_ID;

    public static AudioPlayer get() {
        return SingletonHolder.instance;
    }

    private static class SingletonHolder {
        private static AudioPlayer instance = new AudioPlayer();
    }

    private AudioPlayer() {
        mGreenDaoHelper = GreenDaoHelper.getInstance();
    }

    public void init(Context context) {
        this.context = context.getApplicationContext();
        musicList = (null == musicList) ? new ArrayList<>() : musicList;
        audioFocusManager = new AudioFocusManager(context);
        mediaPlayer = new MediaPlayer();
        handler = new Handler(Looper.getMainLooper());
        noisyReceiver = new NoisyAudioStreamReceiver();
        noisyFilter = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        mediaPlayer.setOnCompletionListener(mp -> next());
        mediaPlayer.setOnPreparedListener(mp -> {
            if (isPreparing()) {
                startPlayer();
            }
        });
        mediaPlayer.setOnBufferingUpdateListener((mp, percent) -> {
            for (OnPlayerEventListener listener : listeners) {
                listener.onBufferingUpdate(percent);
            }
        });
    }

    public void addOnPlayEventListener(OnPlayerEventListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeOnPlayEventListener(OnPlayerEventListener listener) {
        listeners.remove(listener);
    }

    /**
     * 新增或者更新播放列表
     *
     * @param userMusicList
     * @param isUpdate
     */
    public void addOrUpdate(UserMusicList userMusicList, boolean isUpdate) {
        GreenDaoHelper greenDaoHelper = GreenDaoHelper.getInstance();
        Log.i(TAG, "addOrUpdate: isUpdate==" + isUpdate + "===" + userMusicList.toString());
        if (isUpdate) {
            greenDaoHelper.updateUserMusicList(userMusicList);
        } else {
            greenDaoHelper.insertUserMusicList(userMusicList);
        }
    }

    public void initMusicList(){
        long musicListId = getPlayMusicListId();
        if (Keys.LOCAL_MUSIC_LIST_ID == musicListId){
            musicList = mGreenDaoHelper.queryMusicsByType(0);
            return;
        }
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            User user = new Gson().fromJson(userInfo, User.class);
            userId = user.getId() ;
        }
        musicList = mGreenDaoHelper.queryMusicsByUserIdMusicListId(userId, getPlayMusicListId());
    }

//    public void addAndPlay(Music music, UserMusicList userMusicList, boolean isUpdate) {
//        int position = musicList.indexOf(music);
//        if (position < 0) {
//            musicList.add(music);
//            GreenDaoHelper greenDaoHelper = GreenDaoHelper.getInstance();
//            Log.i(TAG, "addAndPlay: isUpdate==" + isUpdate + "===" + userMusicList.toString());
//            if (isUpdate){
//                greenDaoHelper.updateUserMusicList(userMusicList);
//            }else{
//                greenDaoHelper.insertUserMusicList(userMusicList);
//            }
//            position = musicList.size() - 1;
//        }
//        play(position);
//    }

    /**
     * 添加在线音乐
     *
     * @param music
     */
    public int addOnlineMusic(Music music) {
        GreenDaoHelper greenDaoHelper = GreenDaoHelper.getInstance();
        //这里我们设置了 songid 唯一 所有呢  我们就来容错这个唯一
        if (greenDaoHelper.queryMusicByMusicSongId(music.getSongId()) == null) {
            try {
                greenDaoHelper.insertMusic(music);
            } catch (SQLiteConstraintException e) {
                e.printStackTrace();
            }
        }
        Log.i(TAG, "addOnlineMusic: 传入的music" + music.toString());
        Log.i(TAG, "addOnlineMusic: 数据库中music==" + greenDaoHelper.queryMusicByMusicSongId(music.getSongId()).toString());
        musicList.add(0, music);
        return 0;
    }

    /**
     * 通过音乐的position 来播放音乐
     *
     *
     *
     * @param position
     */
    public void play(int position) {
        if (musicList.isEmpty()) {
            return;
        }

        if (position < 0) {
            position = musicList.size() - 1;
        } else if (position >= musicList.size()) {
            position = 0;
        }

        setPlayPosition(position);

        Music music = getPlayMusic();

        //最近播放一定存在的
        UserMusicList userMusicList = mGreenDaoHelper.queryUserMusicList(userId, Keys.RECENT_MUSIC_LIST_ID);
        List<Long> musicIdList = userMusicList.getMusicIdList();
        if (musicIdList == null) {
            musicIdList = new ArrayList<>();
        }
        if (!musicIdList.contains(music.getId())) {
            musicIdList.add(0, music.getId());
            userMusicList.setMusicIdList(musicIdList);
            mGreenDaoHelper.updateUserMusicList(userMusicList);
        }

        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(music.getPath());
            mediaPlayer.prepareAsync();
            state = STATE_PREPARING;
            for (OnPlayerEventListener listener : listeners) {
                listener.onChange(music);
            }
            MediaSessionManager.get().updateMetaData(music);
            MediaSessionManager.get().updatePlaybackState();
        } catch (IOException e) {
            e.printStackTrace();
            RxToast.normal("当前歌曲无法播放");
        }
    }

    /**
     * 删除
     *
     * @param position
     */
    public void delete(int position) {
        int playPosition = getPlayPosition();
        Music music = musicList.remove(position);
        // TODO: 2018/12/25 删除音乐
        if (playPosition > position) {
            setPlayPosition(playPosition - 1);
        } else if (playPosition == position) {
            if (isPlaying() || isPreparing()) {
                setPlayPosition(playPosition - 1);
                next();
            } else {
                stopPlayer();
                for (OnPlayerEventListener listener : listeners) {
                    listener.onChange(getPlayMusic());
                }
            }
        }
    }

    public void playPause() {
        if (isPreparing()) {
            stopPlayer();
        } else if (isPlaying()) {
            pausePlayer();
        } else if (isPausing()) {
            startPlayer();
        } else {
            play(getPlayPosition());
        }
    }

    public void startPlayer() {
        if (!isPreparing() && !isPausing()) {
            return;
        }

        if (audioFocusManager.requestAudioFocus()) {
            mediaPlayer.start();
            state = STATE_PLAYING;
            handler.post(mPublishRunnable);
//            Notifier.get().showPlay(getPlayMusic());
            MediaSessionManager.get().updatePlaybackState();
            context.registerReceiver(noisyReceiver, noisyFilter);

            for (OnPlayerEventListener listener : listeners) {
                listener.onPlayerStart();
            }
        }
    }

    public void pausePlayer() {
        pausePlayer(true);
    }

    public void pausePlayer(boolean abandonAudioFocus) {
        if (!isPlaying()) {
            return;
        }

        mediaPlayer.pause();
        state = STATE_PAUSE;
        handler.removeCallbacks(mPublishRunnable);
        MediaSessionManager.get().updatePlaybackState();
        context.unregisterReceiver(noisyReceiver);
        if (abandonAudioFocus) {
            audioFocusManager.abandonAudioFocus();
        }

        for (OnPlayerEventListener listener : listeners) {
            listener.onPlayerPause();
        }
    }

    public void stopPlayer() {
        if (isIdle()) {
            return;
        }

        pausePlayer();
        mediaPlayer.reset();
        state = STATE_IDLE;
    }

    public void next() {
        if (musicList.isEmpty()) {
            return;
        }

        PlayModeEnum mode = PlayModeEnum.valueOf((Integer) SPTool.getInstanse().getParam(Keys.PLAY_MODE, 0));
        switch (mode) {
            case SHUFFLE:
                play(new Random().nextInt(musicList.size()));
                break;
            case SINGLE:
                play(getPlayPosition());
                break;
            case LOOP:
            default:
                play(getPlayPosition() + 1);
                break;
        }
    }

    public void prev() {
        if (musicList.isEmpty()) {
            return;
        }

        PlayModeEnum mode = PlayModeEnum.valueOf((Integer) SPTool.getInstanse().getParam(Keys.PLAY_MODE, 0));
        switch (mode) {
            case SHUFFLE:
                play(new Random().nextInt(musicList.size()));
                break;
            case SINGLE:
                play(getPlayPosition());
                break;
            case LOOP:
            default:
                play(getPlayPosition() - 1);
                break;
        }
    }

    /**
     * 跳转到指定的时间位置
     *
     * @param msec 时间
     */
    public void seekTo(int msec) {
        if (isPlaying() || isPausing()) {
            mediaPlayer.seekTo(msec);
            MediaSessionManager.get().updatePlaybackState();
            for (OnPlayerEventListener listener : listeners) {
                listener.onPublish(msec);
            }
        }
    }

    private Runnable mPublishRunnable = new Runnable() {
        @Override
        public void run() {
            if (isPlaying()) {
                for (OnPlayerEventListener listener : listeners) {
                    listener.onPublish(mediaPlayer.getCurrentPosition());
                }
            }
            handler.postDelayed(this, TIME_UPDATE);
        }
    };

    public int getAudioSessionId() {
        return mediaPlayer.getAudioSessionId();
    }

    public long getAudioPosition() {
        if (isPlaying() || isPausing()) {
            return mediaPlayer.getCurrentPosition();
        } else {
            return 0;
        }
    }

    public Music getPlayMusic() {
        if (musicList.isEmpty()) {
            return null;
        }
        Music music = musicList.get(getPlayPosition());
        Log.i(TAG, getPlayPosition() + "===getPlayMusic: music===" + music.toString());
        return music;
    }

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public List<Music> getMusicList() {
        return musicList;
    }

    public boolean isPlaying() {
        return state == STATE_PLAYING;
    }

    public boolean isPausing() {
        return state == STATE_PAUSE;
    }

    public boolean isPreparing() {
        return state == STATE_PREPARING;
    }

    public boolean isIdle() {
        return state == STATE_IDLE;
    }

    public int getPlayPosition() {
        int position = (int) SPTool.getInstanse().getParam(Keys.PLAY_POSITION, 0);
        if (position < 0 || position >= musicList.size()) {
            position = 0;
            SPTool.getInstanse().setParam(Keys.PLAY_POSITION, position);
        }
        return position;
    }

    private void setPlayPosition(int position) {
        SPTool.getInstanse().setParam(Keys.PLAY_POSITION, position);
    }

    public long getPlayMusicListId() {
        long musicListId = (long) SPTool.getInstanse().getParam(Keys.PLAY_MUSIC_LIST_ID, 0l);
        if (musicListId < 0 ) {
            musicListId = 0;
            SPTool.getInstanse().setParam(Keys.PLAY_MUSIC_LIST_ID, musicListId);
        }
        return musicListId;
    }

    public void setPlayMusicListId(long musicListId) {
        SPTool.getInstanse().setParam(Keys.PLAY_MUSIC_LIST_ID, musicListId);
    }
}
