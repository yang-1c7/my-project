package com.yjq.musiclz.adapter;

import android.annotation.TargetApi;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.vondear.rxtool.RxImageTool;
import com.yjq.musiclz.R;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.listener.OnViewClickListener;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.FileUtils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * 本地音乐列表适配器
 */
public class MusicAdapter extends BaseAdapter {

    private static final String TAG = "MusicAdapter";
    private List<Music> musicList;
    private OnViewClickListener listener;
    private boolean isPlaylist;

    public MusicAdapter(List<Music> musicList) {
        this.musicList = musicList;
    }

    public void setIsPlaylist(boolean isPlaylist) {
        this.isPlaylist = isPlaylist;
    }

    public void setOnViewClickListener(OnViewClickListener listener) {
        this.listener = listener;
    }

    @Override
    public int getCount() {
        return musicList.size();
    }

    @Override
    public Object getItem(int position) {
        return musicList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        MusicViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_music_list, parent, false);
            holder = new MusicViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (MusicViewHolder) convertView.getTag();
        }
        holder.vPlaying.setVisibility((isPlaylist && position == AudioPlayer.get().getPlayPosition()) ? View.VISIBLE : View.INVISIBLE);
        Music music = musicList.get(position);
        String coverPath = music.getCoverPath();
        String coverPathTag = (String) holder.ivCover.getTag();
        if (coverPathTag != null) {
            // 通过 tag 来防止图片错位
            if (coverPathTag.equals(coverPath)) {
                holder.ivCover.setImageBitmap(BitmapFactory.decodeFile(coverPath));
            }else{
                holder.ivCover.setImageBitmap(RxImageTool.getBitmap(R.mipmap.default_cover));
            }
        }else if (coverPath != null ){
            holder.ivCover.setTag(coverPath);
            holder.ivCover.setImageBitmap(BitmapFactory.decodeFile(coverPath));
        }
        holder.tvTitle.setText(music.getTitle());
        String artist = FileUtils.getArtistAndAlbum(music.getArtist(), music.getAlbum());
        holder.tvArtist.setText(artist);
        holder.ivMore.setOnClickListener(v -> {
            if (listener != null) {
                listener.onViewClick(holder.ivMore, music, position);
            }
        });
        holder.vDivider.setVisibility(isShowDivider(position) ? View.VISIBLE : View.GONE);
        return convertView;
    }

    private boolean isShowDivider(int position) {
        return position != musicList.size() - 1;
    }

    static class MusicViewHolder {
        @BindView(R.id.v_playing)
        View vPlaying;
        @BindView(R.id.iv_cover)
        ImageView ivCover;
        @BindView(R.id.tv_title)
        TextView tvTitle;
        @BindView(R.id.tv_artist)
        TextView tvArtist;
        @BindView(R.id.iv_more)
        ImageView ivMore;
        @BindView(R.id.v_divider)
        View vDivider;

        public MusicViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }
}
