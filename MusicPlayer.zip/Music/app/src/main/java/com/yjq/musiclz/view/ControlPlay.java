package com.yjq.musiclz.view;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.vondear.rxtool.RxImageTool;
import com.yjq.musiclz.R;
import com.yjq.musiclz.activity.MusicListParentActivity;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.listener.OnPlayerEventListener;
import com.yjq.musiclz.utils.AudioPlayer;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 音乐控制的播放界面
 *
 */

public class ControlPlay implements View.OnClickListener, OnPlayerEventListener {

    @BindView(R.id.iv_play_bar_cover)
    ImageView ivPlayBarCover;
    @BindView(R.id.tv_play_bar_title)
    TextView tvPlayBarTitle;
    @BindView(R.id.tv_play_bar_artist)
    TextView tvPlayBarArtist;
    @BindView(R.id.iv_play_bar_play)
    ImageView ivPlayBarPlay;
    @BindView(R.id.iv_play_bar_next)
    ImageView ivPlayBarNext;
    @BindView(R.id.v_play_bar_playlist)
    ImageView vPlayBarPlaylist;
    @BindView(R.id.pb_play_bar)
    ProgressBar mProgressBar;

    public ControlPlay(View view) {
        ButterKnife.bind(this, view);
        ivPlayBarPlay.setOnClickListener(this);
        ivPlayBarNext.setOnClickListener(this);
        vPlayBarPlaylist.setOnClickListener(this);
        onChange(AudioPlayer.get().getPlayMusic());
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_play_bar_play:
                AudioPlayer.get().playPause();
                break;
            case R.id.iv_play_bar_next:
                AudioPlayer.get().next();
                break;
            case R.id.v_play_bar_playlist:
                Context context = vPlayBarPlaylist.getContext();
                //默认的音乐列表
                Intent intent = new Intent(context, MusicListParentActivity.class);
                context.startActivity(intent);
                break;
        }
    }

    @Override
    public void onChange(Music music) {
        if (music == null) {
            return;
        }
        Bitmap cover = BitmapFactory.decodeFile(music.getCoverPath());
        if (cover != null) {
            ivPlayBarCover.setImageBitmap(cover);
        }else{
            ivPlayBarCover.setImageBitmap(RxImageTool.getBitmap(R.mipmap.default_cover));
        }
        tvPlayBarTitle.setText(music.getTitle());
        tvPlayBarArtist.setText(music.getArtist());
        ivPlayBarPlay.setSelected(AudioPlayer.get().isPlaying() || AudioPlayer.get().isPreparing());
        mProgressBar.setMax((int) music.getDuration());
        mProgressBar.setProgress((int) AudioPlayer.get().getAudioPosition());
    }

    @Override
    public void onPlayerStart() {
        ivPlayBarPlay.setSelected(true);
    }

    @Override
    public void onPlayerPause() {
        ivPlayBarPlay.setSelected(false);
    }

    @Override
    public void onPublish(int progress) {
        mProgressBar.setProgress(progress);
    }

    @Override
    public void onBufferingUpdate(int percent) {
    }
}
