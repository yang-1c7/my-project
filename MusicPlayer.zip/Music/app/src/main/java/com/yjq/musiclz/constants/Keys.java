package com.yjq.musiclz.constants;

/**
 */
public interface Keys {
    String VIEW_PAGER_INDEX = "view_pager_index";
    String LOCAL_MUSIC_POSITION = "local_music_position";
    String LOCAL_MUSIC_OFFSET = "local_music_offset";
    String PLAYLIST_POSITION = "playlist_position";
    String PLAYLIST_OFFSET = "playlist_offset";

    /**
     * 用户信息，只有会员才有的，游客是没有的（因为游客不用注册，只是纯粹的播放器）
     *
     */
    String USER_INFO = "userInfo";

    /**
     * 数据库的名称
     *
     */
    String DB_NAME = "musiclz_db";

    /**
     * 播放那首音乐
     *
     */
    String PLAY_POSITION = "play_position";
    /**
     * 播放模式
     *
     */
    String PLAY_MODE = "play_mode";

    String SPLASH_URL = "splash_url";

    /**
     * 播放那首音乐的musicListId
     *
     */
    String PLAY_MUSIC_LIST_ID = "play_music_list_id";

    /**
     * 默认列表的id
     *
     */
    long DEF_MUSIC_LIST_ID = 1;

    /**
     * 本地音乐对应的标识
     *
     */
    long LOCAL_MUSIC_LIST_ID = 1000;

    /**
     * 我喜欢对应的标识
     *
     */
    long MY_LOVE_MUSIC_LIST_ID = 1001;

    /**
     * 最近播放对应的标识
     *
     */
    long RECENT_MUSIC_LIST_ID = 1002;



    /**
     * 游客的id
     *
     */
    long DEF_TOURIST_ID = -1;

    /**
     * sp的名字
     *
     */
    String SP_FILE_NAME = "musiclz_cache";

    /**
     * 是否是夜晚模式
     *
     */
    String NIGHT_MODE = "night_mode";

    String MOBILE_NETWORK_PLAY ="mobile_network_play";

    /**
     *
     */
    String VIDEO_ID ="video_id";
}
