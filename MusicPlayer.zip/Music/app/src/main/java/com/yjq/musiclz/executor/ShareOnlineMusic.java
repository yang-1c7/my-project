package com.yjq.musiclz.executor;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.entry.DownloadInfo;
import com.yjq.musiclz.http.HttpCallback;
import com.yjq.musiclz.http.HttpClient;


/**
 * 分享在线歌曲
 */
public abstract class ShareOnlineMusic implements IExecutor<Void> {
    private static final String TAG = "ShareOnlineMusic";
    private Context mContext;
    private String mTitle;
    private String mSongId;

    public ShareOnlineMusic(Context context, String title, String songId) {
        mContext = context;
        mTitle = title;
        mSongId = songId;
    }

    @Override
    public void execute() {
        onPrepare();
        share();
    }

    private void share() {
        // 获取歌曲播放链接
        HttpClient.getMusicDownloadInfo(mSongId, new HttpCallback<DownloadInfo>() {
            @Override
            public void onSuccess(DownloadInfo response) {
                if (response == null) {
                    Log.i(TAG, "onSuccess: 返回信息为空");
                    onFail(null);
                    return;
                }
                Log.i(TAG, "onSuccess: response==" + response.toString());
                if (response.getBitrate() != null) {
                    onExecuteSuccess(null);
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_TEXT, mContext.getString(R.string.share_music, mContext.getString(R.string.app_name),
                            mTitle, response.getBitrate().getFile_link()));
                    mContext.startActivity(Intent.createChooser(intent, mContext.getString(R.string.share)));
                }else{
                    onFail(null);
                }

            }

            @Override
            public void onFail(Exception e) {
                onExecuteFail(e);
                RxToast.normal("暂时无法分享");
            }
        });
    }
}
