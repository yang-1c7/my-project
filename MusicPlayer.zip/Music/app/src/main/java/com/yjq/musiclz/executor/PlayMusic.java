package com.yjq.musiclz.executor;

import android.app.Activity;
import android.app.Dialog;
import android.support.v7.app.AlertDialog;

import com.yjq.musiclz.R;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.utils.NetworkUtils;
import com.yjq.musiclz.utils.SPTool;



public abstract class PlayMusic implements IExecutor<Music> {
    private Activity mActivity;
    protected Music music;
    private int mTotalStep;
    protected int mCounter = 0;

    public PlayMusic(Activity activity, int totalStep) {
        mActivity = activity;
        mTotalStep = totalStep;
    }

    @Override
    public void execute() {
        checkNetwork();
    }

    private void checkNetwork() {
        boolean mobileNetworkPlay = (boolean) SPTool.getInstanse().getParam(Keys.MOBILE_NETWORK_PLAY, false);
        if (NetworkUtils.isActiveNetworkMobile(mActivity) && !mobileNetworkPlay) {
            AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
            builder.setTitle(R.string.tips);
            builder.setMessage(R.string.play_tips);
            builder.setPositiveButton(R.string.play_tips_sure, (dialog, which) -> {
                SPTool.getInstanse().setParam(Keys.MOBILE_NETWORK_PLAY, true);
                getPlayInfoWrapper();
            });
            builder.setNegativeButton(R.string.cancel, null);
            Dialog dialog = builder.create();
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        } else {
            getPlayInfoWrapper();
        }
    }

    private void getPlayInfoWrapper() {
        onPrepare();
        getPlayInfo();
    }

    protected abstract void getPlayInfo();

    protected void checkCounter() {
        mCounter++;
        if (mCounter == mTotalStep) {
            onExecuteSuccess(music);
        }
    }
}
