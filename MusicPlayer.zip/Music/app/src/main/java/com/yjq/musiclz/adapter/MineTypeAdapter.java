package com.yjq.musiclz.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.yjq.musiclz.R;
import com.yjq.musiclz.entry.MineTypeBean;
import com.yjq.musiclz.listener.OnViewClickListener;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 */

public class MineTypeAdapter extends RecyclerView.Adapter<MineTypeAdapter.MineTypeViewHolder> {

    private Context mContext;
    private List<MineTypeBean> mData;

    private OnViewClickListener<MineTypeBean> mOnViewClickListener;

    public void setOnViewClickListener(OnViewClickListener<MineTypeBean> onViewClickListener) {
        this.mOnViewClickListener = onViewClickListener;
    }

    public MineTypeAdapter(Context context, List<MineTypeBean> mineTypeBeanList) {
        this.mContext = context;
        this.mData = mineTypeBeanList;
    }

    @NonNull
    @Override
    public MineTypeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MineTypeViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_mine_type, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MineTypeViewHolder holder, int position) {
        MineTypeBean mineTypeBean = mData.get(position);
        Glide.with(mContext)
                .load(mineTypeBean.getImgResId())
                .into(holder.idIvMineType);
        holder.idTvNameMineType.setText(mineTypeBean.getTypeName());
        int num = mineTypeBean.getTypeNum();
        if (num == 0) {
            holder.idTvNumMineType.setVisibility(View.INVISIBLE);
        } else if (num > 0) {
            holder.idTvNumMineType.setText(String.valueOf(mineTypeBean.getTypeNum()));
            holder.idTvNumMineType.setVisibility(View.VISIBLE);
        }

        holder.idClRoot.setOnClickListener(view -> {
            if (mOnViewClickListener != null) {
                mOnViewClickListener.onViewClick(view, mineTypeBean, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    static class MineTypeViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.id_cl_root)
        ConstraintLayout idClRoot;
        @BindView(R.id.id_iv_mine_type)
        ImageView idIvMineType;
        @BindView(R.id.id_tv_name_mine_type)
        TextView idTvNameMineType;
        @BindView(R.id.id_tv_num_mine_type)
        TextView idTvNumMineType;

        public MineTypeViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
