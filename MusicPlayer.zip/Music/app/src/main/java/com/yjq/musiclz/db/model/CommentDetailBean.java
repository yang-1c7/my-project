package com.yjq.musiclz.db.model;

import com.yjq.musiclz.db.converter.LongConverter;
import com.yjq.musiclz.db.greendao.CommentDetailBeanDao;
import com.yjq.musiclz.db.greendao.DaoSession;
import com.yjq.musiclz.db.greendao.ReplyDetailBeanDao;
import com.yjq.musiclz.db.greendao.UserDao;

import org.greenrobot.greendao.DaoException;
import org.greenrobot.greendao.annotation.Convert;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.ToMany;
import org.greenrobot.greendao.annotation.ToOne;

import java.util.List;

/**
 * 评论的详情
 *
 */
@Entity(nameInDb = "tb_comment")
public class CommentDetailBean {

    @Id(autoincrement = true)
    private Long id;
    //对应到那个视频id
    private Long videoId;

    private Long userId;
    @ToOne(joinProperty = "userId")
    User user;
    private String content;
    private String createDate;

    /**
     * 点赞的人数  一个用户只能对一个视频或者一个评论点赞
     *
     */
    @Convert(columnType = String.class, converter = LongConverter.class)
    private List<Long> loveUserIdList;

    @ToMany(referencedJoinProperty  = "commentId")
    List<ReplyDetailBean> replyList;
    /** Used to resolve relations */
    @Generated(hash = 2040040024)
    private transient DaoSession daoSession;
    /** Used for active entity operations. */
    @Generated(hash = 144870298)
    private transient CommentDetailBeanDao myDao;



    @Generated(hash = 1460998716)
    public CommentDetailBean() {
    }

    @Generated(hash = 70988729)
    public CommentDetailBean(Long id, Long videoId, Long userId, String content, String createDate,
            List<Long> loveUserIdList) {
        this.id = id;
        this.videoId = videoId;
        this.userId = userId;
        this.content = content;
        this.createDate = createDate;
        this.loveUserIdList = loveUserIdList;
    }

    @Generated(hash = 251390918)
    private transient Long user__resolvedKey;

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }


    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getCreateDate() {
        return createDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVideoId() {
        return videoId;
    }

    public void setVideoId(Long videoId) {
        this.videoId = videoId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public List<Long> getLoveUserIdList() {
        return loveUserIdList;
    }

    public void setLoveUserIdList(List<Long> loveUserIdList) {
        this.loveUserIdList = loveUserIdList;
    }

    @Override
    public String toString() {
        return "CommentDetailBean{" +
                "id=" + id +
                ", videoId=" + videoId +
                ", userId=" + userId +
                ", user=" + user +
                ", content='" + content + '\'' +
                ", createDate='" + createDate + '\'' +
                ", loveUserIdList=" + loveUserIdList +
                ", replyList=" + replyList +
                ", daoSession=" + daoSession +
                ", myDao=" + myDao +
                ", user__resolvedKey=" + user__resolvedKey +
                '}';
    }

    /** To-one relationship, resolved on first access. */
    @Generated(hash = 859885876)
    public User getUser() {
        Long __key = this.userId;
        if (user__resolvedKey == null || !user__resolvedKey.equals(__key)) {
            final DaoSession daoSession = this.daoSession;
            if (daoSession == null) {
                throw new DaoException("Entity is detached from DAO context");
            }
            UserDao targetDao = daoSession.getUserDao();
            User userNew = targetDao.load(__key);
            synchronized (this) {
                user = userNew;
                user__resolvedKey = __key;
            }
        }
        return user;
    }

    /** called by internal mechanisms, do not call yourself. */
    @Generated(hash = 1065606912)
    public void setUser(User user) {
        synchronized (this) {
            this.user = user;
            userId = user == null ? null : user.getId();
            user__resolvedKey = userId;
        }
    }

    /**
     * To-many relationship, resolved on first access (and after reset).
     * Changes to to-many relations are not persisted, make changes to the target entity.
     */
    @Generated(hash = 1174755729)
    public List<ReplyDetailBean> getReplyList() {
        if (replyList == null) {
            final DaoSession daoSession = this.daoSession;
            if (daoSession == null) {
                throw new DaoException("Entity is detached from DAO context");
            }
            ReplyDetailBeanDao targetDao = daoSession.getReplyDetailBeanDao();
            List<ReplyDetailBean> replyListNew = targetDao
                    ._queryCommentDetailBean_ReplyList(id);
            synchronized (this) {
                if (replyList == null) {
                    replyList = replyListNew;
                }
            }
        }
        return replyList;
    }

    /** Resets a to-many relationship, making the next get call to query for a fresh result. */
    @Generated(hash = 1198927680)
    public synchronized void resetReplyList() {
        replyList = null;
    }

    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#delete(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 128553479)
    public void delete() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.delete(this);
    }

    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#refresh(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 1942392019)
    public void refresh() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.refresh(this);
    }

    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#update(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 713229351)
    public void update() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.update(this);
    }

    /** called by internal mechanisms, do not call yourself. */
    @Generated(hash = 1090116625)
    public void __setDaoSession(DaoSession daoSession) {
        this.daoSession = daoSession;
        myDao = daoSession != null ? daoSession.getCommentDetailBeanDao() : null;
    }
}
