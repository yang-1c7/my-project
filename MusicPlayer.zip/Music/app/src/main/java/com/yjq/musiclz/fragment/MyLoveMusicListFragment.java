package com.yjq.musiclz.fragment;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.activity.MusicDetailsActivity;
import com.yjq.musiclz.adapter.MusicAdapter;
import com.yjq.musiclz.base.BaseFragment;
import com.yjq.musiclz.constants.Extras;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.constants.RequestCode;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.listener.OnViewClickListener;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.SPTool;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class MyLoveMusicListFragment extends BaseFragment implements AdapterView.OnItemClickListener, OnViewClickListener<Music> {

    @BindView(R.id.id_lv_local_music)
    ListView idLvLocalMusic;
    @BindView(R.id.id_tv_searching)
    TextView idTvSearching;

    @Override
    protected int getLayoutResId() {
        return R.layout.fragment_local_music_list;
    }

    private GreenDaoHelper mGreenDaoHelper;
    private MusicAdapter mAdapter;

    private List<Music> musicList;

    private long userId = Keys.DEF_TOURIST_ID;

    @Override
    protected void initView() {
        super.initView();
        idLvLocalMusic.setVisibility(View.GONE);
        idTvSearching.setVisibility(View.VISIBLE);
    }

    @Override
    protected void initData() {
        super.initData();
        mGreenDaoHelper = GreenDaoHelper.getInstance();
        musicList = new ArrayList<>();
        mAdapter = new MusicAdapter(musicList);
        mAdapter.setOnViewClickListener(this);
        idLvLocalMusic.setAdapter(mAdapter);
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            User user = new Gson().fromJson(userInfo, User.class);
            userId = user.getId() ;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        loadMusic();
    }

    private void loadMusic() {
        Observable.just(mGreenDaoHelper.queryMusicsByUserIdMusicListId(userId, Keys.MY_LOVE_MUSIC_LIST_ID))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(musics -> {
                    if(musics.size() > 0) {
                        refreshMusicList(musics);
                    }else if (musics.size() ==0){
                        idTvSearching.setText("暂无我喜欢的音乐！！");
                        idLvLocalMusic.setVisibility(View.GONE);
                        idTvSearching.setVisibility(View.VISIBLE);
                    }
                });
    }

    /**
     * 刷新音乐列表
     *
     * @param musics
     */
    private void refreshMusicList(List<Music> musics) {
        if (musicList.size() > 0) {
            musicList.clear();
        }
        Log.i(TAG, musics.size() + "====refreshMusicList: musics==" + musics.toString());
        musicList.addAll(musics);
        Log.i(TAG, musicList.size() + "===refreshMusicList: musicList==" + musicList.toString());
        idLvLocalMusic.setVisibility(View.VISIBLE);
        idTvSearching.setVisibility(View.GONE);
        mAdapter.notifyDataSetChanged();
    }


    @Override
    protected void initListener() {
        super.initListener();
        idLvLocalMusic.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Music music = musicList.get(position);
        Log.i(TAG, position + "==onItemClick: ==" + music.toString());
        //点击的时候，我们只是播放
        AudioPlayer audioPlayer = AudioPlayer.get();
        audioPlayer.setPlayMusicListId(Keys.MY_LOVE_MUSIC_LIST_ID);
        audioPlayer.initMusicList();
        audioPlayer.play(position);
    }

    /**
     * 分享音乐
     */
    private void shareMusic(Music music) {
        File file = new File(music.getPath());
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
        startActivity(Intent.createChooser(intent, "分享"));
    }

    private void requestSetRingtone(final Music music) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(mContext)) {
            RxToast.normal("没有权限，无法设置铃声，请授予权限");
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            startActivityForResult(intent, RequestCode.REQUEST_WRITE_SETTINGS);
        } else {
            setRingtone(music);
        }
    }

    /**
     * 设置铃声
     */
    private void setRingtone(Music music) {
        Uri uri = MediaStore.Audio.Media.getContentUriForPath(music.getPath());
        // 查询音乐文件在媒体库是否存在
        Cursor cursor = getContext().getContentResolver()
                .query(uri, null, MediaStore.MediaColumns.DATA + "=?", new String[]{music.getPath()}, null);
        if (cursor == null) {
            return;
        }
        if (cursor.moveToFirst() && cursor.getCount() > 0) {
            String _id = cursor.getString(0);
            ContentValues values = new ContentValues();
            values.put(MediaStore.Audio.Media.IS_MUSIC, true);
            values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
            values.put(MediaStore.Audio.Media.IS_ALARM, false);
            values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
            values.put(MediaStore.Audio.Media.IS_PODCAST, false);

            getContext().getContentResolver()
                    .update(uri, values, MediaStore.MediaColumns.DATA + "=?", new String[]{music.getPath()});
            Uri newUri = ContentUris.withAppendedId(uri, Long.valueOf(_id));
            RingtoneManager.setActualDefaultRingtoneUri(getContext(), RingtoneManager.TYPE_RINGTONE, newUri);
            RxToast.normal("设置铃声成功！");
        }
        cursor.close();
    }

    private void deleteMusic(final Music music) {
        String title = music.getTitle();
        new AlertDialog.Builder(mContext)
                .setMessage("移除" + title)
                .setPositiveButton("移除", (dialog1, which) -> {
                    Observable.just(1)
                            .map(integer -> {
                                UserMusicList userMusicList = mGreenDaoHelper.queryUserMusicList(userId, Keys.MY_LOVE_MUSIC_LIST_ID);
                                userMusicList.getMusicIdList().remove(music.getId());
                                mGreenDaoHelper.updateUserMusicList(userMusicList);
                                musicList.remove(music);
                                return 1;
                            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                            .subscribe(r -> mAdapter.notifyDataSetChanged());
                }).setNegativeButton("放弃", null)
                .show();
    }


    @Override
    public void onSaveInstanceState(Bundle outState) {
        int position = idLvLocalMusic.getFirstVisiblePosition();
        int offset = (idLvLocalMusic.getChildAt(0) == null) ? 0 : idLvLocalMusic.getChildAt(0).getTop();
        outState.putInt(Keys.LOCAL_MUSIC_POSITION, position);
        outState.putInt(Keys.LOCAL_MUSIC_OFFSET, offset);
    }

    public void onRestoreInstanceState(final Bundle savedInstanceState) {
        idLvLocalMusic.post(() -> {
            int position = savedInstanceState.getInt(Keys.LOCAL_MUSIC_POSITION);
            int offset = savedInstanceState.getInt(Keys.LOCAL_MUSIC_OFFSET);
            idLvLocalMusic.setSelectionFromTop(position, offset);
        });
    }

    @Override
    public void onViewClick(View view, Music music, int position) {
        new AlertDialog.Builder(mContext)
                .setTitle(music.getTitle())
                .setItems(R.array.local_music_dialog, (dialog1, which) -> {
                    switch (which) {
                        case 0:// 分享
                            shareMusic(music);
                            break;
                        case 1:// 设为铃声
                            requestSetRingtone(music);
                            break;
                        case 2:// 查看歌曲信息
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(Extras.MUSIC_DETAILS, music);
                            RxActivityTool.skipActivityForResult(mActivity, MusicDetailsActivity.class, bundle, RequestCode.REQ_UPDATE_MUSIC);
                            break;
                        case 3:// 删除
                            deleteMusic(music);
                            break;
                    }
                }).show();
    }

    /**
     * 更新音乐信息
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        loadMusic();
    }

}
