package com.yjq.musiclz.constants;

/**
 * Extras
 */
public interface Extras {
    String MUSIC_LIST_TYPE = "music_list_type";
    String TING_UID = "ting_uid";

    /**
     * 音乐详情
     *
     */
    String MUSIC_DETAILS = "music_details";

    /**
     * 歌手的更多信息
     *
     */
    String MUSIC_ARTIST_INFO_URL = "music_artist_info_url";
    String MUSIC_ARTIST_NAME = "music_artist_name";

}
