package com.yjq.musiclz.fragment;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.os.Build;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.cazaea.sweetalert.SweetAlertDialog;
import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.vondear.rxui.view.likeview.RxShineButton;
import com.yjq.musiclz.R;
import com.yjq.musiclz.activity.LoginActivity;
import com.yjq.musiclz.adapter.WelcomeAdapter;
import com.yjq.musiclz.base.BaseFragment;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.enums.PlayModeEnum;
import com.yjq.musiclz.listener.OnPlayerEventListener;
import com.yjq.musiclz.loader.CoverLoader;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.SPTool;
import com.yjq.musiclz.utils.ScreenUtils;
import com.yjq.musiclz.utils.SystemUtils;
import com.yjq.musiclz.view.AlbumCoverView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;

/**
 */

public class PlayMusicFragment extends BaseFragment implements View.OnClickListener,
        SeekBar.OnSeekBarChangeListener, OnPlayerEventListener {

    @BindView(R.id.ll_content)
    LinearLayout llContent;
    @BindView(R.id.iv_back)
    ImageView ivBack;
    @BindView(R.id.tv_title)
    TextView tvTitle;
    @BindView(R.id.tv_artist)
    TextView tvArtist;
    @BindView(R.id.vp_play_page)
    ViewPager vpPlayPage;
    @BindView(R.id.tv_current_time)
    TextView tvCurrentTime;
    @BindView(R.id.sb_progress)
    SeekBar sbProgress;
    @BindView(R.id.tv_total_time)
    TextView tvTotalTime;
    @BindView(R.id.iv_mode)
    ImageView ivMode;
    @BindView(R.id.iv_prev)
    ImageView ivPrev;
    @BindView(R.id.iv_play)
    ImageView ivPlay;
    @BindView(R.id.iv_next)
    ImageView ivNext;
    @BindView(R.id.iv_play_music_bg)
    ImageView ivPlayMusicBg;
    @BindView(R.id.id_iv_love)
    RxShineButton idIvLove;

    private AlbumCoverView albumCoverView;
    private AudioManager mAudioManager;

    private int lastProgress;
    private boolean isDraggingProgress;

    @Override
    protected void initView() {
        super.initView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            int top = ScreenUtils.getStatusBarHeight();
            llContent.setPadding(0, top, 0, 0);
        }
        initViewPager();
        setPlayMode();
        onChangeImpl(AudioPlayer.get().getPlayMusic());
        AudioPlayer.get().addOnPlayEventListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        long userId = Keys.DEF_TOURIST_ID;
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            User user = new Gson().fromJson(userInfo, User.class);
            userId = user.getId() ;
        }
        UserMusicList userMusicList = GreenDaoHelper.getInstance().queryUserMusicListsByUserIdMusicListId(userId, Keys.MY_LOVE_MUSIC_LIST_ID);
        if (userMusicList == null) return;
        if (userMusicList.getMusicIdList() !=null && userMusicList.getMusicIdList().size()>0){
            idIvLove.setChecked(userMusicList.getMusicIdList().contains(AudioPlayer.get().getPlayMusic().getId()));
        }
    }

    private void setPlayMode() {
        int mode = (int) SPTool.getInstanse().getParam(Keys.PLAY_MODE, 0);
        mode = mode == -1 ? 0 : mode;
        ivMode.setImageLevel(mode);
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.fragment_play_music;
    }

    @Override
    protected void initListener() {
        super.initListener();
        ivBack.setOnClickListener(this);
        ivMode.setOnClickListener(this);
        ivPlay.setOnClickListener(this);
        ivPrev.setOnClickListener(this);
        ivNext.setOnClickListener(this);
        sbProgress.setOnSeekBarChangeListener(this);
        idIvLove.setOnClickListener(this);
    }

    private void initViewPager() {
        View coverView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_play_page_cover, null);
        albumCoverView = coverView.findViewById(R.id.album_cover_view);
        albumCoverView.initNeedle(AudioPlayer.get().isPlaying());
        mAudioManager = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);

        List<View> viewList = new ArrayList<>();
        viewList.add(coverView);
        vpPlayPage.setAdapter(new WelcomeAdapter(viewList));
    }

    /**
     * 根据音乐来设置界面
     *
     * @param music
     */
    private void onChangeImpl(Music music) {
        if (music == null) {
            return;
        }

        tvTitle.setText(music.getTitle());
        tvArtist.setText(music.getArtist());
        sbProgress.setProgress((int) AudioPlayer.get().getAudioPosition());
        sbProgress.setSecondaryProgress(0);
        sbProgress.setMax((int) music.getDuration());
        lastProgress = 0;
        tvCurrentTime.setText("00:00");
        tvTotalTime.setText(formatTime(music.getDuration()));
        setCoverAndBg(music);
        if (AudioPlayer.get().isPlaying() || AudioPlayer.get().isPreparing()) {
            ivPlay.setSelected(true);
            albumCoverView.start();
        } else {
            ivPlay.setSelected(false);
            albumCoverView.pause();
        }
    }

    private void play() {
        AudioPlayer.get().playPause();
    }

    private void next() {
        AudioPlayer.get().next();
    }

    private void prev() {
        AudioPlayer.get().prev();
    }

    /**
     * 切换音乐的模式
     */
    private void switchPlayMode() {
        PlayModeEnum mode = PlayModeEnum.valueOf((Integer) SPTool.getInstanse().getParam(Keys.PLAY_MODE, 0));
        switch (mode) {
            case LOOP:
                mode = PlayModeEnum.SHUFFLE;
                RxToast.normal("随机播放");
                break;
            case SHUFFLE:
                mode = PlayModeEnum.SINGLE;
                RxToast.normal("单曲循环");
                break;
            case SINGLE:
                mode = PlayModeEnum.LOOP;
                RxToast.normal("列表循环");
                break;
        }
        SPTool.getInstanse().setParam(Keys.PLAY_MODE, mode.value());
        setPlayMode();
    }

    private void onBackPressed() {
        mActivity.onBackPressed();
        ivBack.setEnabled(false);
        Observable.timer(300, TimeUnit.MILLISECONDS)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(aLong -> ivBack.setEnabled(true));
    }

    private void setCoverAndBg(Music music) {
        Bitmap albumCover = BitmapFactory.decodeFile(music.getCoverPath());
        if (albumCover != null) {
            albumCoverView.setCoverBitmap(albumCover);
        }
        ivPlayMusicBg.setImageBitmap(CoverLoader.get().loadBlur(music));
    }

    private String formatTime(long time) {
        return SystemUtils.formatTime("mm:ss", time);
    }

    @Override
    public void onDestroy() {
        AudioPlayer.get().removeOnPlayEventListener(this);
        super.onDestroy();
    }

    @Override
    public void onPlayerStart() {
        ivPlay.setSelected(true);
        albumCoverView.start();
    }

    @Override
    public void onPlayerPause() {
        ivPlay.setSelected(false);
        albumCoverView.pause();
    }

    /**
     * 更新播放进度
     */
    @Override
    public void onPublish(int progress) {
        if (!isDraggingProgress) {
            sbProgress.setProgress(progress);
        }
    }

    @Override
    public void onBufferingUpdate(int percent) {
        sbProgress.setSecondaryProgress(sbProgress.getMax() * 100 / percent);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.iv_mode:
                switchPlayMode();
                break;
            case R.id.iv_play:
                play();
                break;
            case R.id.iv_next:
                next();
                break;
            case R.id.iv_prev:
                prev();
                break;
            case R.id.id_iv_love:
                //是否喜欢
                long userId = Keys.DEF_TOURIST_ID;
                String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
                boolean isTourist = true;
                if (!TextUtils.isEmpty(userInfo)) {
                    isTourist = false;
                    User user = new Gson().fromJson(userInfo, User.class);
                    userId = user.getId() ;
                }
                if (isTourist){
                    idIvLove.setChecked(!idIvLove.isChecked());
                    RxToast.normal("请先登陆！！！");
                    RxActivityTool.skipActivity(mContext, LoginActivity.class);
                    return;
                }
                boolean isChecked = idIvLove.isChecked();
                Log.i(TAG, "onCheckedChanged: isChecked==" + isChecked);
                AudioPlayer audioPlayer = AudioPlayer.get();
                Music playMusic = audioPlayer.getPlayMusic();
                UserMusicList userMusicList = GreenDaoHelper.getInstance().queryUserMusicListsByUserIdMusicListId(userId, Keys.MY_LOVE_MUSIC_LIST_ID);
                List<Long> musicIdList = userMusicList.getMusicIdList();
                if (musicIdList == null) {
                    musicIdList = new ArrayList<>();
                }
                if (isChecked){
                    if (!musicIdList.contains(playMusic.getId())) {
                        musicIdList.add(0, playMusic.getId());
                        userMusicList.setMusicIdList(musicIdList);
                        audioPlayer.addOrUpdate(userMusicList, true);
                    }
                    new SweetAlertDialog(mContext, SweetAlertDialog.SUCCESS_TYPE)
                            .setTitleText("已添加到我喜欢列表！!")
                            .setConfirmText("OK")
                            .setConfirmClickListener(sweetAlertDialog -> sweetAlertDialog.dismiss())
                            .show();
                }else{
                    if (musicIdList.contains(playMusic.getId())) {
                        musicIdList.remove(playMusic.getId());
                        userMusicList.setMusicIdList(musicIdList);
                        audioPlayer.addOrUpdate(userMusicList, true);
                    }
                    new SweetAlertDialog(mContext, SweetAlertDialog.ERROR_TYPE)
                            .setTitleText("已移除我喜欢列表！!")
                            .setConfirmText("OK")
                            .setConfirmClickListener(sweetAlertDialog -> sweetAlertDialog.dismiss())
                            .show();
                }
                break;
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (seekBar == sbProgress) {
            if (Math.abs(progress - lastProgress) >= DateUtils.SECOND_IN_MILLIS) {
                tvCurrentTime.setText(formatTime(progress));
                lastProgress = progress;
            }
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        if (seekBar == sbProgress) {
            isDraggingProgress = true;
        }
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        if (seekBar == sbProgress) {
            isDraggingProgress = false;
            if (AudioPlayer.get().isPlaying() || AudioPlayer.get().isPausing()) {
                int progress = seekBar.getProgress();
                AudioPlayer.get().seekTo(progress);
            } else {
                seekBar.setProgress(0);
            }
        }
    }

    @Override
    public void onChange(Music music) {
        onChangeImpl(music);
    }
}
