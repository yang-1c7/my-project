package com.yjq.musiclz.activity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.utils.ProgressDialogHelper;
import com.yjq.musiclz.utils.SPTool;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class LoginActivity extends BaseActivity implements View.OnClickListener {

    @BindView(R.id.id_et_user)
    EditText idEtUser;
    @BindView(R.id.id_et_pwd)
    EditText idEtPwd;
    @BindView(R.id.id_tv_forget_pwd)
    TextView idTvForgetPwd;
    @BindView(R.id.id_btn_login)
    Button idBtnLogin;
    @BindView(R.id.id_btn_register)
    Button idBtnRegister;

    private ProgressDialogHelper progressDialogHelper;
    private GreenDaoHelper mGreenDaoHelper;

    @Override
    protected void initView() {
        super.initView();
        progressDialogHelper = new ProgressDialogHelper(mContext);
    }

    @Override
    protected int getStatusBarColor() {
        return R.color.white;
    }

    @Override
    protected void initData() {
        mGreenDaoHelper = GreenDaoHelper.getInstance();

    }

    @Override
    protected void initListener() {
        idTvForgetPwd.setOnClickListener(this);
        idBtnLogin.setOnClickListener(this);
        idBtnRegister.setOnClickListener(this);

    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_login;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.id_btn_login:
                String userName = idEtUser.getText().toString().trim();
                String pwd = idEtPwd.getText().toString().trim();
                if (isEtEmpty(userName, "用户名不能为空", idEtUser)) return;
                if (isEtEmpty(pwd, "密码不能为空", idEtPwd)) return;
                progressDialogHelper.show("Login", "正在登陆中...");

                Observable.just(1)
                        .map(integer -> {
                            User user = mGreenDaoHelper.queryUserByUserName(userName);
                            if (user == null) {
                                Log.e(TAG, "数据库没有该用户了");
                                return -1;
                            } else {
                                Log.e(TAG, "数据库有该用户，可以验证密码");
                                return 1;
                            }
                        })
                        .map(integer -> {
                                    if (integer == 1) {
                                        User user = mGreenDaoHelper.queryUserByUserNameAndPwd(userName, pwd);
                                        if (user == null) {
                                            return 2;
                                        }else{
                                            //存储用户信息
                                            SPTool.getInstanse().setParam(Keys.USER_INFO, new Gson().toJson(user));
                                            return 3;
                                        }
                                    }
                                    return integer;
                                }
                        )
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(integer -> {
                            progressDialogHelper.dismiss();
                            switch (integer) {
                                case -1:
                                    //数据库没有该用户
                                    RxToast.normal("该用户不存在！！");
                                    break;
                                case 2:
                                    //登录失败
                                    RxToast.normal("登录失败，请检查用户名和密码！");
                                    break;
                                case 3:
                                    //登陆成功
                                    RxToast.normal("登陆成功");
                                    int userType =  mGreenDaoHelper.queryUserByUserNameAndPwd(userName, pwd).getUserType();
                                    if (userType==1){
                                        RxActivityTool.skipActivity(mContext, AdminMainActivity.class);
                                        RxActivityTool.finishActivity(MainActivity.class);
                                    }else if (userType == 0){
                                        RxActivityTool.skipActivity(mContext, MainActivity.class);
                                    }
                                    finish();
                                    break;
                            }
                        });
                break;
            case R.id.id_btn_register:
                RxActivityTool.skipActivity(mContext, RegisterActivity.class);
                mActivity.finish();
                break;
            case R.id.id_tv_forget_pwd:
                RxActivityTool.skipActivity(mContext, ForgetPwdActivity.class);
                mActivity.finish();
                break;
        }
    }
}
