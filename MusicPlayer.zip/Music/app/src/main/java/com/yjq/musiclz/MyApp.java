package com.yjq.musiclz;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.StrictMode;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.vondear.rxtool.RxTool;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.entry.SheetInfo;
import com.yjq.musiclz.loader.CoverLoader;
import com.yjq.musiclz.service.PlayService;
import com.yjq.musiclz.utils.SPTool;
import com.yjq.musiclz.utils.ScreenUtils;

import java.util.ArrayList;
import java.util.List;

import fm.jiecao.jcvideoplayer_lib.JCVideoPlayerStandard;

/**
 */

public class MyApp extends MultiDexApplication {

    private final List<SheetInfo> mSheetList = new ArrayList<>();

    private static MyApp mMyApp;

    /**
     * application 全局单列
     *
     * @return
     */
    public static MyApp getInstance() {
        return mMyApp;
    }

    private JCVideoPlayerStandard mVideoPlaying;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    public void onCreate() {
        super.onCreate();

        mMyApp = this;

        //初始化greendao的数据库
        GreenDaoHelper.getInstance().initGreenDao(this, Keys.DB_NAME);
        RxTool.init(this);
        SPTool.getInstanse().init(this);
        ScreenUtils.init(this);
        CoverLoader.get().init(this);
        Intent intent = new Intent(this, PlayService.class);
        startService(intent);

        // android 7.0系统解决拍照的问题
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        builder.detectFileUriExposure();

    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);

    }

    public List<SheetInfo> getSheetList() {
        return mSheetList;
    }

    public void setVideoPlaying(JCVideoPlayerStandard videoPlaying) {
        this.mVideoPlaying = videoPlaying;
    }

    public JCVideoPlayerStandard getVideoPlaying() {
        return mVideoPlaying;
    }
}
