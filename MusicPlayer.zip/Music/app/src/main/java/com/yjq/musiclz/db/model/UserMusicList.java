package com.yjq.musiclz.db.model;

import com.yjq.musiclz.db.converter.LongConverter;

import org.greenrobot.greendao.annotation.Convert;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;

import java.util.List;

/**
 * 用户、音乐列表、每个列表中的音乐
 *
 */

@Entity(nameInDb = "tb_user_music_list")
public class UserMusicList {

    @Id(autoincrement = true)
    @Property(nameInDb = "id")
    private Long id;

    //用户id  默认是游客的  游客是-1
    @Property(nameInDb = "user_id")
    private Long userId;

    // 音乐列表的id
    @Property(nameInDb = "music_list_id")
    private Long musicListId;

    //每个音乐列表中的所有音乐id
    @Property(nameInDb = "music_id_list")
    @Convert(columnType = String.class, converter = LongConverter.class)
    private List<Long> musicIdList;

    @Generated(hash = 871607230)
    public UserMusicList(Long id, Long userId, Long musicListId,
            List<Long> musicIdList) {
        this.id = id;
        this.userId = userId;
        this.musicListId = musicListId;
        this.musicIdList = musicIdList;
    }

    @Generated(hash = 2072694651)
    public UserMusicList() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getMusicListId() {
        return musicListId;
    }

    public void setMusicListId(Long musicListId) {
        this.musicListId = musicListId;
    }

    public List<Long> getMusicIdList() {
        return musicIdList;
    }

    public void setMusicIdList(List<Long> musicIdList) {
        this.musicIdList = musicIdList;
    }

    @Override
    public String toString() {
        return "UserMusicList{" +
                "id=" + id +
                ", userId=" + userId +
                ", musicListId=" + musicListId +
                ", musicIdList=" + musicIdList +
                '}';
    }
}
