package com.yjq.musiclz.listener;

import android.view.View;

/**
 */

public interface OnViewClickListener<T> {

    /**
     * view的点击事件
     *
     * @param view
     * @param t
     * @param position
     */
    void onViewClick(View view, T t, int position);
}
