package com.yjq.musiclz.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.github.yuweiguocn.library.greendao.MigrationHelper;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.greendao.CommentDetailBeanDao;
import com.yjq.musiclz.db.greendao.DaoMaster;
import com.yjq.musiclz.db.greendao.DaoSession;
import com.yjq.musiclz.db.greendao.MusicDao;
import com.yjq.musiclz.db.greendao.MusicListDao;
import com.yjq.musiclz.db.greendao.ReplyDetailBeanDao;
import com.yjq.musiclz.db.greendao.UserDao;
import com.yjq.musiclz.db.greendao.UserMusicListDao;
import com.yjq.musiclz.db.greendao.VideoBeanDao;
import com.yjq.musiclz.db.model.CommentDetailBean;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.MusicList;
import com.yjq.musiclz.db.model.ReplyDetailBean;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.db.model.VideoBean;

import java.util.ArrayList;
import java.util.List;


/**
 * greendao的辅助类，包括初始化、获取数据库等
 */

public class GreenDaoHelper {

    private static final String TAG = "GreenDaoHelper";

    private static class Singleton {
        private static final GreenDaoHelper INSTANCE = new GreenDaoHelper();
    }

    public static GreenDaoHelper getInstance() {
        return GreenDaoHelper.Singleton.INSTANCE;
    }

    private GreenDaoHelper() {
    }

    private DaoMaster.DevOpenHelper mDevOpenHelper;
    private SQLiteDatabase mDb;
    private DaoMaster mDaoMaster;
    private DaoSession mDaoSession;

    /**
     * 初始化greenDao
     * 建议放在Application 中进行
     */
    public void initGreenDao(Context context, String dbName) {
        // 通过 DaoMaster 的内部类 DevOpenHelper，你可以得到一个便利的 SQLiteOpenHelper 对象。
        // 可能你已经注意到了，你并不需要去编写「CREATE TABLE」这样的 SQL 语句，因为 greenDAO 已经帮你做了。
        // 注意：默认的 DaoMaster.DevOpenHelper 会在数据库升级时，删除所有的表，意味着这将导致数据的丢失。
        // 所以，在正式的项目中，你还应该做一层封装，来实现数据库的安全升级。

        //greendao默认的DaoMaster.DevOpenHelper
//        mDevOpenHelper = new DaoMaster.DevOpenHelper(context, dbName, null);
        //引用开源库的OpenHelper来更新数据库， 引用开源库，需要我们自定义一个openHelper

        MigrationHelper.DEBUG = true; //如果你想查看日志信息，请将DEBUG设置为true
        mDevOpenHelper = new MySQLiteOpenHelper(context, dbName, null);
        mDb = mDevOpenHelper.getWritableDatabase();
        // 注意：该数据库连接属于 DaoMaster，所以多个 Session 指的是相同的数据库连接。
        mDaoMaster = new DaoMaster(mDb);
        mDaoSession = mDaoMaster.newSession();
    }

    /**
     * 获取greendao的daosession
     *
     * @return
     */
    public DaoSession getDaoSession() {
        return mDaoSession;
    }

    /**
     * 获取greendao的db
     *
     * @return
     */
    public SQLiteDatabase getDb() {
        return mDb;
    }

    /**
     * 获取音乐类的dao
     *
     * @return
     */
    private MusicDao getMusicDao() {
        //初始化获取数据库对应的操作类  dao
        //异步操作  GreenDaoHelper.getInstance().getDaoSession().startAsyncSession()
        return GreenDaoHelper.getInstance().getDaoSession().getMusicDao();
    }

    /**
     * 获取音乐列表的dao
     *
     * @return
     */
    private MusicListDao getMusicListDao() {
        return GreenDaoHelper.getInstance().getDaoSession().getMusicListDao();
    }

    /**
     * 获取用户、音乐列表的dao
     *
     * @return
     */
    private UserMusicListDao getUserMusicListDao() {
        return GreenDaoHelper.getInstance().getDaoSession().getUserMusicListDao();
    }

    /**
     * 获取用户表的dao
     *
     * @return
     */
    private UserDao getUserDao() {
        return GreenDaoHelper.getInstance().getDaoSession().getUserDao();
    }

    /**
     * video表的dao
     *
     * @return
     */
    private VideoBeanDao getVideoBeanDao() {
        return GreenDaoHelper.getInstance().getDaoSession().getVideoBeanDao();
    }


    /**
     * 评论表的dao
     *
     * @return
     */
    private CommentDetailBeanDao getCommentDetailBeanDao() {
        return GreenDaoHelper.getInstance().getDaoSession().getCommentDetailBeanDao();
    }

    /**
     * 回复表的dao
     *
     * @return
     */
    private ReplyDetailBeanDao getReplyDetailBeanDao() {
        return GreenDaoHelper.getInstance().getDaoSession().getReplyDetailBeanDao();
    }

    /**
     * 音乐表相关的操作
     * -------------------------------------------------------start----------------------------------------------------
     */

    /**
     * 查询全部音乐
     *
     * @return
     */
    public List<Music> queryMusics() {
        return getMusicDao().queryBuilder().list();
    }

    /**
     * 查询数据库中的本地全部音乐或者网络音乐
     *
     * @return
     */
    public List<Music> queryMusicsByType(int type) {
        return getMusicDao().queryBuilder().where(MusicDao.Properties.Type.eq(type))
                .list();
    }

    /**
     * 查询该用户默认列表音乐
     *
     * @return
     */
    public List<Music> queryMusicsByUserIdMusicListId(long userId, long musicListId) {
        List<Music> musicLists = new ArrayList<>();
        Log.i(TAG, "queryMusicsByUserIdMusicListId: userId===" + userId +"==musicListId==" + musicListId);
        List<Long> musicIdList = queryUserMusicList(userId, musicListId).getMusicIdList();
        if (musicIdList == null) {
            return musicLists;
        }
        Log.i(TAG, "queryMusicsByUserIdMusicListId: musicIdList==" + musicIdList.toString());
        for (Long musicId : musicIdList ) {
            if (musicId != null) {
                Log.i(TAG, "queryMusicsByUserIdMusicListId: musicId==" + musicId);
                musicLists.add(queryMusicById(musicId));
            }
        }
        return musicLists;
    }

    /**
     * 获取所有音乐的数量
     *
     * @return
     */
    public long queryMusicCount(){
        return getMusicDao().queryBuilder().count();
    }

    /**
     * 根据music数据库的id  来查询对应的音乐
     *
     * @param musicId
     * @return
     */
    public Music queryMusicById(long musicId) {
        return getMusicDao().queryBuilder().where(MusicDao.Properties.Id.eq(musicId))
                .build().unique();
    }


    /**
     * 根据music的songid  来查询对应的音乐
     *
     * @param musicSongId
     * @return
     */
    public Music queryMusicByMusicSongId(String musicSongId) {
        return getMusicDao().queryBuilder().where(MusicDao.Properties.SongId.eq(musicSongId))
                .build().unique();
    }

    /**
     * 新增音乐的列表
     *
     * @param musics
     */
    public void insertMusics(List<Music> musics) {
        getMusicDao().insertInTx(musics);
    }

    /**
     * 添加新的音乐
     *
     * @param music
     */
    public void insertMusic(Music music) {
        getMusicDao().insertInTx(music);
    }

    /**
     * 查询新增的music
     *
     * @return
     */
    public Music queryFristMusic() {
        return getMusicDao().queryBuilder().limit(1)
                .build().unique();
    }

    /**
     * 查询新增的music
     *
     * @return
     */
    public Music queryLastMusic() {
        return getMusicDao().queryBuilder().limit(1).orderDesc(MusicDao.Properties.Id)
                .build().unique();
    }

    /**
     *
     *
     * @param music
     */
    public int updateMusic(Music music){
        getMusicDao().update(music);
        return 1;
    }


    /**
     * 音乐表相关的操作
     * -------------------------------------------------------end----------------------------------------------------
     */


    //***********************************************************************************************************************


    /**
     * 音乐列表相关的操作
     * -------------------------------------------------------start----------------------------------------------------
     */


    /**
     * 查询默认列表
     *
     * @return
     */
    public MusicList queryDefMusicList() {
        return getMusicListDao().queryBuilder().where(MusicListDao.Properties.Id.eq(Keys.DEF_MUSIC_LIST_ID),
                MusicListDao.Properties.MusicListName.eq("默认列表"))
                .build().unique();
    }

    /**
     * 根据列表id查询列表
     *
     * @return
     */
    public MusicList queryMusicList(long musicListId) {
        return getMusicListDao().queryBuilder().where(MusicListDao.Properties.Id.eq(musicListId))
                .build().unique();
    }

    /**
     * 根据列表名称查询是否存在该列表
     *
     * @return
     */
    public MusicList queryMusicList(String musicListName) {
        return getMusicListDao().queryBuilder().where(MusicListDao.Properties.MusicListName.eq(musicListName))
                .build().unique();
    }

    /**
     * 查询播放列表
     *
     * @return
     */
    public List<MusicList> queryMusicLists() {
        return getMusicListDao().queryBuilder().list();
    }

    /**
     * 新增音乐列表
     *
     * @param musicList
     */
    public void insertMusicList(MusicList musicList) {
        getMusicListDao().insertInTx(musicList);
    }

    /**
     * 删除音乐列表
     *
     * @param musicListId
     */
    public void deleteMusicListById(long musicListId){
        getMusicListDao().delete(queryMusicList(musicListId));
    }

    /**
     * 音乐列表相关的操作
     * -------------------------------------------------------end----------------------------------------------------
     */

    //***********************************************************************************************************************

    /**
     * 音乐列表 用户表 的中间表相关的操作
     * -------------------------------------------------------start----------------------------------------------------
     */

    /**
     * 根据用户id查询默认列表
     *
     * @param userId
     * @return
     */
    public UserMusicList queryUserDefMusicList(long userId) {
        return getUserMusicListDao().queryBuilder()
                .where(UserMusicListDao.Properties.UserId.eq(userId), UserMusicListDao.Properties.MusicListId.eq(Keys.DEF_MUSIC_LIST_ID))
                .build()
                .unique();
    }

    /**
     * 根据用户id和列表id查询唯一列表
     *
     * @param userId
     * @return
     */
    public UserMusicList queryUserMusicList(long userId, long musicListId) {
        return getUserMusicListDao().queryBuilder()
                .where(UserMusicListDao.Properties.UserId.eq(userId), UserMusicListDao.Properties.MusicListId.eq(musicListId))
                .build()
                .unique();
    }

    /**
     * 查询全部音乐中间表
     *
     * @return
     */
    public List<UserMusicList> queryUserMusicLists() {
        return getUserMusicListDao().queryBuilder().list();
    }

    /**
     * 根据用户id查询改用下的全部音乐中间表
     *
     * @return
     */
    public List<UserMusicList> queryUserMusicListsByUserId(long userId) {
        return getUserMusicListDao().queryBuilder().where(UserMusicListDao.Properties.UserId.eq(userId)).list();
    }

    /**
     * 根据用户id查询该用户下下的全部音乐中间表  除了 我喜欢、本地播放
     *
     * @return
     */
    public List<UserMusicList> queryUserMusicListsNotLove(long userId) {
        return getUserMusicListDao().queryBuilder().where(UserMusicListDao.Properties.UserId.eq(userId), UserMusicListDao.Properties.MusicListId.notEq(Keys.MY_LOVE_MUSIC_LIST_ID)
                , UserMusicListDao.Properties.MusicListId.notEq(Keys.RECENT_MUSIC_LIST_ID)).list();
    }

    /**
     * 查询全部音乐中间表
     *
     * @return
     */
    public UserMusicList queryUserMusicListsByUserIdMusicListId(long userId, long musicListId) {
        return getUserMusicListDao().queryBuilder().where(UserMusicListDao.Properties.UserId.eq(userId), UserMusicListDao.Properties.MusicListId.eq(musicListId)).build().unique();
    }

    /**
     * 新增音乐列表、用户表的中间表
     *
     * @param userMusicList
     */
    public void insertUserMusicList(UserMusicList userMusicList) {
        getUserMusicListDao().insertInTx(userMusicList);
    }

    /**
     * 修改音乐列表、用户表的中间表
     *
     * @param userMusicList
     */
    public void updateUserMusicList(UserMusicList userMusicList) {
        getUserMusicListDao().updateInTx(userMusicList);
    }

    /**
     * 删除音乐列表 用户表
     *
     * @param musicListId
     * @param userId
     */
    public void deleteUserMusicListByMusicListId(long musicListId, long userId){
        getUserMusicListDao().delete(queryUserMusicList(userId, musicListId));
    }


    /**
     * 音音乐列表 用户表 的中间表的相关的操作
     * -------------------------------------------------------end----------------------------------------------------
     */

    //***************************************************************************************************************

    /**
     * 用户表 的相关的操作
     * -------------------------------------------------------start----------------------------------------------------
     */

    public void insertUser(User user) {
        getUserDao().insertInTx(user);
    }

    /**
     * 根据用户名查找用户
     *
     * @param userName
     * @return
     */
    public User queryUserByUserName(String userName) {
        return getUserDao().queryBuilder().where(UserDao.Properties.UserName.eq(userName))
                .build().unique();
    }

    /**
     * 根据用户id查找用户
     *
     * @param userId
     * @return
     */
    public User queryUserByUserId(long userId) {
        return getUserDao().queryBuilder().where(UserDao.Properties.Id.eq(userId))
                .build().unique();
    }

    /**
     * 获取所有的用户
     *
     * @return
     */
    public List<User> queryUsers() {
        List<User> userList = getUserDao().queryBuilder().where(UserDao.Properties.UserType.eq(0)).list();
        return (userList == null) ? new ArrayList<>() : userList;
    }


    /**
     * 根据用户密保查找用户
     *
     * @param userName
     * @param userPwdHelp
     * @return
     */
    public User queryUserByNamePwdHelp(String userName, String userPwdHelp) {
        return getUserDao().queryBuilder().where(UserDao.Properties.UserPwdHelp.eq(userPwdHelp), UserDao.Properties.UserName.eq(userName))
                .build().unique();
    }

    /**
     * 根据用户名和密码查找 用户
     *
     * @param userName
     * @param userPwd
     * @return
     */
    public User queryUserByUserNameAndPwd(String userName, String userPwd){
        return getUserDao().queryBuilder().where(UserDao.Properties.UserName.eq(userName), UserDao.Properties.UserPwd.eq(userPwd))
                .build().unique();
    }

    /**
     * 更新用户信息
     *
     * @param user
     */
    public void updateUser(User user){
        getUserDao().update(user);
    }


    /**
     * 用户表 的相关的操作
     * -------------------------------------------------------end----------------------------------------------------
     */


    /**
     * 视频 评论列表的相关的操作
     * -------------------------------------------------------start----------------------------------------------------
     */

    /**
     * 添加视频列表
     *
     * @param videoBean
     */
    public void insertVideo(VideoBean videoBean) {
        getVideoBeanDao().insertInTx(videoBean);
    }

    public void insertVideoList(List<VideoBean> videoBeanList){
        getVideoBeanDao().insertInTx(videoBeanList);
    }

    public List<VideoBean> queryVideoList() {
        return getVideoBeanDao().queryBuilder().list();
    }

    /**
     * 根据video的id 获取videoBean
     *
     * @param videoId
     * @return
     */
    public VideoBean queryVideoById(long videoId){
        return getVideoBeanDao().queryBuilder().where(VideoBeanDao.Properties.Id.eq(videoId))
                .build().unique();
    }


    /**
     * 添加评论列表
     *
     * @param commentDetailBean
     */
    public void insertCommentDetail(CommentDetailBean commentDetailBean) {
        getCommentDetailBeanDao().insertInTx(commentDetailBean);
    }

    public void insertCommentDetailList(List<CommentDetailBean> commentDetailBeanList){
        getCommentDetailBeanDao().insertInTx(commentDetailBeanList);
    }


    /**
     * 添加回复列表
     *
     * @param replyDetailBean
     */
    public void insertReplyDetail(ReplyDetailBean replyDetailBean) {
        getReplyDetailBeanDao().insertInTx(replyDetailBean);
    }


    public void insertReplyDetailList(List<ReplyDetailBean> replyDetailBeanList){
        getReplyDetailBeanDao().insertInTx(replyDetailBeanList);
    }

    public List<ReplyDetailBean> queryReplyListByCommentId(long commentId){
        return getReplyDetailBeanDao().queryBuilder().where(ReplyDetailBeanDao.Properties.CommentId.eq(commentId)).list();
    }
}
