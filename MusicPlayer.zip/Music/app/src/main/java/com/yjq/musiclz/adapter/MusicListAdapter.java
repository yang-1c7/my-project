package com.yjq.musiclz.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TextView;

import com.vondear.rxtool.RxImageTool;
import com.yjq.musiclz.R;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.entry.MusicListBean;
import com.yjq.musiclz.listener.OnGroupLongListener;
import com.yjq.musiclz.listener.OnViewClickListener;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.FileUtils;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * 播放列表的适配器
 */
public class MusicListAdapter extends BaseExpandableListAdapter {

    private static final String TAG = "MusicListAdapter";

    private boolean isPlaylist;
    //分组的数据
    private List<MusicListBean> mGroupDatas;
    private Context mContext;
    private OnViewClickListener listener;
    private OnGroupLongListener mOnGroupLongListener;

    public void setOnViewClickListener(OnViewClickListener listener) {
        this.listener = listener;
    }

    public void setOnGroupLongListener(OnGroupLongListener onGroupLongListener) {
        this.mOnGroupLongListener = onGroupLongListener;
    }

    public MusicListAdapter(List<MusicListBean> groupDatas, Context mContext) {
        this.mGroupDatas = groupDatas;
        this.mContext = mContext;
    }

    @Override
    public int getGroupCount() {
        return mGroupDatas.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return mGroupDatas.get(groupPosition).getMusicLists().size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return mGroupDatas.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return mGroupDatas.get(groupPosition).getMusicLists().get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        MusicListGroupViewHolder groupHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_exlist_group_music_list, parent, false);
            groupHolder = new MusicListGroupViewHolder(convertView);
            convertView.setTag(groupHolder);
        } else {
            groupHolder = (MusicListGroupViewHolder) convertView.getTag();
        }
        MusicListBean musicListBean = mGroupDatas.get(groupPosition);
        groupHolder.idTvMusicListName.setText(musicListBean.getMusicList().getMusicListName());
        groupHolder.idTvMusicListNum.setText("[ " + musicListBean.getMusicLists().size() + " ]");
        groupHolder.idClMusicList.setOnLongClickListener(view -> {
            if (mOnGroupLongListener != null) {
                mOnGroupLongListener.onGroupLong(musicListBean, groupPosition);
            }
            return true;
        });

        groupHolder.idClMusicList.setOnClickListener(view -> {
            ExpandableListView expandableListView = (ExpandableListView) parent;
            if (expandableListView.isGroupExpanded(groupPosition)) {
                expandableListView.collapseGroup(groupPosition);
            } else{
                expandableListView.expandGroup(groupPosition);
            }
        });
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        MusicListSubViewHolder subHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.item_music_list, parent, false);
            subHolder = new MusicListSubViewHolder(convertView);
            convertView.setTag(subHolder);
        } else {
            subHolder = (MusicListSubViewHolder) convertView.getTag();
        }
        List<Music> musicList = mGroupDatas.get(groupPosition).getMusicLists();
        subHolder.vPlaying.setVisibility((isPlaylist && childPosition == AudioPlayer.get().getPlayPosition()) ? View.VISIBLE : View.INVISIBLE);
        Music music = musicList.get(childPosition);
        String coverPath = music.getCoverPath();
        String coverPathTag = (String) subHolder.ivCover.getTag();
        if (coverPathTag != null) {
            // 通过 tag 来防止图片错位
            if (coverPathTag.equals(coverPath)) {
                subHolder.ivCover.setImageBitmap(BitmapFactory.decodeFile(coverPath));
            }else{
                subHolder.ivCover.setImageBitmap(RxImageTool.getBitmap(R.mipmap.default_cover));
            }
        }else if (coverPath != null ){
            subHolder.ivCover.setTag(coverPath);
            subHolder.ivCover.setImageBitmap(BitmapFactory.decodeFile(coverPath));
        }
        subHolder.tvTitle.setText(music.getTitle());
        String artist = FileUtils.getArtistAndAlbum(music.getArtist(), music.getAlbum());
        subHolder.tvArtist.setText(artist);
        subHolder.ivMore.setOnClickListener(v -> {
            if (listener != null) {
                listener.onViewClick(subHolder.ivMore, mGroupDatas.get(groupPosition), childPosition);
            }
        });
        subHolder.vDivider.setVisibility(isShowDivider(childPosition, musicList.size()) ? View.VISIBLE : View.GONE);

        return convertView;
    }

    private boolean isShowDivider(int position, int subSize) {
        return position != subSize - 1;
    }

    public void setIsPlaylist(boolean isPlaylist) {
        this.isPlaylist = isPlaylist;
    }

    //设置子列表是否可选中
    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    static class MusicListGroupViewHolder {
        @BindView(R.id.id_tv_music_list_name)
        TextView idTvMusicListName;
        @BindView(R.id.id_tv_music_list_num)
        TextView idTvMusicListNum;
        @BindView(R.id.id_cl_music_list)
        ConstraintLayout idClMusicList;

        public MusicListGroupViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

    static class MusicListSubViewHolder {

        @BindView(R.id.v_playing)
        View vPlaying;
        @BindView(R.id.iv_cover)
        ImageView ivCover;
        @BindView(R.id.tv_title)
        TextView tvTitle;
        @BindView(R.id.tv_artist)
        TextView tvArtist;
        @BindView(R.id.iv_more)
        ImageView ivMore;
        @BindView(R.id.v_divider)
        View vDivider;

        public MusicListSubViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

}
