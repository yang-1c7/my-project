package com.yjq.musiclz.fragment;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import com.vondear.rxtool.RxActivityTool;
import com.yjq.musiclz.MyApp;
import com.yjq.musiclz.R;
import com.yjq.musiclz.activity.OnlineMusicActivity;
import com.yjq.musiclz.adapter.SheetAdapter;
import com.yjq.musiclz.base.BaseFragment;
import com.yjq.musiclz.constants.Extras;
import com.yjq.musiclz.entry.SheetInfo;

import java.util.List;

import butterknife.BindView;

/**
 * 我的  fragment
 */

public class OnlineMusicListFragment extends BaseFragment {


    @BindView(R.id.id_lv_online_music)
    ListView idLvOnlineMusic;
    @BindView(R.id.id_tv_searching)
    TextView idTvSearching;
    private List<SheetInfo> mSongLists;

    @Override
    protected int getLayoutResId() {
        return R.layout.fragment_online_music_list;
    }

    @Override
    protected void initData() {
        super.initData();
        mSongLists = MyApp.getInstance().getSheetList();
        if (mSongLists.size()==0) {
            String[] titles = getResources().getStringArray(R.array.online_music_list_title);
            String[] types = getResources().getStringArray(R.array.online_music_list_type);
            for (int i = 0; i < titles.length; i++) {
                SheetInfo info = new SheetInfo();
                info.setTitle(titles[i]);
                info.setType(types[i]);
                mSongLists.add(info);
            }
        }
        Log.i(TAG, "initData: mSongLists ==" + mSongLists.toString());
        SheetAdapter adapter = new SheetAdapter(mSongLists);
        idLvOnlineMusic.setAdapter(adapter);
        idLvOnlineMusic.setOnItemClickListener((adapterView, view, position, l) -> {
            SheetInfo sheetInfo = mSongLists.get(position);
            Bundle bundle = new Bundle();
            bundle.putSerializable(Extras.MUSIC_LIST_TYPE, sheetInfo);
            RxActivityTool.skipActivity(mContext, OnlineMusicActivity.class, bundle);
        });
    }

}
