package com.yjq.musiclz.entry;

/**
 */

public class MineTypeBean {

    /**
     * 我的里面的类型 资源图片
     */
    private int imgResId;

    /**
     * 我的里面的类型 名称
     *
     */
    private String typeName;

    /**
     * 我的里面的类型  包含的子条目
     *
     */
    private int typeNum;


    public int getImgResId() {
        return imgResId;
    }

    public void setImgResId(int imgResId) {
        this.imgResId = imgResId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public int getTypeNum() {
        return typeNum;
    }

    public void setTypeNum(int typeNum) {
        this.typeNum = typeNum;
    }


    @Override
    public String toString() {
        return "MineTypeBean{" +
                "imgResId=" + imgResId +
                ", typeName='" + typeName + '\'' +
                ", typeNum=" + typeNum +
                '}';
    }
}
