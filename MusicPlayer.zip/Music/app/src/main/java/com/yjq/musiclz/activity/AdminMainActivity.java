package com.yjq.musiclz.activity;

import android.graphics.Color;
import android.os.Build;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.adapter.UserListAdapter;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.utils.SPTool;
import com.yjq.musiclz.utils.ScreenUtils;

import java.lang.reflect.Method;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class AdminMainActivity extends BaseActivity {

    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;
    @BindView(R.id.id_ll_home_title)
    LinearLayout idLlHomeTitle;
    @BindView(R.id.id_rv_admin_main)
    RecyclerView idRvAdminMain;
    @BindView(R.id.id_tv_no_data)
    TextView idTvNoData;
    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;

    @Override
    protected int getStatusBarColor() {
        setSystemBarTransparent();
        return -1;
    }

    private void setSystemBarTransparent() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // LOLLIPOP解决方案
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            // KITKAT解决方案
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    @Override
    protected void initData() {
        Observable.just(GreenDaoHelper.getInstance().queryUsers())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(users -> {
                    if (users.size() == 0) {
                        idRvAdminMain.setVisibility(View.GONE);
                        idTvNoData.setVisibility(View.VISIBLE);
                    } else {
                        Log.i(TAG, "initData: user==" + users.size());
                        idRvAdminMain.setLayoutManager(new LinearLayoutManager(mContext));
                        UserListAdapter userListAdapter = new UserListAdapter(mContext, users);
                        userListAdapter.setOnViewClickListener((view, user, position) -> {
                            View dialogView = LayoutInflater.from(mContext).inflate(R.layout.dialog_user_info, null, false);
                            TextView idEtUser = dialogView.findViewById(R.id.id_et_user);
                            TextView idEtPwdHelp = dialogView.findViewById(R.id.id_et_pwd_help);
                            TextView  idEtMail = dialogView.findViewById(R.id.id_et_mail);
                            idEtUser.setText(user.getUserName());
                            idEtPwdHelp.setText(user.getUserPwdHelp());
                            idEtMail.setText(user.getUserEmail());
                            AlertDialog alertDialog = new AlertDialog.Builder(mContext)
                                    .setView(dialogView)
                                    .setPositiveButton("确定", (dialog, which) -> dialog.dismiss())
                                    .create();
                            alertDialog.setCanceledOnTouchOutside(false);
                            alertDialog.show();
                        });

                        userListAdapter.setOnViewLongListener((view, user, position) -> {
                            View dialogView = LayoutInflater.from(mContext).inflate(R.layout.dialog_add_music_list, null, false);
                            TextInputLayout idTilAdd = dialogView.findViewById(R.id.id_til_add_music_list);
                            EditText idEtAddMusicListName = dialogView.findViewById(R.id.id_et_add_music_list);
                            idTilAdd.setHint("请输入新密码");
                            idEtAddMusicListName.setHint("请输入新密码");
                            AlertDialog alertDialog = new AlertDialog.Builder(mContext)
                                    .setView(dialogView)
                                    .setPositiveButton("重置", (dialog, which) -> {
                                        String pwd = idEtAddMusicListName.getText().toString().trim();
                                        if (isEtEmpty(pwd, "密码不能为空", idEtAddMusicListName)) return;
                                        user.setUserPwd(pwd);
                                        GreenDaoHelper.getInstance().updateUser(user);
                                        RxToast.normal("重置成功");
                                        dialog.dismiss();
                                    }).setNegativeButton("放弃", null)
                                    .create();
                            alertDialog.setCanceledOnTouchOutside(false);
                            alertDialog.show();
                        });
                        idRvAdminMain.setAdapter(userListAdapter);
                        idRvAdminMain.setVisibility(View.VISIBLE);
                        idTvNoData.setVisibility(View.GONE);
                    }
                });

    }

    @Override
    protected void initView() {
        super.initView();
        idTlMain.setPadding(0, ScreenUtils.getStatusBarHeight(), 0, 0);
        setTlTitle(idTlMain, idTvTlTitle, "管理员");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_tl_admin_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * 利用反射机制调用MenuBuilder的setOptionalIconsVisible方法设置mOptionalIconsVisible为true，
     * 给菜单设置图标时才可见 让菜单同时显示图标和文字
     */
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        if (menu != null) {
            if (menu.getClass().getSimpleName().equalsIgnoreCase("MenuBuilder")) {
                try {
                    Method method = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);
                    method.setAccessible(true);
                    method.invoke(menu, true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return super.onMenuOpened(featureId, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_person:
                //个人信息
                RxActivityTool.skipActivity(mContext, PersonActivity.class);
                return true;
            case R.id.action_forget_pwd:
                //找回密码
                RxActivityTool.skipActivity(mContext, ForgetPwdActivity.class);
                return true;
            case R.id.action_exit:
                //退出应用
                SPTool.getInstanse().clear();
                mActivity.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

        if (!RxToast.doubleClickExit()) {
            return;
        }

        super.onBackPressed();
    }


    @Override
    protected void initListener() {
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_admin_main;
    }

}
