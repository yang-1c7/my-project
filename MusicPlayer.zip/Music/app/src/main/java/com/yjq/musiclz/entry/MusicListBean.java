package com.yjq.musiclz.entry;

import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.MusicList;

import java.util.List;

/**
 */

public class MusicListBean {

    /**
     * 用户的id
     *
     */
    private Long userId;

    /**
     * 播放列表 对象
     *
     */
    private MusicList musicList;

    /**
     * 播放列表中的音乐
     *
     */
    private List<Music> musicLists;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public MusicList getMusicList() {
        return musicList;
    }

    public void setMusicList(MusicList musicList) {
        this.musicList = musicList;
    }

    public List<Music> getMusicLists() {
        return musicLists;
    }

    public void setMusicLists(List<Music> musicLists) {
        this.musicLists = musicLists;
    }

    @Override
    public String toString() {
        return "MusicListBean{" +
                "userId=" + userId +
                ", musicList=" + musicList +
                ", musicLists=" + musicLists +
                '}';
    }
}
