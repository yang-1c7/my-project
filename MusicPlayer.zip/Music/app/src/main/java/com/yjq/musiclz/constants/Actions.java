package com.yjq.musiclz.constants;

/**
 * Actions
 */
public interface Actions {
    String VOLUME_CHANGED_ACTION = "android.media.VOLUME_CHANGED_ACTION";
    String ACTION_STOP = "me.wcy.music.ACTION_STOP";
}
