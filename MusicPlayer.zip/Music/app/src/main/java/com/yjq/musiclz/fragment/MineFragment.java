package com.yjq.musiclz.fragment;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.vondear.rxtool.RxActivityTool;
import com.yjq.musiclz.R;
import com.yjq.musiclz.activity.LocalMusicListActivity;
import com.yjq.musiclz.activity.MyLoveMusicListActivity;
import com.yjq.musiclz.activity.OnlineMusicActivity;
import com.yjq.musiclz.activity.RecentMusicListActivity;
import com.yjq.musiclz.adapter.MineTypeAdapter;
import com.yjq.musiclz.base.BaseFragment;
import com.yjq.musiclz.constants.Extras;
import com.yjq.musiclz.entry.MineTypeBean;
import com.yjq.musiclz.entry.OnlineMusic;
import com.yjq.musiclz.entry.OnlineMusicList;
import com.yjq.musiclz.entry.SheetInfo;
import com.yjq.musiclz.http.HttpCallback;
import com.yjq.musiclz.http.HttpClient;
import com.yjq.musiclz.loader.GlideImageLoader;
import com.youth.banner.Banner;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * 我的  fragment
 */

public class MineFragment extends BaseFragment {


    @BindView(R.id.id_b_mine)
    Banner idBMine;
    @BindView(R.id.id_rv_mine)
    RecyclerView idRvMine;
    @BindView(R.id.tv_profile)
    TextView tvProfile;
    @BindView(R.id.iv_cover)
    ImageView ivCover;
    @BindView(R.id.tv_music_1)
    TextView tvMusic1;
    @BindView(R.id.tv_music_2)
    TextView tvMusic2;
    @BindView(R.id.tv_music_3)
    TextView tvMusic3;
    @BindView(R.id.id_ll_sheet)
    LinearLayout idLlSheet;

    @Override
    protected int getLayoutResId() {
        return R.layout.fragment_mine;
    }

    @Override
    protected void initView() {
        super.initView();

    }

    @Override
    protected void initData() {
        super.initData();
        //本地图片数据（资源文件）
        List<Integer> list = new ArrayList<>();
        list.add(R.drawable.bg_banner_01);
        list.add(R.drawable.bg_banner_02);
        list.add(R.drawable.bg_banner_03);
        list.add(R.drawable.bg_banner_04);
        idBMine.setImages(list)
                .setImageLoader(new GlideImageLoader())
                .start();

        Observable.just(1)
                .map(integer -> {

                    String[] names = mContext.getResources().getStringArray(R.array.text_mine_type);
                    TypedArray a = mContext.getResources().obtainTypedArray(R.array.int_text_type);
                    List<MineTypeBean> mineTypeBeanList = new ArrayList<>();
                    for (int i = 0; i < names.length; i++) {
                        MineTypeBean mineTypeBean = new MineTypeBean();
                        mineTypeBean.setImgResId(a.getResourceId(i, 0));
                        mineTypeBean.setTypeName(names[i]);
                        mineTypeBeanList.add(mineTypeBean);
                    }
                    return mineTypeBeanList;
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(mineTypeBeanList -> {
                    idRvMine.setLayoutManager(new GridLayoutManager(mContext, 3));
                    MineTypeAdapter mineTypeAdapter = new MineTypeAdapter(mContext, mineTypeBeanList);
                    mineTypeAdapter.setOnViewClickListener((view, mineTypeBean, position) -> {
                        Log.i(TAG, "initData: mineTypeBean==" + mineTypeBean.toString());
                        switch (mineTypeBean.getTypeName()) {
                            case "本地音乐":
                                RxActivityTool.skipActivity(mContext, LocalMusicListActivity.class);
                                break;
                            case "我喜欢":
                                RxActivityTool.skipActivity(mContext, MyLoveMusicListActivity.class);
                                break;
                            case "最近播放":
                                RxActivityTool.skipActivity(mContext, RecentMusicListActivity.class);
                                break;
                        }
                    });
                    idRvMine.setAdapter(mineTypeAdapter);
                });

        //叱咤歌曲榜  7
        tvProfile.setText("推荐歌曲榜");

        ivCover.setImageResource(R.drawable.default_cover);
        tvMusic1.setText("1.加载中…");
        tvMusic2.setText("2.加载中…");
        tvMusic3.setText("3.加载中…");

        SheetInfo info = new SheetInfo();
        info.setTitle("叱咤歌曲榜");
        info.setType("7");

        HttpClient.getSongListInfo(info.getType(), 3, 0, new HttpCallback<OnlineMusicList>() {
            @Override
            public void onSuccess(OnlineMusicList response) {
                if (response == null || response.getSong_list() == null) {
                    return;
                }
                parse(response, info);
                tvMusic1.setText(info.getMusic1());
                tvMusic2.setText(info.getMusic2());
                tvMusic3.setText(info.getMusic3());
                Glide.with(mContext)
                        .load(info.getCoverUrl())
                        .placeholder(R.drawable.default_cover)
                        .error(R.drawable.default_cover)
                        .into(ivCover);
            }

            @Override
            public void onFail(Exception e) {
            }
        });

        idLlSheet.setOnClickListener(view -> {
            Bundle bundle = new Bundle();
            bundle.putSerializable(Extras.MUSIC_LIST_TYPE, info);
            RxActivityTool.skipActivity(mContext, OnlineMusicActivity.class, bundle);
        });
    }

    private void parse(OnlineMusicList response, SheetInfo sheetInfo) {
        List<OnlineMusic> onlineMusics = response.getSong_list();
        sheetInfo.setCoverUrl(response.getBillboard().getPic_s260());
        if (onlineMusics.size() >= 1) {
            sheetInfo.setMusic1(mContext.getString(R.string.song_list_item_title_1,
                    onlineMusics.get(0).getTitle(), onlineMusics.get(0).getArtist_name()));
        } else {
            sheetInfo.setMusic1("");
        }
        if (onlineMusics.size() >= 2) {
            sheetInfo.setMusic2(mContext.getString(R.string.song_list_item_title_2,
                    onlineMusics.get(1).getTitle(), onlineMusics.get(1).getArtist_name()));
        } else {
            sheetInfo.setMusic2("");
        }
        if (onlineMusics.size() >= 3) {
            sheetInfo.setMusic3(mContext.getString(R.string.song_list_item_title_3,
                    onlineMusics.get(2).getTitle(), onlineMusics.get(2).getArtist_name()));
        } else {
            sheetInfo.setMusic3("");
        }
    }

}
