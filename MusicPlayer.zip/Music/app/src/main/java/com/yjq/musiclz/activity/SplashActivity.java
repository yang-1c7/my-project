package com.yjq.musiclz.activity;

import android.Manifest;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.rd.PageIndicatorView;
import com.rd.animation.type.AnimationType;
import com.rd.draw.data.Orientation;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.RxBarTool;
import com.yjq.musiclz.R;
import com.yjq.musiclz.adapter.WelcomeAdapter;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.utils.SPTool;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * 引导页
 */
public class SplashActivity extends BaseActivity {

    @BindView(R.id.id_vp)
    ViewPager idVp;
    @BindView(R.id.id_piv)
    PageIndicatorView idPiv;
    private List<View> guideViewList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void initParam(Bundle savedInstanceState) {
        super.initParam(savedInstanceState);
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            User user = new Gson().fromJson(userInfo, User.class);
            Log.i(TAG, "initParam: user===" + user.toString());
            if (user.getUserType()==1){
                RxActivityTool.skipActivity(mContext, AdminMainActivity.class);
                mActivity.finish();
            }else if (user.getUserType()==0){
                toMain();
            }
        }
    }

    @Override
    protected void initView() {
        RxBarTool.FLAG_FULLSCREEN(mActivity);
        idPiv.setAnimationType(AnimationType.THIN_WORM);
        idPiv.setOrientation(Orientation.HORIZONTAL);
    }

    @Override
    protected void initData() {
        guideViewList = new ArrayList<>();
        TypedArray typedArray = mContext.getResources().obtainTypedArray(R.array.int_welcome);
        final int len = typedArray.length();
        for (int i = 0; i < len; i++) {
            View view = LayoutInflater.from(mContext).inflate(R.layout.item_vp_welcome, null);
            ((ImageView) view.findViewById(R.id.id_iv_welecome)).setImageResource(typedArray.getResourceId(i, 0));
            TextView idTvEnter = view.findViewById(R.id.id_tv_enter);
            idTvEnter.setVisibility(View.GONE);
            if (i == len - 1) {
                idTvEnter.setVisibility(View.VISIBLE);
                idTvEnter.setOnClickListener(view1 -> toMain());
            }
            guideViewList.add(view);
        }
        idPiv.setCount(len);
        WelcomeAdapter welcomeAdapter = new WelcomeAdapter(guideViewList);
        idVp.setAdapter(welcomeAdapter);
        idVp.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == len - 1) {
                    idPiv.setVisibility(View.GONE);
                } else {
                    idPiv.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        idVp.setCurrentItem(0);
        //开始检查需要的权限
        checkPermission(Manifest.permission.CAMERA,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE);
    }

    private void toMain() {
        RxActivityTool.skipActivity(mContext, MainActivity.class);
        mActivity.finish();
    }

    @Override
    protected void initListener() {

    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_splash;
    }

}
