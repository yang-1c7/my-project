package com.yjq.musiclz.activity;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.MyApp;
import com.yjq.musiclz.R;
import com.yjq.musiclz.adapter.FragmentAdapter;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.MusicList;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.fragment.FindMusicFragment;
import com.yjq.musiclz.fragment.MineFragment;
import com.yjq.musiclz.fragment.OnlineMusicListFragment;
import com.yjq.musiclz.fragment.PlayMusicFragment;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.SPTool;
import com.yjq.musiclz.utils.ScreenUtils;
import com.yjq.musiclz.view.ControlPlay;

import butterknife.BindView;
import de.hdodenhof.circleimageview.CircleImageView;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayer;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends BaseActivity implements View.OnClickListener, ViewPager.OnPageChangeListener {

    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;
    @BindView(R.id.id_abl_main)
    AppBarLayout idAblMain;
    @BindView(R.id.id_nv_main)
    NavigationView idNvMain;
    @BindView(R.id.id_dl_main)
    DrawerLayout idDlMain;
    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.id_cl_main)
    CoordinatorLayout idClMain;
    @BindView(R.id.id_tv_mine)
    TextView idTvMine;
    @BindView(R.id.id_tv_online_music)
    TextView idTvOnlineMusic;
    @BindView(R.id.id_tv_find_music)
    TextView idTvFindMusic;
    @BindView(R.id.id_ll_home_title)
    LinearLayout idLlHomeTitle;
    @BindView(R.id.tv_play_bar_title)
    TextView tvPlayBarTitle;
    @BindView(R.id.tv_play_bar_artist)
    TextView tvPlayBarArtist;
    @BindView(R.id.iv_play_bar_play)
    ImageView ivPlayBarPlay;
    @BindView(R.id.iv_play_bar_next)
    ImageView ivPlayBarNext;
    @BindView(R.id.v_play_bar_playlist)
    ImageView vPlayBarPlaylist;
    @BindView(R.id.pb_play_bar)
    ProgressBar pbPlayBar;
    @BindView(R.id.id_vp_content)
    ViewPager idVpContent;
    private ActionBarDrawerToggle mDrawerToggle;

    @BindView(R.id.fl_play_bar)
    FrameLayout flPlayBar;
    @BindView(R.id.iv_play_bar_cover)
    ImageView ivPlayBarCover;


    private ControlPlay controlPlay;
    private PlayMusicFragment mPlayMusicFragment;
    private boolean isShowPlayMusicFragment;


    private MineFragment mMineFragment;
    private OnlineMusicListFragment mOnlineMusicListFragment;
    private FindMusicFragment mFindMusicFragment;

    @Override
    protected int getStatusBarColor() {
        setSystemBarTransparent();
        return -1;
    }

    private void setSystemBarTransparent() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // LOLLIPOP解决方案
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            // KITKAT解决方案
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initView() {
        super.initView();
        idTlMain.setPadding(0, ScreenUtils.getStatusBarHeight(), 0, 0);
        setSupportActionBar(idTlMain);
        //不显示toolbar的标题
        idLlHomeTitle.setVisibility(View.VISIBLE);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        //设置导航栏图标
        idTlMain.setNavigationIcon(R.mipmap.ic_menu); //设置导航按钮图标

        if (getSupportActionBar() != null) {
            //设置左上角的图标响应
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        //绑定菜单和toolbar
        mDrawerToggle = new ActionBarDrawerToggle(mActivity, idDlMain, idTlMain, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                invalidateOptionsMenu();
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
                invalidateOptionsMenu();
            }
        };
        //显示默认的图标
//        mDrawerToggle.setDrawerIndicatorEnabled(false);
        //将左上角的图标和侧滑监听进行联动 达到动画效果显示
        mDrawerToggle.syncState();
        //设置侧滑菜单的监听, 同时加上这句话还会有一个小的点击翻转动画
        idDlMain.addDrawerListener(mDrawerToggle);
        //toolbar的菜单点击事件
        idTlMain.setNavigationOnClickListener(v -> openOrCloseDrawer());

        idNvMain.setNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.action_person:
                    //个人信息
                    RxActivityTool.skipActivity(mContext, PersonActivity.class);
                    break;
                case R.id.action_forget_pwd:
                    //找回密码
                    RxActivityTool.skipActivity(mContext, ForgetPwdActivity.class);
                    break;
                case R.id.action_about:
                    //关于app
                    RxActivityTool.skipActivity(mContext, AboutAppActivity.class);
                    break;
                case R.id.action_exit:
                    //退出应用
                    SPTool.getInstanse().clear();
                    RxActivityTool.skipActivity(mContext, MainActivity.class);
                    break;
            }
            return false;
        });

        mGreenDaoHelper = GreenDaoHelper.getInstance();

        //初始化侧边栏
        initNavi();

        //toolbar的菜单操作
        idTlMain.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.action_search:
                    RxToast.normal("搜索");
                    return true;
            }
            return false;
        });

        mMineFragment = new MineFragment();
        mOnlineMusicListFragment = new OnlineMusicListFragment();
        mFindMusicFragment = new FindMusicFragment();
        FragmentAdapter adapter = new FragmentAdapter(getSupportFragmentManager());
        adapter.addFragment(mMineFragment);
        adapter.addFragment(mOnlineMusicListFragment);
        adapter.addFragment(mFindMusicFragment);
        idVpContent.setAdapter(adapter);
        idVpContent.addOnPageChangeListener(this);
        idTvMine.setSelected(true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        initNavi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (MyApp.getInstance().getVideoPlaying() != null) {
            if (MyApp.getInstance().getVideoPlaying().currentState == JCVideoPlayer.CURRENT_STATE_PLAYING) {
                MyApp.getInstance().getVideoPlaying().startButton.performClick();
            } else if (MyApp.getInstance().getVideoPlaying().currentState == JCVideoPlayer.CURRENT_STATE_PREPAREING) {
                JCVideoPlayer.releaseAllVideos();
            }
        }
    }

    private void initNavi() {
        View headView = idNvMain.getHeaderView(0);
        headView.findViewById(R.id.id_ll_user_nv).setOnClickListener(this);
        CircleImageView idCvUserImg = headView.findViewById(R.id.id_cv_user_img);
        TextView idTvUserName = headView.findViewById(R.id.id_tv_user_name);
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            User user = new Gson().fromJson(userInfo, User.class);
            idTvUserName.setText(user.getUserName());
        } else {
            idTvUserName.setText("游客");
        }

        initMusicOther();

    }

    @Override
    protected void onServiceBound() {
        super.onServiceBound();
        controlPlay = new ControlPlay(flPlayBar);
        AudioPlayer.get().addOnPlayEventListener(controlPlay);
    }

    @Override
    protected void initListener() {
        flPlayBar.setOnClickListener(this);
        idTvMine.setOnClickListener(this);
        idTvOnlineMusic.setOnClickListener(this);
        idTvFindMusic.setOnClickListener(this);
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_main;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_tl_main, menu);
        return true;
    }

    /**
     * 关闭打开左侧菜单栏
     */
    private void openOrCloseDrawer() {
        if (idDlMain.isDrawerOpen(idNvMain)) {
            idDlMain.closeDrawer(idNvMain);
        } else {
            idDlMain.openDrawer(idNvMain);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt(Keys.VIEW_PAGER_INDEX, idVpContent.getCurrentItem());
        mMineFragment.onSaveInstanceState(outState);
        mOnlineMusicListFragment.onSaveInstanceState(outState);
        mFindMusicFragment.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(final Bundle savedInstanceState) {
        idVpContent.post(() -> {
            idVpContent.setCurrentItem(savedInstanceState.getInt(Keys.VIEW_PAGER_INDEX), false);
//            mMineFragment.onRestoreInstanceState(savedInstanceState);
//            mOnlineMusicListFragment.onRestoreInstanceState(savedInstanceState);
//            mFindMusicFragment.onRestoreInstanceState(savedInstanceState);
        });
    }

    @Override
    public void onBackPressed() {

        if (mPlayMusicFragment != null && isShowPlayMusicFragment) {
            hidePlayMusicFragment();
            return;
        }

        if (idDlMain.isDrawerOpen(GravityCompat.START)) {
            idDlMain.closeDrawers();
            return;
        }

        if (!RxToast.doubleClickExit()) {
            return;
        }

        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (controlPlay != null) {
            AudioPlayer.get().removeOnPlayEventListener(controlPlay);
        }
        super.onDestroy();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.fl_play_bar:
                //弹出播放音乐的fragment
                showPlayMusicFragment();
                break;
            case R.id.id_ll_user_nv:
                //有登录用户的话，进去个人信息，没有的话 前往登陆界面
                String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
                if (!TextUtils.isEmpty(userInfo)) {
                    RxActivityTool.skipActivity(mContext, PersonActivity.class);
                } else {
                    RxActivityTool.skipActivity(mContext, LoginActivity.class);
                }
                break;
            case R.id.id_tv_mine:
                idVpContent.setCurrentItem(0);
                break;
            case R.id.id_tv_online_music:
                idVpContent.setCurrentItem(1);
                break;
            case R.id.id_tv_find_music:
                idVpContent.setCurrentItem(2);
                break;


        }
    }

    private void showPlayMusicFragment() {
        if (isShowPlayMusicFragment) {
            return;
        }

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.setCustomAnimations(R.anim.fragment_slide_up, 0);
        if (mPlayMusicFragment == null) {
            mPlayMusicFragment = new PlayMusicFragment();
            ft.replace(android.R.id.content, mPlayMusicFragment);
        } else {
            ft.show(mPlayMusicFragment);
        }
        ft.commitAllowingStateLoss();
        isShowPlayMusicFragment = true;
    }

    private void hidePlayMusicFragment() {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.setCustomAnimations(0, R.anim.fragment_slide_down);
        ft.hide(mPlayMusicFragment);
        ft.commitAllowingStateLoss();
        isShowPlayMusicFragment = false;
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        Log.i(TAG, "onPageSelected: position==" + position);
        int textSize_15 = mContext.getResources().getDimensionPixelSize(R.dimen.text_15);
        int textSize_18 = mContext.getResources().getDimensionPixelSize(R.dimen.text_18);
        switch (position) {
            case 0:
                idTvMine.setSelected(true);
                idTvOnlineMusic.setSelected(false);
                idTvFindMusic.setSelected(false);
                idTvMine.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_18);
                idTvOnlineMusic.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_15);
                idTvFindMusic.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_15);
                break;
            case 1:
                idTvMine.setSelected(false);
                idTvOnlineMusic.setSelected(true);
                idTvFindMusic.setSelected(false);
                idTvMine.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_15);
                idTvOnlineMusic.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_18);
                idTvFindMusic.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_15);
                break;
            case 2:
                idTvMine.setSelected(false);
                idTvOnlineMusic.setSelected(false);
                idTvFindMusic.setSelected(true);
                idTvMine.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_15);
                idTvOnlineMusic.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_15);
                idTvFindMusic.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize_18);
                break;
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    private GreenDaoHelper mGreenDaoHelper;


    @TargetApi(Build.VERSION_CODES.N)
    private void initMusicOther() {
        Observable.just(0)
                .map(integer -> {
//                    FileUtils.copyDb(mContext, Keys.DB_NAME);
                    String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
                    long userId = Keys.DEF_TOURIST_ID;
                    if (!TextUtils.isEmpty(userInfo)) {
                        User user = new Gson().fromJson(userInfo, User.class);
                        userId = user.getId();
                    }
                    // 我们新建一个默认的音乐列表和我喜欢的列表
                    MusicList musicList = GreenDaoHelper.getInstance().queryDefMusicList();
                    if (musicList == null) {
                        musicList = new MusicList();
                        musicList.setId(Keys.DEF_MUSIC_LIST_ID);
                        musicList.setMusicListName("默认列表");
                        mGreenDaoHelper.insertMusicList(musicList);
                    }
                    UserMusicList userMusicList = GreenDaoHelper.getInstance().queryUserDefMusicList(userId);
                    if (userMusicList == null) {
                        userMusicList = new UserMusicList();
                        userMusicList.setUserId(userId);
                        //默认都会新建一个 默认列表
                        userMusicList.setMusicListId(Keys.DEF_MUSIC_LIST_ID);
                        mGreenDaoHelper.insertUserMusicList(userMusicList);
                    }

                    MusicList myLovemusicList = GreenDaoHelper.getInstance().queryMusicList(Keys.MY_LOVE_MUSIC_LIST_ID);
                    if (myLovemusicList == null) {
                        myLovemusicList = new MusicList();
                        myLovemusicList.setId(Keys.MY_LOVE_MUSIC_LIST_ID);
                        myLovemusicList.setMusicListName("我喜欢");
                        mGreenDaoHelper.insertMusicList(myLovemusicList);
                    }
                    UserMusicList myLoveUserMusicList = GreenDaoHelper.getInstance().queryUserMusicListsByUserIdMusicListId(userId, Keys.MY_LOVE_MUSIC_LIST_ID);
                    if (myLoveUserMusicList == null) {
                        myLoveUserMusicList = new UserMusicList();
                        myLoveUserMusicList.setUserId(userId);
                        //默认都会新建一个 我喜欢列表
                        myLoveUserMusicList.setMusicListId(Keys.MY_LOVE_MUSIC_LIST_ID);
                        mGreenDaoHelper.insertUserMusicList(myLoveUserMusicList);

                        User user = new User();
                        user.setUserName("水里的鱼");
                        user.setUserEmail("123@qq.com");
                        user.setUserPwdHelp("1");
                        user.setUserPwd("123");
                        User user01 = new User();
                        user01.setUserName("沐风");
                        user01.setUserEmail("321@qq.com");
                        user01.setUserPwdHelp("1");
                        user01.setUserPwd("123");
                        mGreenDaoHelper.insertUser(user);
                        mGreenDaoHelper.insertUser(user01);
                    }

                    MusicList recentmusicList = GreenDaoHelper.getInstance().queryMusicList(Keys.RECENT_MUSIC_LIST_ID);
                    if (recentmusicList == null) {
                        recentmusicList = new MusicList();
                        recentmusicList.setId(Keys.RECENT_MUSIC_LIST_ID);
                        recentmusicList.setMusicListName("最近播放");
                        mGreenDaoHelper.insertMusicList(recentmusicList);
                    }
                    UserMusicList recentUserMusicList = GreenDaoHelper.getInstance().queryUserMusicListsByUserIdMusicListId(userId, Keys.RECENT_MUSIC_LIST_ID);
                    if (recentUserMusicList == null) {
                        recentUserMusicList = new UserMusicList();
                        recentUserMusicList.setUserId(userId);
                        //默认都会新建一个 最近播放
                        recentUserMusicList.setMusicListId(Keys.RECENT_MUSIC_LIST_ID);
                        mGreenDaoHelper.insertUserMusicList(recentUserMusicList);
                    }


                    return 1;
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(integer -> {
                });
    }
}
