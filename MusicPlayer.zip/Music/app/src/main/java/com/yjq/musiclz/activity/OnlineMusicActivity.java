package com.yjq.musiclz.activity;

import android.graphics.Bitmap;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.google.gson.Gson;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.adapter.OnlineMusicAdapter;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Extras;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.entry.OnlineMusic;
import com.yjq.musiclz.entry.OnlineMusicList;
import com.yjq.musiclz.entry.SheetInfo;
import com.yjq.musiclz.enums.LoadStateEnum;
import com.yjq.musiclz.executor.PlayOnlineMusic;
import com.yjq.musiclz.executor.ShareOnlineMusic;
import com.yjq.musiclz.http.HttpCallback;
import com.yjq.musiclz.http.HttpClient;
import com.yjq.musiclz.listener.OnMoreClickListener;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.FileUtils;
import com.yjq.musiclz.utils.ImageUtils;
import com.yjq.musiclz.utils.SPTool;
import com.yjq.musiclz.utils.ScreenUtils;
import com.yjq.musiclz.view.AutoLoadListView;
import com.yjq.musiclz.view.ViewUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 */

public class OnlineMusicActivity extends BaseActivity implements AdapterView.OnItemClickListener, OnMoreClickListener, AutoLoadListView.OnLoadListener {

    private static final int MUSIC_LIST_SIZE = 20;

    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.lv_online_music_list)
    AutoLoadListView lvOnlineMusicList;
    @BindView(R.id.ll_loading)
    LinearLayout llLoading;
    @BindView(R.id.ll_load_fail)
    LinearLayout llLoadFail;
    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;

    private View vHeader;
    private OnlineMusicList mOnlineMusicList;
    private List<OnlineMusic> mMusicList = new ArrayList<>();
    private OnlineMusicAdapter mAdapter = new OnlineMusicAdapter(mMusicList);
    private int mOffset = 0;

    private SheetInfo mSheetInfo;

    @Override
    protected void initView() {
        super.initView();

        vHeader = LayoutInflater.from(this).inflate(R.layout.activity_online_music_list_header, null);
        AbsListView.LayoutParams params = new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ScreenUtils.dp2px(150));
        vHeader.setLayoutParams(params);
        lvOnlineMusicList.addHeaderView(vHeader, null, false);
        lvOnlineMusicList.setAdapter(mAdapter);
        lvOnlineMusicList.setOnLoadListener(this);
        ViewUtils.changeViewState(lvOnlineMusicList, llLoading, llLoadFail, LoadStateEnum.LOADING);
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initListener() {
        lvOnlineMusicList.setOnItemClickListener(this);
        mAdapter.setOnMoreClickListener(this);
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_online_music;
    }


    @Override
    protected void onServiceBound() {
        mSheetInfo = (SheetInfo) getIntent().getSerializableExtra(Extras.MUSIC_LIST_TYPE);
        idTvTlTitle.setVisibility(View.VISIBLE);
        setTlTitle(idTlMain, idTvTlTitle, mSheetInfo.getTitle());
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());
        onLoad();
    }

    private void getMusic(final int offset) {
        HttpClient.getSongListInfo(mSheetInfo.getType(), MUSIC_LIST_SIZE, offset, new HttpCallback<OnlineMusicList>() {
            @Override
            public void onSuccess(OnlineMusicList response) {
                lvOnlineMusicList.onLoadComplete();
                mOnlineMusicList = response;
                if (offset == 0 && response == null) {
                    ViewUtils.changeViewState(lvOnlineMusicList, llLoading, llLoadFail, LoadStateEnum.LOAD_FAIL);
                    return;
                } else if (offset == 0) {
                    initHeader();
                    ViewUtils.changeViewState(lvOnlineMusicList, llLoading, llLoadFail, LoadStateEnum.LOAD_SUCCESS);
                }
                if (response == null || response.getSong_list() == null || response.getSong_list().size() == 0) {
                    lvOnlineMusicList.setEnable(false);
                    return;
                }
                mOffset += MUSIC_LIST_SIZE;
                mMusicList.addAll(response.getSong_list());
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFail(Exception e) {
                lvOnlineMusicList.onLoadComplete();
                if (e instanceof RuntimeException) {
                    // 歌曲全部加载完成
                    lvOnlineMusicList.setEnable(false);
                    return;
                }
                if (offset == 0) {
                    ViewUtils.changeViewState(lvOnlineMusicList, llLoading, llLoadFail, LoadStateEnum.LOAD_FAIL);
                } else {
                    RxToast.normal(mContext.getResources().getString(R.string.load_fail));
                }
            }
        });
    }

    @Override
    public void onLoad() {
        getMusic(mOffset);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        play((OnlineMusic) parent.getAdapter().getItem(position));
    }

    @Override
    public void onMoreClick(int position) {
        final OnlineMusic onlineMusic = mMusicList.get(position);
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(mMusicList.get(position).getTitle());
        String path = FileUtils.getMusicDir() + FileUtils.getMp3FileName(onlineMusic.getArtist_name(), onlineMusic.getTitle());
        File file = new File(path);
        int itemsId = file.exists() ? R.array.online_music_dialog_without_download : R.array.online_music_dialog;
        dialog.setItems(itemsId, (dialog1, which) -> {
            switch (which) {
                case 0:// 分享
                    share(onlineMusic);
                    break;
                case 1:// 查看歌手信息
                    artistInfo(onlineMusic);
                    break;
            }
        });
        dialog.show();
    }

    private void initHeader() {
        final ImageView ivHeaderBg = vHeader.findViewById(R.id.iv_header_bg);
        final ImageView ivCover = vHeader.findViewById(R.id.iv_cover);
        TextView tvTitle = vHeader.findViewById(R.id.tv_title);
        TextView tvUpdateDate = vHeader.findViewById(R.id.tv_update_date);
        TextView tvComment = vHeader.findViewById(R.id.tv_comment);
        tvTitle.setText(mOnlineMusicList.getBillboard().getName());
        tvUpdateDate.setText(getString(R.string.recent_update, mOnlineMusicList.getBillboard().getUpdate_date()));
        tvComment.setText(mOnlineMusicList.getBillboard().getComment());
        Glide.with(this)
                .load(mOnlineMusicList.getBillboard().getPic_s640())
                .asBitmap()
                .placeholder(R.drawable.default_cover)
                .error(R.drawable.default_cover)
                .override(200, 200)
                .into(new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                        ivCover.setImageBitmap(resource);
                        ivHeaderBg.setImageBitmap(ImageUtils.blur(resource));
                    }
                });
    }

    private void play(OnlineMusic onlineMusic) {
        new PlayOnlineMusic(mActivity, onlineMusic) {
            @Override
            public void onPrepare() {
                showProgress();
            }

            @Override
            public void onExecuteSuccess(Music music) {
                cancelProgress();
                //点击的时候，我们默认添加到默认列表
                Log.i(TAG, "onExecuteSuccess: music===" + music.toString());
                String path = music.getPath();
                path = path.substring(0, path.indexOf(".mp3?"));
                path = path.substring(path.lastIndexOf("/")+1);
                music.setSongId(path);
                Music localMusic = GreenDaoHelper.getInstance().queryMusicByMusicSongId(music.getSongId());
                if (localMusic!= null){
                    music.setId(localMusic.getId());
                }
                String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
                //游客身份登录  游客的id是唯一 且固定的 就是-1
                long userId = Keys.DEF_TOURIST_ID;
                if (!TextUtils.isEmpty(userInfo)) {
                    User user = new Gson().fromJson(userInfo, User.class);
                    userId = user.getId();
                }
                UserMusicList userMusicList = GreenDaoHelper.getInstance().queryUserDefMusicList(userId);
                boolean isUpdate = true;  // 是更新的 不是新建的
                if (userMusicList == null) {
                    Log.i(TAG, "onItemClick: 新建中间表");
                    isUpdate = false;
                    userMusicList = new UserMusicList();
                    userMusicList.setUserId(userId);
                    userMusicList.setMusicListId(Keys.DEF_MUSIC_LIST_ID);
                }
                List<Long> musicIdList = userMusicList.getMusicIdList();
                if (musicIdList == null) {
                    musicIdList = new ArrayList<>();
                }
                Log.i(TAG, "onItemClick: musicIdList.s==" + musicIdList.toString());
                AudioPlayer audioPlayer = AudioPlayer.get(); audioPlayer.setPlayMusicListId(Keys.DEF_MUSIC_LIST_ID);
                audioPlayer.initMusicList();
                int position = audioPlayer.addOnlineMusic(music);
                if (music.getId() == null) {
                    Log.e(TAG, "onExecuteSuccess: musicid 异常");
                }else{
                    if (!musicIdList.contains(music.getId())) {
                        musicIdList.add(0, music.getId());
                        userMusicList.setMusicIdList(musicIdList);
                        audioPlayer.addOrUpdate(userMusicList, isUpdate);
                    }
                }
                audioPlayer.play(position);
                RxToast.normal("已添加到默认列表");
            }

            @Override
            public void onExecuteFail(Exception e) {
                cancelProgress();
                RxToast.normal("暂时无法播放");
            }
        }.execute();
    }

    private void share(final OnlineMusic onlineMusic) {
        new ShareOnlineMusic(this, onlineMusic.getTitle(), onlineMusic.getSong_id()) {
            @Override
            public void onPrepare() {
                showProgress();
            }

            @Override
            public void onExecuteSuccess(Void aVoid) {
                cancelProgress();
            }

            @Override
            public void onExecuteFail(Exception e) {
                cancelProgress();
            }
        }.execute();
    }

    private void artistInfo(OnlineMusic onlineMusic) {
        ArtistInfoActivity.start(this, onlineMusic.getTing_uid());
    }

}
