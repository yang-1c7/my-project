package com.yjq.musiclz.activity;

import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.utils.ProgressDialogHelper;
import com.yjq.musiclz.utils.SPTool;
import com.yjq.musiclz.utils.ShakeHelper;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class RegisterActivity extends BaseActivity implements View.OnClickListener{

    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;
    @BindView(R.id.id_et_user)
    EditText idEtUser;
    @BindView(R.id.id_et_pwd)
    EditText idEtPwd;
    @BindView(R.id.id_et_pwd_sure)
    EditText idEtPwdSure;
    @BindView(R.id.id_et_pwd_help)
    EditText idEtPwdHelp;
    @BindView(R.id.id_et_mail)
    EditText idEtMail;
    @BindView(R.id.id_btn_register)
    Button idBtnRegister;
    @BindView(R.id.id_rg_role)
    RadioGroup idRgRole;

    private ProgressDialogHelper progressDialogHelper;
    private GreenDaoHelper mGreenDaoHelper;

    private int userType;

    @Override
    protected void initView() {
        super.initView();
        setTlTitle(idTlMain, idTvTlTitle, "注册");
        progressDialogHelper = new ProgressDialogHelper(mContext);
        mGreenDaoHelper = GreenDaoHelper.getInstance();
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initListener() {
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());
        idBtnRegister.setOnClickListener(this);
        idEtPwdSure.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                String pwd = idEtPwd.getText().toString().trim();
                if (isEtEmpty(pwd, "请先填写密码", idEtPwd)) return;
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        idEtPwdSure.setOnFocusChangeListener((v, hasFocus) -> {

            if (!hasFocus) {
                // 此处为失去焦点时的处理内容
                if (!TextUtils.equals(idEtPwd.getText().toString().trim(), idEtPwdSure.getText().toString().trim())) {
                    RxToast.normal("两次输入的密码不一致");
                    idEtPwdSure.setText("");
                }
            }
        });

        idEtMail.setOnFocusChangeListener((v, hasFocus) -> {

            if (!hasFocus) {
                // 此处为失去焦点时的处理内容
                String mailStr = idEtMail.getText().toString().trim();
                if (!mailStr.matches("^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\\.[a-zA-Z0-9_-]{2,3}){1,2})$") || mailStr.length() <= 0) {
                    RxToast.normal("邮箱格式不正确");
                    idEtMail.setText("");
                }
            }
        });

        idRgRole.setOnCheckedChangeListener((radioGroup, i) -> {
            switch (radioGroup.getCheckedRadioButtonId()){
                case R.id.id_rb_role_student:
                    userType = 0 ;
                    break;
                case R.id.id_rb_role_teacher:
                    userType = 1 ;
                    break;
            }
        });
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_register;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.id_btn_register:
                String userName = idEtUser.getText().toString().trim();
                String pwd = idEtPwd.getText().toString().trim();
                String pwdSure = idEtPwdSure.getText().toString().trim();
                String pwdHelp = idEtPwdHelp.getText().toString().trim();
                String mail = idEtMail.getText().toString().trim();
                if (isEtEmpty(userName, "用户名不能为空", idEtUser)) return;
                if (isEtEmpty(pwd, "密码不能为空", idEtPwd)) return;
                if (isEtEmpty(pwdSure, "确认密码不能为空", idEtPwdSure)) return;
                if (isEtEmpty(pwdHelp, "密保不能为空", idEtPwdHelp)) return;
                if (isEtEmpty(mail, "邮箱不能为空", idEtMail)) return;
                String mailStr = idEtMail.getText().toString().trim();
                if (!mailStr.matches("^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\\.[a-zA-Z0-9_-]{2,3}){1,2})$") || mailStr.length() <= 0) {
                    idEtMail.setText("");
                    RxToast.normal("邮箱格式不正确");
                    ShakeHelper.shake(idEtMail);
                    return;
                }

                progressDialogHelper.show("Register", "正在注册中...");
                Observable.just(1)
                        .map(integer -> {
                            User user = mGreenDaoHelper.queryUserByUserName(userName);
                            if (user != null) {
                                Log.e(TAG, "老用户，已经注册过了。");
                                return 2;
                            } else {
                                Log.e(TAG, "新用户");
                                return 1;
                            }
                        })
                        .map(integer -> {
                                    if (integer == 1) {
                                        User user = new User();
                                        user.setUserName(userName);
                                        user.setUserPwd(pwd);
                                        user.setUserPwdHelp(pwdHelp);
                                        user.setUserEmail(mail);
                                        // TODO: 2018/12/26  头像路径
                                        user.setUserImgPath(userName);
                                        user.setUserType(userType);
                                        mGreenDaoHelper.insertUser(user);
                                        SPTool.getInstanse().setParam(Keys.USER_INFO, new Gson().toJson(user));
                                        return 3;
                                    }
                                    return integer;
                                }
                        )
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(integer -> {
                            progressDialogHelper.dismiss();
                            switch (integer) {
                                case 1:
                                    //用户注册失败
                                    RxToast.normal("注册失败...");
                                    break;
                                case 2:
                                    //老用户
                                    RxToast.normal("该用户名已注册...");
                                    break;
                                case 3:
                                    //用户注册成功
                                    RxToast.normal("恭喜你，注册成功！！！");
                                    if (userType==1){
                                        RxActivityTool.skipActivity(mContext, AdminMainActivity.class);
                                        RxActivityTool.finishActivity(MainActivity.class);
                                    }else if (userType == 0){
                                        RxActivityTool.skipActivity(mContext, MainActivity.class);
                                    }
                                    finish();
                                    break;
                            }
                        });
                break;
        }
    }
}
