package com.yjq.musiclz.constants;

public interface RequestCode {
    int REQUEST_WRITE_SETTINGS = 0;
    int REQUEST_ALBUM = 1;
    int REQUEST_CORP = 2;

    /**
     * 更新音乐信息
     *
     */
    int REQ_UPDATE_MUSIC = 100;
}
