package com.yjq.musiclz.listener;

import com.yjq.musiclz.entry.MusicListBean;

/**
 */

public interface OnGroupLongListener {

    /**
     * 父组的长按事件
     *
     * @param musicListBean
     * @param groupPosition
     */
    void onGroupLong(MusicListBean musicListBean, int groupPosition);
}
