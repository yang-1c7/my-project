package com.yjq.musiclz.listener;

/**
 * 音乐列表“更多”按钮监听器
 */
public interface OnMoreClickListener {
    void onMoreClick(int position);
}
