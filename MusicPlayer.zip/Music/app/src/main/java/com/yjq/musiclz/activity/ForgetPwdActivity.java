package com.yjq.musiclz.activity;

import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.utils.ProgressDialogHelper;
import com.yjq.musiclz.utils.SPTool;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class ForgetPwdActivity extends BaseActivity implements View.OnClickListener {

    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;
    @BindView(R.id.id_et_user)
    EditText idEtUser;
    @BindView(R.id.id_et_pwd_help)
    EditText idEtPwdHelp;
    @BindView(R.id.id_et_pwd)
    EditText idEtPwd;
    @BindView(R.id.id_btn_save)
    Button idBtnSave;


    private ProgressDialogHelper progressDialogHelper;
    private GreenDaoHelper mGreenDaoHelper;

    @Override
    protected void initView() {
        super.initView();
        setTlTitle(idTlMain, idTvTlTitle, "找回密码");
        progressDialogHelper = new ProgressDialogHelper(mContext);
        mGreenDaoHelper = GreenDaoHelper.getInstance();
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initListener() {
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());
        idBtnSave.setOnClickListener(this);

    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_forget_pwd;
    }

    private User user;

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.id_btn_save:
                String userName = idEtUser.getText().toString().trim();
                String pwdHelp = idEtPwdHelp.getText().toString().trim();
                String pwd = idEtPwd.getText().toString().trim();
                if (isEtEmpty(userName, "用户名不能为空", idEtUser)) return;
                if (isEtEmpty(pwdHelp, "密保不能为空", idEtPwdHelp)) return;
                if (isEtEmpty(pwd, "密码不能为空", idEtPwd)) return;
                progressDialogHelper.show("ForgetPwd", "正在修改密码...");
                Observable.just(1)
                        .map(integer -> {
                                    User userPar = mGreenDaoHelper.queryUserByNamePwdHelp(userName, pwdHelp);
                                    if (userPar != null) {
                                        Log.e(TAG, "存在用户，可以找回密码");
                                        user = userPar;
                                        return 2;
                                    } else {
                                        Log.e(TAG, "用户名和密保不一致");
                                        return 1;
                                    }
                                }
                        )
                        .map(integer -> {
                            if (integer == 2) {
                                user.setUserPwd(pwd);
                                mGreenDaoHelper.updateUser(user);
                                SPTool.getInstanse().setParam(Keys.USER_INFO, new Gson().toJson(user));
                                return 3;
                            }
                            return integer;
                        })
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(integer -> {
                            progressDialogHelper.dismiss();
                            progressDialogHelper.dismiss();
                            switch (integer) {
                                case 1:
                                    //用户注册失败
                                    RxToast.normal("用户名和密保不一致...");
                                    break;
                                case 3:
                                    //用户注册成功
                                    RxToast.normal("恭喜你，密码找回！！！");
                                    int userType =  mGreenDaoHelper.queryUserByUserNameAndPwd(userName, pwd).getUserType();
                                    if (userType==1){
                                        RxActivityTool.skipActivity(mContext, AdminMainActivity.class);
                                        RxActivityTool.finishActivity(MainActivity.class);
                                    }else if (userType == 0){
                                        RxActivityTool.skipActivity(mContext, MainActivity.class);
                                    }
                                    finish();
                                    break;
                            }
                        });
                break;
        }
    }
}
