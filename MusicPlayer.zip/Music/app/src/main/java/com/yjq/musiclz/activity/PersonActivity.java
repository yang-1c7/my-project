package com.yjq.musiclz.activity;

import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.utils.ProgressDialogHelper;
import com.yjq.musiclz.utils.SPTool;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class PersonActivity extends BaseActivity implements View.OnClickListener {

    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;
    @BindView(R.id.id_et_user)
    EditText idEtUser;
    @BindView(R.id.id_et_mail)
    EditText idEtMail;
    @BindView(R.id.id_btn_register)
    Button idBtnRegister;
    @BindView(R.id.id_et_pwd_help)
    EditText idEtPwdHelp;

    private ProgressDialogHelper progressDialogHelper;
    private GreenDaoHelper mGreenDaoHelper;

    private User user;

    @Override
    protected void initView() {
        super.initView();
        setTlTitle(idTlMain, idTvTlTitle, "个人信息");
        progressDialogHelper = new ProgressDialogHelper(mContext);
        mGreenDaoHelper = GreenDaoHelper.getInstance();
    }

    @Override
    protected void initData() {
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            user = new Gson().fromJson(userInfo, User.class);
            idEtUser.setText(user.getUserName());
            idEtMail.setText(user.getUserEmail());
            idEtPwdHelp.setText(user.getUserPwdHelp());
        }

    }

    @Override
    protected void initListener() {
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());
        idBtnRegister.setOnClickListener(this);

        idEtMail.setOnFocusChangeListener((v, hasFocus) -> {

            if (!hasFocus) {
                // 此处为失去焦点时的处理内容
                String mailStr = idEtMail.getText().toString().trim();
                if (!mailStr.matches("^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\\.[a-zA-Z0-9_-]{2,3}){1,2})$") || mailStr.length() <= 0) {
                    RxToast.normal("邮箱格式不正确");
                    idEtMail.setText("");
                }
            }
        });
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_person;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.id_btn_register:
                String userName = idEtUser.getText().toString().trim();
                String email = idEtMail.getText().toString().trim();
                if (isEtEmpty(userName, "用户名不能为空", idEtUser)) return;
                if (isEtEmpty(email, "邮箱不能为空", idEtMail)) return;
                user.setUserName(userName);
                user.setUserEmail(email);
                progressDialogHelper.show("save", "正在保存用户信息...");
                Observable.just(1)
                        .map(integer -> {
                            User userTmp = mGreenDaoHelper.queryUserByUserName(userName);
                            if (userTmp == null) {
                                Log.e(TAG, "数据库没有该用户了");
                                return 1;
                            } else {
                                Log.e(TAG, "数据库有该用户，可以验证密码");
                                return -1;
                            }
                        })
                        .map(integer -> {
                                    if (integer == 1) {
                                        mGreenDaoHelper.updateUser(user);
                                        SPTool.getInstanse().setParam(Keys.USER_INFO, new Gson().toJson(user));
                                        return 2;
                                    }
                                    return integer;
                                }
                        )
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(integer -> {
                            progressDialogHelper.dismiss();
                            switch (integer) {
                                case -1:
                                    //数据库没有该用户
                                    RxToast.normal("该用户已经存在，不能重复命名！！");
                                    break;
                                case 2:
                                    //登陆成功
                                    RxToast.normal("个人信息更改成功！！");
                                    int userType =  user.getUserType();
                                    if (userType==1){
                                        RxActivityTool.skipActivity(mContext, AdminMainActivity.class);
                                        RxActivityTool.finishActivity(MainActivity.class);
                                    }else if (userType == 0){
                                        RxActivityTool.skipActivity(mContext, MainActivity.class);
                                    }
                                    finish();
                                    break;
                            }
                        });
                break;
        }

    }
}
