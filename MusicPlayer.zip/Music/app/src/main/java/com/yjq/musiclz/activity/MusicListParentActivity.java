package com.yjq.musiclz.activity;

import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.adapter.MusicListAdapter;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.MusicList;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.entry.MusicListBean;
import com.yjq.musiclz.listener.OnPlayerEventListener;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.SPTool;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

/**
 * 一级的音乐列表
 *
 * @time 2018/12/24 14:14
 */
public class MusicListParentActivity extends BaseActivity implements OnPlayerEventListener {

    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;
    @BindView(R.id.id_elv_music_list)
    ExpandableListView idElvMusicList;

    private List<MusicListBean> mGroupDatas;
    private MusicListAdapter mMusicListAdapter;
    private GreenDaoHelper mGreenDaoHelper;

    @Override
    protected void initView() {
        super.initView();
        setTlTitle(idTlMain, idTvTlTitle, "播放列表");
        mGroupDatas = new ArrayList<>();
        mMusicListAdapter = new MusicListAdapter(mGroupDatas, mContext);
        mMusicListAdapter.setIsPlaylist(true);
        idElvMusicList.setAdapter(mMusicListAdapter);
    }


    @Override
    protected void onServiceBound() {

    }

    @Override
    protected void initData() {
        mGreenDaoHelper = GreenDaoHelper.getInstance();
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        long userId = Keys.DEF_TOURIST_ID;
        if (!TextUtils.isEmpty(userInfo)) {
            User user = new Gson().fromJson(userInfo, User.class);
            userId = user.getId();
        }
        loadMusicList(userId);
    }

    /**
     * 加载播放列表
     *
     * @param userId
     */
    private void loadMusicList(long userId) {
        Observable.just(mGreenDaoHelper.queryUserMusicListsNotLove(userId))
                .map(musicListList -> {
                    List<MusicListBean> musicListBeanList = new ArrayList<>();
                    for (int i = 0; i < musicListList.size(); i++) {
                        MusicListBean musicListBean = new MusicListBean();
                        UserMusicList userMusicList = musicListList.get(i);
                        musicListBean.setMusicList(mGreenDaoHelper.queryMusicList(userMusicList.getMusicListId()));
                        musicListBean.setUserId(userMusicList.getUserId());
                        List<Music> musicLists = new ArrayList<>();
                        if (userMusicList.getMusicIdList() != null) {
                            for (int j = 0; j < userMusicList.getMusicIdList().size(); j++) {
                                long musicId = userMusicList.getMusicIdList().get(j);
                                musicLists.add(mGreenDaoHelper.queryMusicById(musicId));
                            }
                        }
                        musicListBean.setMusicLists(musicLists);
                        musicListBeanList.add(musicListBean);
                    }
                    return musicListBeanList;
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(musicListBeanList -> {
                    Log.i(TAG, musicListBeanList.size() + "==loadMusic: musicListBeanList.size===" + musicListBeanList.toString());
                    if (musicListBeanList.size() == 0) {
                        //数据库没有音乐,获取本地的音乐
                    } else if (musicListBeanList.size() > 0) {
                        if (mGroupDatas.size() > 0) {
                            mGroupDatas.clear();
                        }
                        mGroupDatas.addAll(musicListBeanList);
                        Log.i(TAG, mGroupDatas.size() + "==initData: " + mGroupDatas.toString());
                        mMusicListAdapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    protected void initListener() {
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());

        AudioPlayer.get().addOnPlayEventListener(this);

        //toolbar的菜单操作
        idTlMain.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case R.id.action_add_music_list:
                    String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
                    if (TextUtils.isEmpty(userInfo)) {
                        RxToast.normal("亲，您目前是游客，无权新建列表，请先注册为会员！！！");
                        RxActivityTool.skipActivity(mContext, LoginActivity.class);
                        return true;
                    }
                    User user = new Gson().fromJson(userInfo, User.class);
                    View dialogView = LayoutInflater.from(mContext).inflate(R.layout.dialog_add_music_list, null, false);
                    EditText idEtAddMusicListName = dialogView.findViewById(R.id.id_et_add_music_list);
                    AlertDialog alertDialog = new AlertDialog.Builder(mContext)
                            .setView(dialogView)
                            .setPositiveButton("保存", null).setNegativeButton("放弃", null)
                            .create();
                    alertDialog.setCanceledOnTouchOutside(false);
                    alertDialog.setOnShowListener(dialog -> {
                        Button positionButton = alertDialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE);
                        Button negativeButton = alertDialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE);
                        positionButton.setOnClickListener(v -> {
                            String musicListName = idEtAddMusicListName.getText().toString().trim();
                            if (isEtEmpty(musicListName, "列表名称不能为空", idEtAddMusicListName)) return;
                            if (TextUtils.equals(musicListName, "默认列表")) {
                                RxToast.normal("默认列表不能新建，请命名其他的名称！！！");
                                return;
                            }
                            Observable.just(1)
                                    .map(integer -> {
                                        MusicList musicList = mGreenDaoHelper.queryMusicList(musicListName);
                                        if (musicList == null) {
                                            musicList = new MusicList();
                                            musicList.setMusicListName(musicListName);
                                            mGreenDaoHelper.insertMusicList(musicList);
                                            return 1;
                                        }
                                        return -1;
                                    })
                                    .map(integer -> {
                                        if (integer == 1) {
                                            MusicList musicList = mGreenDaoHelper.queryMusicList(musicListName);
                                            UserMusicList userMusicList = new UserMusicList();
                                            long userId = user.getId();
                                            userMusicList.setUserId(userId);
                                            long musicListId = musicList.getId();
                                            userMusicList.setMusicListId(musicListId);
                                            mGreenDaoHelper.insertUserMusicList(userMusicList);
                                            MusicListBean musicListBean = new MusicListBean();
                                            UserMusicList userMusicListTmp = mGreenDaoHelper.queryUserMusicList(userId, musicListId);
                                            musicListBean.setMusicList(mGreenDaoHelper.queryMusicList(userMusicListTmp.getMusicListId()));
                                            musicListBean.setUserId(userId);
                                            List<Music> musicLists = new ArrayList<>();
                                            if (userMusicListTmp.getMusicIdList() != null) {
                                                for (int j = 0; j < userMusicListTmp.getMusicIdList().size(); j++) {
                                                    long musicId = userMusicListTmp.getMusicIdList().get(j);
                                                    musicLists.add(mGreenDaoHelper.queryMusicById(musicId));
                                                }
                                            }
                                            musicListBean.setMusicLists(musicLists);
                                            mGroupDatas.add(musicListBean);
                                            return 1;
                                        }
                                        return integer;
                                    })
                                    .subscribeOn(Schedulers.io())
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(aLong -> {
                                        if (aLong >= 0) {
                                            RxToast.normal("新增列表成功！！！");
                                            mMusicListAdapter.notifyDataSetChanged();
                                            alertDialog.dismiss();
                                        } else {
                                            RxToast.normal("该列表已存在，请重新命名！！！");
                                        }
                                    });

                        });
                        negativeButton.setOnClickListener(v -> alertDialog.dismiss());
                    });
                    alertDialog.show();
                    return true;
            }
            return false;
        });

        //折叠
//        idElvMusicList.setOnGroupCollapseListener();
        //展开
//        idElvMusicList.setOnGroupExpandListener();
        idElvMusicList.setOnChildClickListener((parent, view, groupPosition, childPosition, id) -> {
            Log.i(TAG, "initListener: groupPosition===" + groupPosition + "==childPosition==" + childPosition);
            AudioPlayer audioPlayer = AudioPlayer.get();
            audioPlayer.setPlayMusicListId(mGroupDatas.get(groupPosition).getMusicList().getId());
            audioPlayer.initMusicList();
            audioPlayer.play(childPosition);
            return true;
        });

        mMusicListAdapter.setOnViewClickListener((view, o, childPosition) -> {
            String[] items = new String[]{"移除"};
            MusicListBean musicListBean = (MusicListBean) o;
            List<Music> musicList = musicListBean.getMusicLists();
            Music music = musicList.get(childPosition);
            new AlertDialog.Builder(mContext)
                    .setTitle(music.getTitle())
                    .setItems(items, (dialog1, which) -> Observable.just(1)
                            .map(integer -> {
                                UserMusicList userMusicList = mGreenDaoHelper.queryUserMusicList(musicListBean.getUserId(), musicListBean.getMusicList().getId());
                                userMusicList.getMusicIdList().remove(music.getId());
                                mGreenDaoHelper.updateUserMusicList(userMusicList);
                                musicList.remove(music);
                                musicListBean.setMusicLists(musicList);
                                return 1;
                            }).subscribeOn(Schedulers.io()).observeOn(AndroidSchedulers.mainThread())
                            .subscribe(r -> mMusicListAdapter.notifyDataSetChanged()))
                    .show();
        });

        mMusicListAdapter.setOnGroupLongListener((musicListBean, groupPosition) -> {
            if (musicListBean.getMusicList().getId() == Keys.DEF_MUSIC_LIST_ID) {
                RxToast.normal("默认列表不能删除");
                return;
            }
            new AlertDialog.Builder(mContext)
                    .setTitle("是否确认删除该列表")
                    .setMessage("删除列表的同时，该列表下的所有音乐将删除，但是不删除本地音乐！！！")
                    .setPositiveButton("确认", (dialogInterface, i) -> {
                        long musicListId = musicListBean.getMusicList().getId();
                        mGreenDaoHelper.deleteUserMusicListByMusicListId(musicListId, musicListBean.getUserId());
                        mGreenDaoHelper.deleteMusicListById(musicListId);
                        mGroupDatas.remove(musicListBean);
                        mMusicListAdapter.notifyDataSetChanged();
                        dialogInterface.dismiss();
                        RxToast.normal("删除成功");
                    }).setNegativeButton("放弃", (dialogInterface, i) -> dialogInterface.dismiss()).create().show();
        });
    }

    @Override
    protected void onDestroy() {
        AudioPlayer.get().removeOnPlayEventListener(this);
        super.onDestroy();
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_music_list_parent;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_tl_add_music_list, menu);
        return true;
    }

    @Override
    public void onChange(Music music) {
        mMusicListAdapter.notifyDataSetChanged();
    }

    @Override
    public void onPlayerStart() {

    }

    @Override
    public void onPlayerPause() {

    }

    @Override
    public void onPublish(int progress) {

    }

    @Override
    public void onBufferingUpdate(int percent) {

    }
}
