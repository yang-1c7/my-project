package com.yjq.musiclz.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.yjq.musiclz.R;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.listener.OnViewClickListener;
import com.yjq.musiclz.listener.OnViewLongListener;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 */

public class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.UserListViewHolder> {


    private Context mContext;
    private List<User> mData;

    private OnViewClickListener<User> mOnViewClickListener;
    private OnViewLongListener<User> mOnViewLongListener;

    public void setOnViewClickListener(OnViewClickListener<User> onViewClickListener) {
        this.mOnViewClickListener = onViewClickListener;
    }
    public void setOnViewLongListener(OnViewLongListener<User> onViewLongListener) {
        this.mOnViewLongListener = onViewLongListener;
    }

    public UserListAdapter(Context context, List<User> userList) {
        this.mContext = context;
        this.mData = userList;
    }

    @NonNull
    @Override
    public UserListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new UserListViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_admin_user, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull UserListViewHolder holder, int position) {
        User user = mData.get(position);
        holder.idTvUserName.setText(user.getUserName());
        holder.idClRoot.setOnClickListener(view -> {
            if (mOnViewClickListener != null) {
                mOnViewClickListener.onViewClick(view, user, position);
            }
        });
        holder.idClRoot.setOnLongClickListener(view -> {
            if (mOnViewLongListener != null) {
                mOnViewLongListener.onViewLong(view, user, position);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }


    static class UserListViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.id_cv_user_img)
        CircleImageView idCvUserImg;
        @BindView(R.id.id_tv_user_name)
        TextView idTvUserName;
        @BindView(R.id.id_cl_root)
        ConstraintLayout idClRoot;

        public UserListViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
