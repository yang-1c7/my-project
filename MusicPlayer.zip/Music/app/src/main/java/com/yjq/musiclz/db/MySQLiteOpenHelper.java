package com.yjq.musiclz.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.github.yuweiguocn.library.greendao.MigrationHelper;
import com.yjq.musiclz.db.greendao.DaoMaster;

import org.greenrobot.greendao.database.Database;

/**
 * 数据库升级的时候，那个表升级，在onUpgrade方法里面的migrate中添加那个表（也就是bean对象）,
 *
 *
 *  同时记得  在greendao的gradle中改版本号（也就是schemaVersion ）
 *
 *
 * @version
 */
public class MySQLiteOpenHelper extends DaoMaster.DevOpenHelper {

    public MySQLiteOpenHelper(Context context, String name) {
        this(context, name, null);
    }

    public MySQLiteOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory) {
        super(context, name, factory);
    }

    @Override
    public void onUpgrade(Database db, int oldVersion, int newVersion) {
        MigrationHelper.migrate(db, new MigrationHelper.ReCreateAllTableListener() {

            @Override
            public void onCreateAllTables(Database db, boolean ifNotExists) {
                DaoMaster.createAllTables(db, ifNotExists);
            }

            @Override
            public void onDropAllTables(Database db, boolean ifExists) {
                DaoMaster.dropAllTables(db, ifExists);
            }
        });
//        },TestDataDao.class, TestData2Dao.class, TestData3Dao.class);
    }


}
