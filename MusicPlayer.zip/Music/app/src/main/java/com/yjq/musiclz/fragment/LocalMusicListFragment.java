package com.yjq.musiclz.fragment;

import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.view.RxToast;
import com.yjq.musiclz.R;
import com.yjq.musiclz.activity.MusicDetailsActivity;
import com.yjq.musiclz.adapter.MusicAdapter;
import com.yjq.musiclz.base.BaseFragment;
import com.yjq.musiclz.constants.Extras;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.constants.RequestCode;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.db.model.MusicList;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.UserMusicList;
import com.yjq.musiclz.listener.OnViewClickListener;
import com.yjq.musiclz.loader.MusicLoaderCallback;
import com.yjq.musiclz.utils.AudioPlayer;
import com.yjq.musiclz.utils.SPTool;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class LocalMusicListFragment extends BaseFragment implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener, OnViewClickListener<Music> {

    @BindView(R.id.id_lv_local_music)
    ListView idLvLocalMusic;
    @BindView(R.id.id_tv_searching)
    TextView idTvSearching;

    @Override
    protected int getLayoutResId() {
        return R.layout.fragment_local_music_list;
    }

    private GreenDaoHelper mGreenDaoHelper;
    private MusicAdapter mAdapter;

    private List<Music> musicList;
    private List<UserMusicList> userMusicLists;
    private List<String> titleList;

    @Override
    protected void initView() {
        super.initView();
        idLvLocalMusic.setVisibility(View.GONE);
        idTvSearching.setVisibility(View.VISIBLE);
    }

    @Override
    protected void initData() {
        super.initData();
        mGreenDaoHelper = GreenDaoHelper.getInstance();
        musicList = new ArrayList<>();
        userMusicLists = new ArrayList<>();
        titleList = new ArrayList<>();
        mAdapter = new MusicAdapter(musicList);
        mAdapter.setOnViewClickListener(this);
        idLvLocalMusic.setAdapter(mAdapter);
        loadMusic();
    }


    private void loadMusic() {
        Observable.just(mGreenDaoHelper.queryMusicsByType(0))
                .map(musicListList -> {
//                    FileUtils.copyDb(mContext, Keys.DB_NAME);
                    String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
                    long userId = Keys.DEF_TOURIST_ID;
                    boolean isTourist = true;
                    if (!TextUtils.isEmpty(userInfo)) {
                        User user = new Gson().fromJson(userInfo, User.class);
                        isTourist = false;
                        userId = user.getId() ;
                    }
                    if (musicList.size() == 0) {
                        // 我们新建一个默认的音乐列表
                        MusicList musicList = GreenDaoHelper.getInstance().queryDefMusicList();
                        if (musicList == null) {
                            musicList = new MusicList();
                            musicList.setMusicListName("默认列表");
                            mGreenDaoHelper.insertMusicList(musicList);
                        }
                    }
                    UserMusicList userMusicList = GreenDaoHelper.getInstance().queryUserDefMusicList(userId);
                    if (userMusicList == null) {
                        userMusicList = new UserMusicList();
                        userMusicList.setUserId(userId);
                        //默认都会新建一个 默认列表
                        userMusicList.setMusicListId(Keys.DEF_MUSIC_LIST_ID);
                        mGreenDaoHelper.insertUserMusicList(userMusicList);
                    }

                    if (!isTourist) {
                        userMusicLists = mGreenDaoHelper.queryUserMusicListsNotLove(userId);
                        for (UserMusicList userMusicListTmp : userMusicLists) {
                            titleList.add(mGreenDaoHelper.queryMusicList(userMusicListTmp.getMusicListId()).getMusicListName());
                        }
                    }else{
                        userMusicLists.add(mGreenDaoHelper.queryUserDefMusicList(userId));
                        titleList.add("默认列表");
                    }
                    return mGreenDaoHelper.queryMusicsByType(0);
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(musics -> {
                    Log.i(TAG, "loadMusic: musics.size===" + musics.size());
                    if (musics.size() == 0) {
                        //数据库没有音乐,获取本地的音乐
                        mActivity.getLoaderManager().initLoader(0, null, new MusicLoaderCallback(mContext, music -> {
                            Log.i(TAG, music.size() + "===initLoader: value===" + music.toString());
                            mGreenDaoHelper.insertMusics(music);
                            refreshMusicList(music);
                        }));
                    } else if (musics.size() > 0) {
                        refreshMusicList(musics);
                    }
                });
    }

    /**
     * 刷新音乐列表
     *
     * @param musics
     */
    private void refreshMusicList(List<Music> musics) {
        if (musicList.size() > 0) {
            musicList.clear();
        }
        Log.i(TAG, musics.size() + "====refreshMusicList: musics==" + musics.toString());
        musicList.addAll(musics);
        Log.i(TAG, musicList.size() + "===refreshMusicList: musicList==" + musicList.toString());
        idLvLocalMusic.setVisibility(View.VISIBLE);
        idTvSearching.setVisibility(View.GONE);
        mAdapter.notifyDataSetChanged();
    }


    @Override
    protected void initListener() {
        super.initListener();
        idLvLocalMusic.setOnItemClickListener(this);
        idLvLocalMusic.setOnItemLongClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Music music = musicList.get(position);
        Log.i(TAG, position + "==onItemClick: ==" + music.toString());
        //点击的时候，我们只是播放
        AudioPlayer audioPlayer = AudioPlayer.get();
        audioPlayer.setPlayMusicListId(Keys.LOCAL_MUSIC_LIST_ID);
        audioPlayer.initMusicList();
        audioPlayer.play(position);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
        Log.i(TAG, "onItemLongClick: titleList==" + titleList.toString());
        String[] titles = new String[titleList.size()];
        titleList.toArray(titles);
        Music music = musicList.get(position);
        Log.i(TAG, position + "===onItemLongClick: music==" + music.toString());
        new AlertDialog.Builder(mContext)
                .setTitle("移动到")
                .setItems(titles, (dialog1, which) -> {
                    UserMusicList userMusicList = userMusicLists.get(which);
                    List<Long> musicIdList = userMusicList.getMusicIdList();
                    if (musicIdList == null) {
                        musicIdList = new ArrayList<>();
                    }
                    AudioPlayer audioPlayer = AudioPlayer.get();
                    if (!musicIdList.contains(music.getId())) {
                        musicIdList.add(0, music.getId());
                        userMusicList.setMusicIdList(musicIdList);
                        audioPlayer.addOrUpdate(userMusicList, true);
                    }
                    audioPlayer.setPlayMusicListId(userMusicList.getMusicListId());
                    audioPlayer.initMusicList();
                    audioPlayer.play(0);
                    RxToast.normal("已添加到" + titles[which]);
                }).show();
        return true;
    }

    /**
     * 分享音乐
     */
    private void shareMusic(Music music) {
        File file = new File(music.getPath());
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("audio/*");
        intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
        startActivity(Intent.createChooser(intent, "分享"));
    }

    private void requestSetRingtone(final Music music) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(mContext)) {
            RxToast.normal("没有权限，无法设置铃声，请授予权限");
            Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS);
            intent.setData(Uri.parse("package:" + getContext().getPackageName()));
            startActivityForResult(intent, RequestCode.REQUEST_WRITE_SETTINGS);
        } else {
            setRingtone(music);
        }
    }

    /**
     * 设置铃声
     */
    private void setRingtone(Music music) {
        Uri uri = MediaStore.Audio.Media.getContentUriForPath(music.getPath());
        // 查询音乐文件在媒体库是否存在
        Cursor cursor = getContext().getContentResolver()
                .query(uri, null, MediaStore.MediaColumns.DATA + "=?", new String[]{music.getPath()}, null);
        if (cursor == null) {
            return;
        }
        if (cursor.moveToFirst() && cursor.getCount() > 0) {
            String _id = cursor.getString(0);
            ContentValues values = new ContentValues();
            values.put(MediaStore.Audio.Media.IS_MUSIC, true);
            values.put(MediaStore.Audio.Media.IS_RINGTONE, true);
            values.put(MediaStore.Audio.Media.IS_ALARM, false);
            values.put(MediaStore.Audio.Media.IS_NOTIFICATION, false);
            values.put(MediaStore.Audio.Media.IS_PODCAST, false);

            getContext().getContentResolver()
                    .update(uri, values, MediaStore.MediaColumns.DATA + "=?", new String[]{music.getPath()});
            Uri newUri = ContentUris.withAppendedId(uri, Long.valueOf(_id));
            RingtoneManager.setActualDefaultRingtoneUri(getContext(), RingtoneManager.TYPE_RINGTONE, newUri);
            RxToast.normal("设置铃声成功！");
        }
        cursor.close();
    }

    private void deleteMusic(final Music music) {
        String title = music.getTitle();
        new AlertDialog.Builder(mContext)
                .setMessage("删除" + title)
                .setPositiveButton("删除", (dialog1, which) -> {
                    File file = new File(music.getPath());
                    if (file.delete()) {
                        // 刷新媒体库
                        Intent intent =
                                new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://".concat(music.getPath())));
                        getContext().sendBroadcast(intent);
                    }
                }).setNegativeButton("放弃", null)
                .show();
    }


    @Override
    public void onSaveInstanceState(Bundle outState) {
        int position = idLvLocalMusic.getFirstVisiblePosition();
        int offset = (idLvLocalMusic.getChildAt(0) == null) ? 0 : idLvLocalMusic.getChildAt(0).getTop();
        outState.putInt(Keys.LOCAL_MUSIC_POSITION, position);
        outState.putInt(Keys.LOCAL_MUSIC_OFFSET, offset);
    }

    public void onRestoreInstanceState(final Bundle savedInstanceState) {
        idLvLocalMusic.post(() -> {
            int position = savedInstanceState.getInt(Keys.LOCAL_MUSIC_POSITION);
            int offset = savedInstanceState.getInt(Keys.LOCAL_MUSIC_OFFSET);
            idLvLocalMusic.setSelectionFromTop(position, offset);
        });
    }

    @Override
    public void onViewClick(View view, Music music, int position) {
        new AlertDialog.Builder(mContext)
                .setTitle(music.getTitle())
                .setItems(R.array.local_music_dialog, (dialog1, which) -> {
                    switch (which) {
                        case 0:// 分享
                            shareMusic(music);
                            break;
                        case 1:// 设为铃声
                            requestSetRingtone(music);
                            break;
                        case 2:// 查看歌曲信息
                            Bundle bundle = new Bundle();
                            bundle.putSerializable(Extras.MUSIC_DETAILS, music);
                            RxActivityTool.skipActivityForResult(mActivity, MusicDetailsActivity.class, bundle, RequestCode.REQ_UPDATE_MUSIC);
                            break;
                        case 3:// 删除
                            deleteMusic(music);
                            break;
                    }
                }).show();
    }

    /**
     * 更新音乐信息
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        loadMusic();
    }

}
