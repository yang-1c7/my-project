package com.yjq.musiclz.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.vondear.rxui.view.likeview.RxShineButton;
import com.yjq.musiclz.R;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.model.CommentDetailBean;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.listener.OnViewClickListener;
import com.yjq.musiclz.utils.SPTool;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.hdodenhof.circleimageview.CircleImageView;

/**
 * 评论与回复列表的适配器
 */

public class CommentExpandAdapter extends BaseExpandableListAdapter {
    private static final String TAG = "CommentExpandAdapter";

    private List<CommentDetailBean> commentBeanList;
    private Context context;
    private User mUser;
    private OnViewClickListener<CommentDetailBean> listener;

    public void setOnViewClickListener(OnViewClickListener<CommentDetailBean> listener) {
        this.listener = listener;
    }

    public CommentExpandAdapter(Context context, List<CommentDetailBean> commentBeanList) {
        this.context = context;
        this.commentBeanList = commentBeanList;
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            mUser = new Gson().fromJson(userInfo, User.class);
        }
    }


    /**
     * 添加新的评论
     *
     * @param commentDetailBean
     */
    public void addComment(CommentDetailBean commentDetailBean){
        if(commentDetailBean!=null){
            commentBeanList.add(commentDetailBean);
            notifyDataSetChanged();
        }else {
            throw new IllegalArgumentException("评论数据为空!");
        }
    }

    /**
     * 添加新的评论
     *
     * @param commentBeanListParam
     */
    public void addCommentList(List<CommentDetailBean> commentBeanListParam){
        if(commentBeanListParam!=null && commentBeanListParam.size()>0){
            if (commentBeanList.size()>0) commentBeanList.clear();
            commentBeanList.addAll(commentBeanListParam);
            notifyDataSetChanged();
        }else {
            throw new IllegalArgumentException("评论数据为空!");
        }
    }

    @Override
    public int getGroupCount() {
        return commentBeanList.size();
    }

    @Override
    public int getChildrenCount(int i) {
        if (commentBeanList.get(i).getReplyList() == null) {
            return 0;
        } else {
            return commentBeanList.get(i).getReplyList().size() > 0 ? commentBeanList.get(i).getReplyList().size() : 0;
        }

    }

    @Override
    public Object getGroup(int i) {
        return commentBeanList.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {
        return commentBeanList.get(i).getReplyList().get(i1);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return getCombinedChildId(groupPosition, childPosition);
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }


    @Override
    public View getGroupView(final int groupPosition, boolean isExpand, View convertView, ViewGroup viewGroup) {
        final GroupHolder groupHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.comment_item_layout, viewGroup, false);
            groupHolder = new GroupHolder(convertView);
            convertView.setTag(groupHolder);
        } else {
            groupHolder = (GroupHolder) convertView.getTag();
        }
        CommentDetailBean commentDetailBean = commentBeanList.get(groupPosition);
        Glide.with(context).load(R.drawable.user_other)
                .diskCacheStrategy(DiskCacheStrategy.RESULT)
                .error(R.mipmap.ic_launcher)
                .centerCrop()
                .into(groupHolder.commentItemLogo);
        groupHolder.commentItemUserName.setText(commentDetailBean.getUser().getUserName());
        groupHolder.commentItemTime.setText(commentDetailBean.getCreateDate());
        groupHolder.commentItemContent.setText(commentDetailBean.getContent());
        List<Long> loveUserList = commentDetailBean.getLoveUserIdList()==null ? new ArrayList<>() : commentDetailBean.getLoveUserIdList();
        boolean isChecked = loveUserList.contains(mUser.getId());
        groupHolder.commentItemLike.setChecked(isChecked);
        groupHolder.commentItemLike.setOnClickListener(view -> {
            if (loveUserList.contains(mUser.getId())){
                loveUserList.remove(mUser.getId());
            }else{
                loveUserList.add(mUser.getId());
            }
            groupHolder.commentItemLike.setChecked(loveUserList.contains(mUser.getId()));
            commentDetailBean.setLoveUserIdList(loveUserList);
            if (listener != null) {
                listener.onViewClick(groupHolder.commentItemLike, commentDetailBean, groupPosition);
            }
            Log.i(TAG, "getView: loveUserList==" + loveUserList.toString());
        });

        return convertView;
    }

    @Override
    public View getChildView(final int groupPosition, int childPosition, boolean b, View convertView, ViewGroup viewGroup) {
        final ChildHolder childHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.comment_reply_item_layout, viewGroup, false);
            childHolder = new ChildHolder(convertView);
            convertView.setTag(childHolder);
        } else {
            childHolder = (ChildHolder) convertView.getTag();
        }

        String replyUser = commentBeanList.get(groupPosition).getReplyList().get(childPosition).getUser().getUserName();
        if (!TextUtils.isEmpty(replyUser)) {
            childHolder.replyItemUser.setText(replyUser + ":");
        } else {
            childHolder.replyItemUser.setText("无名" + ":");
        }

        childHolder.replyItemContent.setText(commentBeanList.get(groupPosition).getReplyList().get(childPosition).getContent());

        return convertView;
    }

    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }

    static class GroupHolder {
        @BindView(R.id.comment_item_logo)
        CircleImageView commentItemLogo;
        @BindView(R.id.comment_item_userName)
        TextView commentItemUserName;
        @BindView(R.id.comment_item_time)
        TextView commentItemTime;
        @BindView(R.id.comment_item_like)
        RxShineButton commentItemLike;
        @BindView(R.id.comment_item_content)
        TextView commentItemContent;

        public GroupHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

    static class ChildHolder {
        @BindView(R.id.reply_item_user)
        TextView replyItemUser;
        @BindView(R.id.reply_item_content)
        TextView replyItemContent;

        public ChildHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

}
