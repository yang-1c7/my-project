package com.yjq.musiclz.base;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import com.vondear.rxtool.RxActivityTool;
import com.vondear.rxtool.RxBarTool;
import com.vondear.rxtool.view.RxToast;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.PermissionListener;
import com.yjq.musiclz.R;
import com.yjq.musiclz.service.PlayService;
import com.yjq.musiclz.utils.ShakeHelper;

import java.util.List;

import butterknife.ButterKnife;

/**
 * Created by boys on 2018/10/11.
 */

public abstract class BaseActivity extends AppCompatActivity {

    protected final String TAG = this.getClass().getSimpleName();

    /**
     * 上下文生命周期
     */
    protected Context mContext;
    protected BaseActivity mActivity;

    /**
     * 权限对应的标示
     */
    public final int REQUEST_CODE_DEFAULT = 100;
    public final int REQUEST_CODE_SETTING = 300;

    protected PlayServiceConnection serviceConnection;
    protected PlayService playService;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        mActivity = this;
        if (getStatusBarColor() != -1){
            RxBarTool.setStatusBarColor(mActivity, getStatusBarColor());
        }
        // 设置页面布局并且绑定数据
        if (getLayoutResId() != -1) {
            setContentView(getLayoutResId());
            //绑定初始化ButterKnife
            ButterKnife.bind(mActivity);
        }

        initParam(savedInstanceState);
        //初始化view
        initView();
        initData();
        bindService();
        initListener();

        RxActivityTool.addActivity(mActivity);
    }

    protected int getStatusBarColor() {
        return R.color.common_color_01;
    }

    /**
     * 初始化参数
     *
     * @param savedInstanceState
     */
    protected void initParam(Bundle savedInstanceState) {

    }

    /**
     * 初始化view
     */
    protected void initView(){

    }

    /**
     * 初始化data 也就是初始化数据
     */
    protected abstract void initData();

    /**
     * 初始化监听
     */
    protected abstract void initListener();

    /**
     * 获取要绑定的layoutId
     *
     * @return
     */
    @LayoutRes
    protected abstract int getLayoutResId();


    private void bindService() {
        Intent intent = new Intent();
        intent.setClass(this, PlayService.class);
        serviceConnection = new PlayServiceConnection();
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private class PlayServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            playService = ((PlayService.PlayBinder) service).getService();
            onServiceBound();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e(getClass().getSimpleName(), "service disconnected");
        }
    }

    protected void onServiceBound() {
    }


    /**
     * 处理edittext的空
     *
     * @param editText
     */
    public void handleEtEmpty(EditText editText) {
        ShakeHelper.shake(editText);
        editText.setText("");
        editText.requestFocus();
        editText.setFocusable(true);
        editText.setFocusableInTouchMode(true);
    }

    /**
     * 判断edittext的值是否为空
     *
     * @param editText
     */
    public boolean isEtEmpty(String content, String msg, EditText editText) {
        if (TextUtils.isEmpty(content)){
            RxToast.normal(msg);
            ShakeHelper.shake(editText);
            return true;
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        if (serviceConnection != null) {
            unbindService(serviceConnection);
        }
        super.onDestroy();
        RxActivityTool.finishActivity(mActivity);
    }

    /**
     * 是否全屏
     *
     * @param activity
     * @return
     */
    public boolean isFullScreen(Activity activity) {
        return (activity.getWindow().getAttributes().flags &
                WindowManager.LayoutParams.FLAG_FULLSCREEN) == WindowManager.LayoutParams.FLAG_FULLSCREEN;
    }

    /**
     * 检查需要的权限
     */
    public void checkPermission(String... permissions) {
        AndPermission.with(mActivity)
                .requestCode(REQUEST_CODE_DEFAULT)
                .permission(permissions)
                .send();
    }

    /**
     * 判断用户是否授予权限
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        AndPermission.onRequestPermissionsResult(requestCode, permissions, grantResults, listener);
    }

    private PermissionListener listener = new PermissionListener() {
        @Override
        public void onSucceed(int requestCode, List<String> grantPermissions) {
            permissionGrant(requestCode, grantPermissions);
        }

        @Override
        public void onFailed(int requestCode, List<String> deniedPermissions) {
            if (AndPermission.hasAlwaysDeniedPermission(mActivity, deniedPermissions)) {
                // 第一种：用默认的提示语。
                AndPermission.defaultSettingDialog(mActivity, REQUEST_CODE_SETTING).show();
            }
            mActivity.finish();
        }
    };

    /**
     * 用户授权通过的操作
     *
     * @param requestCode
     * @param grantPermissions
     */
    protected void permissionGrant(int requestCode, List<String> grantPermissions) {

    }

    /**
     * 设置每个activity的common title
     *
     * @param idTlMain
     * @param idTvTlTitle
     * @param title
     */
    protected void setTlTitle(Toolbar idTlMain, TextView idTvTlTitle, String title) {
        setSupportActionBar(idTlMain);
        //不显示toolbar的标题
        idTvTlTitle.setText(title);
        setSupportActionBar(idTlMain);
        //不显示toolbar的标题
        idTvTlTitle.setVisibility(View.VISIBLE);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        //设置导航栏图标
        idTlMain.setNavigationIcon(R.mipmap.ic_back); //设置导航按钮图标
    }


    public void showProgress() {
        showProgress(getString(R.string.loading));
    }

    private ProgressDialog progressDialog;

    public void showProgress(String message) {
        if (progressDialog == null) {
            progressDialog = new ProgressDialog(this);
            progressDialog.setCancelable(false);
        }
        progressDialog.setMessage(message);
        if (!progressDialog.isShowing()) {
            progressDialog.show();
        }
    }

    public void cancelProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.cancel();
        }
    }

}
