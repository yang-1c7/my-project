package com.yjq.musiclz.listener;

import android.view.View;

/**
 */

public interface OnViewLongListener<T> {

    /**
     * view的长按事件
     *
     * @param view
     * @param t
     * @param position
     */
    void onViewLong(View view, T t, int position);
}
