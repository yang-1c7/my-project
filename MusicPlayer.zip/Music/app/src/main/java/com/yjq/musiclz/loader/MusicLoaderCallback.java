package com.yjq.musiclz.loader;

import android.app.LoaderManager;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.webkit.ValueCallback;

import com.yjq.musiclz.db.model.Music;
import com.yjq.musiclz.utils.SystemUtils;

import java.util.ArrayList;
import java.util.List;

/**
 *
 *
 */

public class MusicLoaderCallback implements LoaderManager.LoaderCallbacks<Cursor> {

    private Context mContext;

    private ValueCallback<List<Music>> mMusicCallback;

    public MusicLoaderCallback(Context context, ValueCallback<List<Music>> musicCallback) {
        this.mContext = context;
        this.mMusicCallback = musicCallback;
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        return new CursorLoader(mContext, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                new String[]{
                        MediaStore.Audio.AudioColumns._ID,
                        MediaStore.Audio.AudioColumns.IS_MUSIC,
                        MediaStore.Audio.AudioColumns.TITLE,
                        MediaStore.Audio.AudioColumns.ARTIST,
                        MediaStore.Audio.AudioColumns.ALBUM,
                        MediaStore.Audio.AudioColumns.ALBUM_ID,
                        MediaStore.Audio.AudioColumns.DATA,
                        MediaStore.Audio.AudioColumns.DISPLAY_NAME,
                        MediaStore.Audio.AudioColumns.SIZE,
                        MediaStore.Audio.AudioColumns.DURATION
                }, MediaStore.Audio.Media.MIME_TYPE + "= ?", new String[]{"audio/mpeg"},
                MediaStore.Audio.Media.DATE_MODIFIED + " desc");
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        if (data == null) {
            return;
        }
        int count = 0;
        List<Music> musicList = new ArrayList<>();
        while (data.moveToNext()) {
            // 是否为音乐，魅族手机上始终为0
            int isMusic = data.getInt(data.getColumnIndex(MediaStore.Audio.AudioColumns.IS_MUSIC));
            if (!SystemUtils.isFlyme() && isMusic == 0) {
                continue;
            }

            long id = data.getLong(data.getColumnIndex(BaseColumns._ID));
            String title = data.getString(data.getColumnIndex(MediaStore.Audio.AudioColumns.TITLE));
            String artist = data.getString(data.getColumnIndex(MediaStore.Audio.AudioColumns.ARTIST));
            String album = data.getString(data.getColumnIndex(MediaStore.Audio.AudioColumns.ALBUM));
            long albumId = data.getLong(data.getColumnIndex(MediaStore.Audio.AudioColumns.ALBUM_ID));
            String path = data.getString(data.getColumnIndex(MediaStore.Audio.AudioColumns.DATA));
            String fileName = data.getString(data.getColumnIndex(MediaStore.Audio.AudioColumns.DISPLAY_NAME));
            long duration = data.getLong(data.getColumnIndex(MediaStore.Audio.Media.DURATION));
            long fileSize = data.getLong(data.getColumnIndex(MediaStore.Audio.Media.SIZE));

            Music music = new Music();
            music.setSongId(String.valueOf(id));
            music.setType(Music.Type.LOCAL);
            music.setTitle(title);
            music.setArtist(artist);
            music.setAlbum(album);
            music.setAlbumId(albumId);
            music.setDuration(duration);
            music.setPath(path);
            music.setFileName(fileName);
            music.setFileSize(fileSize);

            if (++count <= 20) {
                // 只加载前20首的缩略图
                CoverLoader.get().loadThumb(music);
            }
            musicList.add(music);
        }
        if (mMusicCallback != null) {
            mMusicCallback.onReceiveValue(musicList);
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader loader) {

    }
}
