package com.yjq.musiclz.adapter;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.vondear.rxui.view.likeview.RxShineButton;
import com.yjq.musiclz.R;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.model.CommentDetailBean;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.VideoBean;
import com.yjq.musiclz.listener.OnViewClickListener;
import com.yjq.musiclz.utils.SPTool;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.hdodenhof.circleimageview.CircleImageView;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayer;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayerStandard;

/**
 * 视频的适配器
 */

public class VideoAdapter extends BaseAdapter {
    private static final String TAG = "VideoAdapter";
    private List<VideoBean> videoBeanList;
    private OnViewClickListener<VideoBean> listener;
    private Context mContext;

    private User mUser;

    public VideoAdapter(List<VideoBean> videoBeanList, Context context) {
        this.videoBeanList = videoBeanList;
        this.mContext = context;
        refreshUser();
    }

    public void setOnViewClickListener(OnViewClickListener listener) {
        this.listener = listener;
    }


    /**
     * 刷新用户的信息
     *
     */
    public void refreshUser(){
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            mUser = new Gson().fromJson(userInfo, User.class);
        }
    }

    /**
     * 刷新用户的信息
     *
     */
    public void refreshVideoList(List<VideoBean> videoList){
        if (videoBeanList.size()>0) videoBeanList.clear();
        videoBeanList.addAll(videoList);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return videoBeanList.size();
    }

    @Override
    public Object getItem(int position) {
        return videoBeanList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @TargetApi(Build.VERSION_CODES.N)
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        VideoBean videoBean = videoBeanList.get(position);
        VideoViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video, parent, false);
            holder = new VideoViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (VideoViewHolder) convertView.getTag();
        }
        Glide.with(mContext)
                .load(videoBean.getPublishHead())
                .into(holder.idCivHead);
        List<Long> loveUserList = videoBean.getLoveUserIdList()==null ? new ArrayList<>() : videoBean.getLoveUserIdList();
        Log.i(TAG, "getView: videoBean==" + videoBean.toString());
        if (mUser == null) {
            holder.idRsbVideoLoves.setChecked(false);
        }else{
            boolean isChecked = loveUserList.contains(mUser.getId());
            holder.idRsbVideoLoves.setChecked(isChecked);
        }
        holder.idTvVideoLoves.setText(String.valueOf(loveUserList.size()));
        holder.idRsbVideoLoves.setOnClickListener(v -> {
            if (mUser == null) {
                //游客不能点赞
                holder.idRsbVideoLoves.setChecked(false);
                if (listener != null) {
                    listener.onViewClick(holder.idRsbVideoLoves, null, position);
                }
                return;
            }
            if (loveUserList.contains(mUser.getId())){
                loveUserList.remove(mUser.getId());
            }else{
                loveUserList.add(mUser.getId());
            }
            holder.idRsbVideoLoves.setChecked(loveUserList.contains(mUser.getId()));
            Log.i(TAG, "getView: loveUserList==" + loveUserList.toString());
            holder.idTvVideoLoves.setText(String.valueOf(loveUserList.size()));
            videoBean.setLoveUserIdList(loveUserList);
            if (listener != null) {
                listener.onViewClick(holder.idRsbVideoLoves, videoBean, position);
            }
        });

        holder.idIvVideoComment.setOnClickListener(v -> {
            if (mUser == null) {
                //游客不能评论
                if (listener != null) {
                    listener.onViewClick(holder.idIvVideoComment, null, position);
                }
                return;
            }

            if (listener != null) {
                listener.onViewClick(holder.idIvVideoComment, videoBean, position);
            }
        });

        holder.idTvVideoDesc.setOnClickListener(v -> {
            if (mUser == null) {
                //游客不能查看详情
                if (listener != null) {
                    listener.onViewClick(holder.idTvVideoDesc, null, position);
                }
                return;
            }

            if (listener != null) {
                listener.onViewClick(holder.idTvVideoDesc, videoBean, position);
            }
        });

        holder.idIvVideoShare.setOnClickListener(v -> {
            if (mUser == null) {
                //游客不能分享
                if (listener != null) {
                    listener.onViewClick(holder.idIvVideoShare, null, position);
                }
                return;
            }

            if (listener != null) {
                listener.onViewClick(holder.idIvVideoShare, videoBean, position);
            }
        });

        holder.idTvVideoPublishName.setText(videoBean.getPublishName());
        holder.idTvVideoDesc.setText(videoBean.getVideoDesc());
        boolean setUp = holder.idJcvpsVideo.setUp(videoBean.getVideoUrl(), JCVideoPlayer.SCREEN_LAYOUT_LIST,
                "");
        if (setUp) {
            Glide.with(mContext).load(videoBean.getVideoCoverUrl()).into(holder.idJcvpsVideo.thumbImageView);
        }
        List<CommentDetailBean> commentDetailBeanList = videoBean.getCommentDetailBeanList();
        commentDetailBeanList = commentDetailBeanList == null ? new ArrayList<>() : commentDetailBeanList;
        int commentSize = commentDetailBeanList.size();
        for (int i = 0; i < commentDetailBeanList.size(); i++) {
            commentSize += commentDetailBeanList.get(i).getReplyList().size();
        }
        holder.idTvVideoComment.setText(String.valueOf(commentSize));

        return convertView;
    }


    static class VideoViewHolder {
        @BindView(R.id.id_civ_head)
        CircleImageView idCivHead;
        @BindView(R.id.id_tv_video_publish_name)
        TextView idTvVideoPublishName;
        @BindView(R.id.id_tv_video_type)
        TextView idTvVideoType;
        @BindView(R.id.id_tv_video_desc)
        TextView idTvVideoDesc;
        @BindView(R.id.id_jcvps_video)
        JCVideoPlayerStandard idJcvpsVideo;
        @BindView(R.id.id_iv_video_share)
        ImageView idIvVideoShare;
        @BindView(R.id.id_rsb_video_loves)
        RxShineButton idRsbVideoLoves;
        @BindView(R.id.id_tv_video_loves)
        TextView idTvVideoLoves;
        @BindView(R.id.id_iv_video_comment)
        ImageView idIvVideoComment;
        @BindView(R.id.id_tv_video_comment)
        TextView idTvVideoComment;

        VideoViewHolder(View view) {
            ButterKnife.bind(this, view);
        }
    }

}
