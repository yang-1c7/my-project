package com.yjq.musiclz.db.model;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * 音乐列表
 *
 */
@Entity(nameInDb = "tb_music_list")
public class MusicList {

    @Id(autoincrement = true)
    @Property(nameInDb = "id")
    private Long id;

    @NotNull
    @Property(nameInDb = "music_list_name")
    private String musicListName;//音乐列表的名字

    @Generated(hash = 1957617598)
    public MusicList(Long id, @NotNull String musicListName) {
        this.id = id;
        this.musicListName = musicListName;
    }

    @Generated(hash = 1135234633)
    public MusicList() {
    }

    @Override
    public String toString() {
        return "MusicList{" +
                "id=" + id +
                '}';
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMusicListName() {
        return this.musicListName;
    }

    public void setMusicListName(String musicListName) {
        this.musicListName = musicListName;
    }

}
