package com.yjq.musiclz.db.model;

import com.yjq.musiclz.db.converter.LongConverter;
import com.yjq.musiclz.db.greendao.CommentDetailBeanDao;
import com.yjq.musiclz.db.greendao.DaoSession;
import com.yjq.musiclz.db.greendao.VideoBeanDao;

import org.greenrobot.greendao.DaoException;
import org.greenrobot.greendao.annotation.Convert;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.NotNull;
import org.greenrobot.greendao.annotation.ToMany;

import java.util.List;

/**
 * 视频播放相关的对象
 *
 */
@Entity(nameInDb = "tb_video")
public class VideoBean {

    @Id(autoincrement = true)
    private Long id;

    @NotNull
    private String videoUrl;

    @NotNull
    private String videoCoverUrl;
    @NotNull
    private String publishName;
    private int publishHead;
    @NotNull
    private String videoDesc;

    /**
     * 点赞的人数  一个用户只能对一个视频或者一个评论点赞
     *
     */
    @Convert(columnType = String.class, converter = LongConverter.class)
    private List<Long> loveUserIdList;

    @ToMany(referencedJoinProperty  = "videoId")
    //一对多的关系,一个视频 可以对应多个评论详情
    List<CommentDetailBean> commentDetailBeanList;

    /** Used to resolve relations */
    @Generated(hash = 2040040024)
    private transient DaoSession daoSession;

    /** Used for active entity operations. */
    @Generated(hash = 887466489)
    private transient VideoBeanDao myDao;

    @Generated(hash = 2024490299)
    public VideoBean() {
    }


    @Generated(hash = 941753186)
    public VideoBean(Long id, @NotNull String videoUrl, @NotNull String videoCoverUrl,
            @NotNull String publishName, int publishHead, @NotNull String videoDesc,
            List<Long> loveUserIdList) {
        this.id = id;
        this.videoUrl = videoUrl;
        this.videoCoverUrl = videoCoverUrl;
        this.publishName = publishName;
        this.publishHead = publishHead;
        this.videoDesc = videoDesc;
        this.loveUserIdList = loveUserIdList;
    }


    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getPublishName() {
        return publishName;
    }

    public void setPublishName(String publishName) {
        this.publishName = publishName;
    }

    public int getPublishHead() {
        return publishHead;
    }

    public void setPublishHead(int publishHead) {
        this.publishHead = publishHead;
    }

    public String getVideoDesc() {
        return videoDesc;
    }

    public void setVideoDesc(String videoDesc) {
        this.videoDesc = videoDesc;
    }

    public List<Long> getLoveUserIdList() {
        return loveUserIdList;
    }

    public void setLoveUserIdList(List<Long> loveUserIdList) {
        this.loveUserIdList = loveUserIdList;
    }

    public String getVideoCoverUrl() {
        return videoCoverUrl;
    }

    public void setVideoCoverUrl(String videoCoverUrl) {
        this.videoCoverUrl = videoCoverUrl;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "VideoBean{" +
                "id=" + id +
                ", videoUrl='" + videoUrl + '\'' +
                ", videoCoverUrl='" + videoCoverUrl + '\'' +
                ", publishName='" + publishName + '\'' +
                ", publishHead=" + publishHead +
                ", videoDesc='" + videoDesc + '\'' +
                ", loveUserIdList=" + loveUserIdList +
                ", commentDetailBeanList=" + commentDetailBeanList +
                ", daoSession=" + daoSession +
                ", myDao=" + myDao +
                '}';
    }

    /**
     * To-many relationship, resolved on first access (and after reset).
     * Changes to to-many relations are not persisted, make changes to the target entity.
     */
    @Generated(hash = 1610161040)
    public List<CommentDetailBean> getCommentDetailBeanList() {
        if (commentDetailBeanList == null) {
            final DaoSession daoSession = this.daoSession;
            if (daoSession == null) {
                throw new DaoException("Entity is detached from DAO context");
            }
            CommentDetailBeanDao targetDao = daoSession.getCommentDetailBeanDao();
            List<CommentDetailBean> commentDetailBeanListNew = targetDao
                    ._queryVideoBean_CommentDetailBeanList(id);
            synchronized (this) {
                if (commentDetailBeanList == null) {
                    commentDetailBeanList = commentDetailBeanListNew;
                }
            }
        }
        return commentDetailBeanList;
    }

    /** Resets a to-many relationship, making the next get call to query for a fresh result. */
    @Generated(hash = 957366288)
    public synchronized void resetCommentDetailBeanList() {
        commentDetailBeanList = null;
    }

    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#delete(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 128553479)
    public void delete() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.delete(this);
    }

    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#refresh(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 1942392019)
    public void refresh() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.refresh(this);
    }

    /**
     * Convenient call for {@link org.greenrobot.greendao.AbstractDao#update(Object)}.
     * Entity must attached to an entity context.
     */
    @Generated(hash = 713229351)
    public void update() {
        if (myDao == null) {
            throw new DaoException("Entity is detached from DAO context");
        }
        myDao.update(this);
    }

    /** called by internal mechanisms, do not call yourself. */
    @Generated(hash = 127927444)
    public void __setDaoSession(DaoSession daoSession) {
        this.daoSession = daoSession;
        myDao = daoSession != null ? daoSession.getVideoBeanDao() : null;
    }
}
