package com.yjq.musiclz.activity;


import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialog;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.vondear.rxtool.RxTimeTool;
import com.vondear.rxtool.view.RxToast;
import com.vondear.rxui.view.likeview.RxShineButton;
import com.yjq.musiclz.R;
import com.yjq.musiclz.adapter.CommentExpandAdapter;
import com.yjq.musiclz.base.BaseActivity;
import com.yjq.musiclz.constants.Keys;
import com.yjq.musiclz.db.GreenDaoHelper;
import com.yjq.musiclz.db.model.CommentDetailBean;
import com.yjq.musiclz.db.model.ReplyDetailBean;
import com.yjq.musiclz.db.model.User;
import com.yjq.musiclz.db.model.VideoBean;
import com.yjq.musiclz.utils.SPTool;
import com.yjq.musiclz.view.CommentExpandableListView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import de.hdodenhof.circleimageview.CircleImageView;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayer;
import fm.jiecao.jcvideoplayer_lib.JCVideoPlayerStandard;

public class VideoDetailActivity extends BaseActivity implements View.OnClickListener{


    @BindView(R.id.detail_page_image)
    JCVideoPlayerStandard detailPageImage;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.collapsing_toolbar)
    CollapsingToolbarLayout collapsingToolbar;
    @BindView(R.id.appbar)
    AppBarLayout appbar;
    @BindView(R.id.detail_page_userLogo)
    CircleImageView detailPageUserLogo;
    @BindView(R.id.detail_page_userName)
    TextView detailPageUserName;
    @BindView(R.id.detail_page_time)
    TextView detailPageTime;
    @BindView(R.id.detail_page_focus)
    RxShineButton detailPageFocus;
    @BindView(R.id.detail_page_above_container)
    LinearLayout detailPageAboveContainer;
    @BindView(R.id.detail_page_lv_comment)
    CommentExpandableListView detailPageLvComment;
    @BindView(R.id.detail_page_comment_container)
    LinearLayout detailPageCommentContainer;
    @BindView(R.id.main_content)
    CoordinatorLayout mainContent;
    @BindView(R.id.detail_page_do_comment)
    TextView detailPageDoComment;

    private CommentExpandAdapter mCommentExpandAdapter;
    private BottomSheetDialog dialog;
    private VideoBean mVideoBean;
    private GreenDaoHelper mGreenDaoHelper;

    private User mUser;


    @Override
    protected void initView() {
        super.initView();
    }

    @Override
    protected void initData() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        collapsingToolbar.setTitle("详情");
        mGreenDaoHelper = GreenDaoHelper.getInstance();
        Intent intent = getIntent();
        if (intent != null) {
            long videoId = intent.getLongExtra(Keys.VIDEO_ID, 0);
            mVideoBean = mGreenDaoHelper.queryVideoById(videoId);
            Log.i(TAG, "initData: mVideoBean===" + mVideoBean.toString());
        }
        String userInfo = (String) SPTool.getInstanse().getParam(Keys.USER_INFO, "");
        if (!TextUtils.isEmpty(userInfo)) {
            mUser = new Gson().fromJson(userInfo, User.class);
        }
        boolean setUp = detailPageImage.setUp(mVideoBean.getVideoUrl(), JCVideoPlayer.SCREEN_LAYOUT_LIST,
                "");
        detailPageImage.backButton.setVisibility(View.VISIBLE);
        detailPageImage.backButton.setOnClickListener(v -> mActivity.finish());
        if (setUp) {
            Glide.with(mContext).load(mVideoBean.getVideoCoverUrl()).into(detailPageImage.thumbImageView);
        }
        Glide.with(mContext).load(mVideoBean.getPublishHead()).into(detailPageUserLogo);
        detailPageUserName.setText(mVideoBean.getPublishName());
        detailPageTime.setText(mVideoBean.getVideoDesc());
        List<Long> loveUserList = mVideoBean.getLoveUserIdList() == null ? new ArrayList<>() : mVideoBean.getLoveUserIdList();
        if (mUser == null) {
            detailPageFocus.setChecked(false);
        }else{
            detailPageFocus.setChecked(loveUserList.contains(mUser.getId()));
        }
        initExpandableListView(mVideoBean.getCommentDetailBeanList());

    }

    @Override
    protected void initListener() {
        detailPageDoComment.setOnClickListener(this);
        detailPageFocus.setOnClickListener(this);
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_video_detail;
    }

    /**
     * 初始化评论和回复列表
     */
    private void initExpandableListView(final List<CommentDetailBean> commentList){
        detailPageLvComment.setGroupIndicator(null);
        //默认展开所有回复
        mCommentExpandAdapter = new CommentExpandAdapter(mContext, commentList);
        mCommentExpandAdapter.setOnViewClickListener((view, commentDetailBean, position) -> {
            commentDetailBean.update();
        });
        detailPageLvComment.setAdapter(mCommentExpandAdapter);
        for(int i = 0; i<commentList.size(); i++){
            detailPageLvComment.expandGroup(i);
        }
        detailPageLvComment.setOnGroupClickListener((expandableListView, view, groupPosition, l) -> {
            boolean isExpanded = expandableListView.isGroupExpanded(groupPosition);
            Log.e(TAG, "onGroupClick: 当前的评论的详情>>>"+commentList.get(groupPosition).toString());
//                if(isExpanded){
//                    expandableListView.collapseGroup(groupPosition);
//                }else {
//                    expandableListView.expandGroup(groupPosition, true);
//                }
            showReplyDialog(groupPosition, commentList.get(groupPosition));
            return true;
        });

        detailPageLvComment.setOnChildClickListener((expandableListView, view, groupPosition, childPosition, l) -> {
            Log.i(TAG, "onChildClick: 点击了回复");
//                RxToast.normal("点击了回复");
            return false;
        });

        detailPageLvComment.setOnGroupExpandListener(groupPosition -> {
            //toast("展开第"+groupPosition+"个分组");

        });

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.detail_page_do_comment:
                showCommentDialog();
                break;
            case R.id.detail_page_focus:
                List<Long> loveUserList = mVideoBean.getLoveUserIdList();
                if (loveUserList.contains(mUser.getId())){
                    loveUserList.remove(mUser.getId());
                }else{
                    loveUserList.add(mUser.getId());
                }
                detailPageFocus.setChecked(loveUserList.contains(mUser.getId()));
                mVideoBean.setLoveUserIdList(loveUserList);
                break;
        }
    }

    /**
     * 弹出评论框
     */
    private void showCommentDialog(){
        dialog = new BottomSheetDialog(this);
        View commentView = LayoutInflater.from(this).inflate(R.layout.comment_dialog_layout,null);
        final EditText commentText = commentView.findViewById(R.id.dialog_comment_et);
        final Button bt_comment = commentView.findViewById(R.id.dialog_comment_bt);
        dialog.setContentView(commentView);
        /**
         * 解决bsd显示不全的情况
         */
        View parent = (View) commentView.getParent();
        BottomSheetBehavior behavior = BottomSheetBehavior.from(parent);
        commentView.measure(0,0);
        behavior.setPeekHeight(commentView.getMeasuredHeight());

        bt_comment.setOnClickListener(view -> {
            String commentContent = commentText.getText().toString().trim();
            if(!TextUtils.isEmpty(commentContent)){
                dialog.dismiss();
                CommentDetailBean detailBean = new CommentDetailBean();
                detailBean.setUserId(mUser.getId());
                detailBean.setVideoId(mVideoBean.getId());
                detailBean.setCreateDate(RxTimeTool.getCurrentDateTime("yyyy-MM-dd HH:mm"));
                detailBean.setContent(commentContent);
                mGreenDaoHelper.insertCommentDetail(detailBean);
                mVideoBean.resetCommentDetailBeanList();
                mCommentExpandAdapter.addCommentList(mVideoBean.getCommentDetailBeanList());
                Log.i(TAG, "showCommentDialog: mVideoBean===" + mVideoBean.toString());
                RxToast.normal("评论成功");
            }else {
                RxToast.normal("评论内容不能为空");
            }
        });
        commentText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!TextUtils.isEmpty(charSequence) && charSequence.length()>2){
                    bt_comment.setBackgroundColor(Color.parseColor("#FFB568"));
                }else {
                    bt_comment.setBackgroundColor(Color.parseColor("#D8D8D8"));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        dialog.show();
    }

    /**
     * 弹出回复框
     */
    private void showReplyDialog(final int position, CommentDetailBean commentDetailBean){
        dialog = new BottomSheetDialog(this);
        View commentView = LayoutInflater.from(this).inflate(R.layout.comment_dialog_layout,null);
        final EditText commentText = commentView.findViewById(R.id.dialog_comment_et);
        final Button bt_comment = commentView.findViewById(R.id.dialog_comment_bt);
        commentText.setHint("回复 " + mVideoBean.getCommentDetailBeanList().get(position).getUser().getUserName() + " 的评论:");
        dialog.setContentView(commentView);
        bt_comment.setOnClickListener(view -> {
            String replyContent = commentText.getText().toString().trim();
            if(!TextUtils.isEmpty(replyContent)){
                dialog.dismiss();
                ReplyDetailBean replyDetailBean = new ReplyDetailBean();
                replyDetailBean.setUserId(mUser.getId());
                replyDetailBean.setContent(replyContent);
                replyDetailBean.setCreateDate(RxTimeTool.getCurrentDateTime("yyyy-MM-dd HH:mm"));
                replyDetailBean.setCommentId(commentDetailBean.getId());
                mGreenDaoHelper.insertReplyDetail(replyDetailBean);
                commentDetailBean.resetReplyList();
                commentDetailBean.getReplyList();
                Log.i(TAG, "showReplyDialog: commentDetailBean.getReplyList()==" +commentDetailBean.getReplyList().toString());
                mCommentExpandAdapter.notifyDataSetChanged();
                detailPageLvComment.expandGroup(position);
                RxToast.normal("回复成功");
            }else {
                RxToast.normal("回复内容不能为空");
            }
        });
        commentText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!TextUtils.isEmpty(charSequence) && charSequence.length()>2){
                    bt_comment.setBackgroundColor(Color.parseColor("#FFB568"));
                }else {
                    bt_comment.setBackgroundColor(Color.parseColor("#D8D8D8"));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        dialog.show();
    }

}
