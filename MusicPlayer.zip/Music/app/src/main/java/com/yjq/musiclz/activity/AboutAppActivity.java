package com.yjq.musiclz.activity;

import android.support.v7.widget.Toolbar;
import android.widget.TextView;

import com.yjq.musiclz.R;
import com.yjq.musiclz.base.BaseActivity;

import butterknife.BindView;

public class AboutAppActivity extends BaseActivity {

    @BindView(R.id.id_tv_tl_title)
    TextView idTvTlTitle;
    @BindView(R.id.id_tl_main)
    Toolbar idTlMain;

    @Override
    protected void initView() {
        super.initView();
        setTlTitle(idTlMain, idTvTlTitle, "关于App");
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initListener() {
        idTlMain.setNavigationOnClickListener(view -> mActivity.finish());
    }

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_about_app;
    }
}
