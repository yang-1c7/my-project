package com.yjq.musiclz.db.converter;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.greenrobot.greendao.converter.PropertyConverter;

import java.util.List;

/**
 * grendao 存储List<Long> 集合
 */

public class LongConverter implements PropertyConverter<List<Long>, String> {

    private final Gson mGson;

    public LongConverter() {
        mGson = new Gson();
    }

    @Override
    public List<Long> convertToEntityProperty(String databaseValue) {
        if (databaseValue == null) {
            return null;
        } else {
            return mGson.fromJson(databaseValue, new TypeToken<List<Long>>() {
            }.getType());
        }
    }

    @Override
    public String convertToDatabaseValue(List<Long> entityProperty) {
        if (entityProperty == null) {
            return null;
        } else {
            return mGson.toJson(entityProperty);
        }
    }
}
