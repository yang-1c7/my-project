package com.yjq.musiclz;

import org.junit.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
        String content = "%&123213";
        System.out.println(getNumbers(content));
        String s = "wang...123test4.jpg".replaceAll("[^\\d]", "");
        System.out.println(s);
        String path ="http://zhangmenshiting.qianqian.com/data2/music/8609324384c9128a2406f244be1541a8/611740443/611740443.mp3?xcode=051e2b90606427d2c9bf3d409e407d1c";
        path = path.substring(0, path.indexOf(".mp3?"));
        System.out.println(path);
        path = path.substring(path.lastIndexOf("/")+1);
        System.out.println(path);
    }

    //截取数字
    public String getNumbers(String content) {
        Pattern pattern = Pattern.compile("\\d+");
        Matcher matcher = pattern.matcher(content);
        while (matcher.find()) {
            return matcher.group(0);
        }
        return "";
    }
}